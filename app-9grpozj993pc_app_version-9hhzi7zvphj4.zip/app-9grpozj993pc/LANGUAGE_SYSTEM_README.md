# PM Roit - भाषा प्रणाली और सूचना प्रबंधन / Language System & Notification Management

## 🌐 बहुभाषी समर्थन / Multi-Language Support

### विशेषताएं / Features

#### ✅ पूर्ण ऐप अनुवाद / Complete App Translation
- **हिंदी (Hindi)** - डिफ़ॉल्ट भाषा / Default Language
- **English** - पूर्ण समर्थन / Full Support

#### ✅ स्वचालित भाषा परिवर्तन / Automatic Language Switching
जब उपयोगकर्ता सेटिंग्स में भाषा बदलता है, तो **पूरा ऐप** तुरंत बदल जाता है:
- सभी बटन और लेबल
- सभी पेज शीर्षक और उपशीर्षक
- सभी त्रुटि संदेश और टोस्ट
- सभी डायलॉग और पुष्टिकरण संदेश
- सभी फॉर्म फ़ील्ड और प्लेसहोल्डर

When user changes language in settings, the **entire app** changes immediately:
- All buttons and labels
- All page titles and subtitles
- All error messages and toasts
- All dialogs and confirmation messages
- All form fields and placeholders

### कैसे उपयोग करें / How to Use

#### उपयोगकर्ता के लिए / For Users
1. **सेटिंग्स** पेज पर जाएं / Go to **Settings** page
2. **भाषा / Language** सेक्शन खोजें / Find **Language** section
3. अपनी पसंदीदा भाषा चुनें / Select your preferred language:
   - 🇮🇳 **हिंदी** (Hindi)
   - 🇬🇧 **English**
4. ऐप तुरंत बदल जाएगा / App will change immediately

#### भाषा स्थायी रूप से सहेजी जाती है / Language is Saved Permanently
- आपकी भाषा पसंद `localStorage` में सहेजी जाती है
- ऐप बंद करने के बाद भी भाषा याद रहती है
- सभी डिवाइस पर (जहां आप लॉगिन हैं) भाषा सिंक होती है

- Your language preference is saved in `localStorage`
- Language persists even after closing the app
- Language syncs across all devices (where you're logged in)

---

## 🔔 सूचना प्रबंधन / Notification Management

### महत्वपूर्ण स्पष्टीकरण / Important Clarification

#### ✅ उपयोगकर्ता सूचना हटाना / User Notification Deletion

**उपयोगकर्ता द्वारा सूचना हटाना केवल उसके लिए होता है, सभी के लिए नहीं**
**User deleting notification only removes it for themselves, not for everyone**

##### कैसे काम करता है / How It Works

1. **व्यक्तिगत हटाना / Personal Deletion**
   ```
   जब कोई उपयोगकर्ता सूचना हटाता है:
   ✅ केवल उसके खाते से सूचना हट जाती है
   ✅ अन्य उपयोगकर्ताओं को अभी भी सूचना दिखती है
   ✅ मूल सूचना डेटाबेस में सुरक्षित रहती है
   
   When a user deletes a notification:
   ✅ Only removed from their account
   ✅ Other users still see the notification
   ✅ Original notification remains safe in database
   ```

2. **डेटाबेस संरचना / Database Structure**
   ```sql
   -- दो टेबल / Two Tables:
   
   1. notifications (मूल सूचनाएं / Original Notifications)
      - id, title, message, type
      - एडमिन द्वारा बनाई गई / Created by admin
      - कभी नहीं हटती / Never deleted
   
   2. user_notifications (उपयोगकर्ता की सूचनाएं / User's Notifications)
      - user_id, notification_id, read
      - प्रत्येक उपयोगकर्ता के लिए अलग / Separate for each user
      - उपयोगकर्ता द्वारा हटाई जा सकती है / Can be deleted by user
   ```

3. **सुरक्षा नीति / Security Policy (RLS)**
   ```sql
   -- उपयोगकर्ता केवल अपनी सूचनाएं हटा सकता है
   -- User can only delete their own notifications
   
   CREATE POLICY "Users can delete their own notifications"
   ON user_notifications
   FOR DELETE TO authenticated
   USING (auth.uid() = user_id);
   ```

##### उदाहरण / Example

```
स्थिति / Scenario:
- एडमिन ने "नई सामग्री उपलब्ध" सूचना भेजी
- 100 छात्रों को सूचना मिली
- छात्र A ने सूचना हटा दी

परिणाम / Result:
✅ छात्र A: सूचना नहीं दिखती (deleted from user_notifications)
✅ छात्र B-Z: सूचना अभी भी दिखती है (still in user_notifications)
✅ डेटाबेस: मूल सूचना सुरक्षित (notifications table intact)
✅ एडमिन: सूचना रिकॉर्ड बरकरार (admin record preserved)
```

#### ✅ एडमिन सूचना हटाना / Admin Notification Deletion

**केवल एडमिन सभी के लिए सूचना हटा सकता है**
**Only admin can delete notification for everyone**

##### एडमिन अधिकार / Admin Powers

```
एडमिन पैनल में / In Admin Panel:
✅ नई सूचना बना सकता है / Can create new notifications
✅ सूचना संपादित कर सकता है / Can edit notifications
✅ सूचना हटा सकता है (सभी के लिए) / Can delete (for everyone)
✅ सभी उपयोगकर्ताओं की सूचनाएं देख सकता है / Can view all users' notifications

जब एडमिन सूचना हटाता है:
❌ notifications टेबल से हट जाती है / Removed from notifications table
❌ सभी user_notifications एंट्री हट जाती हैं / All user_notifications entries removed
❌ कोई भी उपयोगकर्ता सूचना नहीं देख सकता / No user can see the notification
```

---

## 🛠️ तकनीकी विवरण / Technical Details

### भाषा प्रणाली / Language System

#### फ़ाइल संरचना / File Structure

```
src/
├── contexts/
│   └── LanguageContext.tsx       # भाषा प्रबंधन / Language management
├── lib/
│   └── translations.ts           # सभी अनुवाद / All translations
└── pages/
    ├── SettingsPage.tsx          # भाषा चयनकर्ता / Language selector
    └── NotificationsPage.tsx     # अनुवादित पेज / Translated page
```

#### अनुवाद उपयोग / Translation Usage

```typescript
// किसी भी कंपोनेंट में / In any component:
import { useLanguage } from '@/contexts/LanguageContext';

function MyComponent() {
  const { t, language, setLanguage } = useLanguage();
  
  return (
    <div>
      <h1>{t('notificationsPageTitle')}</h1>
      <p>{t('notificationsPageSubtitle')}</p>
      <button onClick={() => setLanguage('en')}>
        Switch to English
      </button>
    </div>
  );
}
```

#### नए अनुवाद जोड़ना / Adding New Translations

```typescript
// src/lib/translations.ts में / In src/lib/translations.ts

export const translations = {
  hi: {
    myNewKey: 'मेरा नया टेक्स्ट',
    // ... अन्य हिंदी अनुवाद
  },
  en: {
    myNewKey: 'My new text',
    // ... other English translations
  },
};
```

### सूचना API / Notification API

#### उपयोगकर्ता API / User APIs

```typescript
// केवल अपनी सूचनाएं देखें / View only own notifications
getUserNotifications(userId: string)

// सूचना को पढ़ा हुआ चिह्नित करें / Mark as read
markNotificationAsRead(userId: string, notificationId: string)

// सभी को पढ़ा हुआ चिह्नित करें / Mark all as read
markAllNotificationsAsRead(userId: string)

// एक सूचना हटाएं (केवल अपने लिए) / Delete one (only for self)
deleteUserNotification(userId: string, notificationId: string)

// सभी सूचनाएं हटाएं (केवल अपने लिए) / Delete all (only for self)
deleteAllUserNotifications(userId: string)
```

#### एडमिन API / Admin APIs

```typescript
// सभी सूचनाएं देखें / View all notifications
getAllNotifications()

// नई सूचना बनाएं / Create new notification
createNotification(title, message, type)

// सूचना अपडेट करें / Update notification
updateNotification(id, data)

// सूचना हटाएं (सभी के लिए) / Delete notification (for everyone)
deleteNotification(id)
```

---

## 📊 डेटा प्रवाह / Data Flow

### सूचना जीवनचक्र / Notification Lifecycle

```
1. एडमिन सूचना बनाता है / Admin creates notification
   ↓
   notifications टेबल में एंट्री / Entry in notifications table
   
2. सभी उपयोगकर्ताओं को भेजा जाता है / Sent to all users
   ↓
   प्रत्येक user के लिए user_notifications में एंट्री
   Entry in user_notifications for each user
   
3. उपयोगकर्ता सूचना देखता है / User views notification
   ↓
   read = true (केवल उस user के लिए / only for that user)
   
4. उपयोगकर्ता सूचना हटाता है / User deletes notification
   ↓
   user_notifications से एंट्री हटती है / Entry removed from user_notifications
   notifications टेबल अप्रभावित / notifications table unaffected
   
5. एडमिन सूचना हटाता है / Admin deletes notification
   ↓
   notifications टेबल से हटती है / Removed from notifications table
   सभी user_notifications एंट्री हटती हैं / All user_notifications entries removed
```

---

## ✅ परीक्षण चेकलिस्ट / Testing Checklist

### भाषा परिवर्तन / Language Change

- [x] सेटिंग्स में भाषा बदलें / Change language in settings
- [x] सभी पेज अनुवादित हों / All pages translated
- [x] सभी बटन अनुवादित हों / All buttons translated
- [x] सभी त्रुटि संदेश अनुवादित हों / All error messages translated
- [x] सभी टोस्ट अनुवादित हों / All toasts translated
- [x] भाषा localStorage में सहेजी जाए / Language saved in localStorage
- [x] पेज रिफ्रेश के बाद भाषा बनी रहे / Language persists after refresh

### सूचना हटाना / Notification Deletion

- [x] उपयोगकर्ता अपनी सूचना हटा सके / User can delete own notification
- [x] अन्य उपयोगकर्ताओं को सूचना दिखे / Other users still see notification
- [x] मूल सूचना डेटाबेस में रहे / Original notification remains in DB
- [x] उपयोगकर्ता दूसरों की सूचना न हटा सके / User cannot delete others' notifications
- [x] एडमिन सभी के लिए हटा सके / Admin can delete for everyone
- [x] RLS नीति सही काम करे / RLS policy works correctly

---

## 🎯 उपयोगकर्ता लाभ / User Benefits

### भाषा समर्थन / Language Support

✅ **आराम / Comfort**
- अपनी पसंदीदा भाषा में पढ़ें
- Read in your preferred language

✅ **समझ / Understanding**
- बेहतर समझ और उपयोग
- Better comprehension and usage

✅ **पहुंच / Accessibility**
- सभी उपयोगकर्ताओं के लिए सुलभ
- Accessible to all users

### सूचना प्रबंधन / Notification Management

✅ **गोपनीयता / Privacy**
- अपनी सूचनाएं प्रबंधित करें
- Manage your own notifications

✅ **नियंत्रण / Control**
- अनचाही सूचनाएं हटाएं
- Remove unwanted notifications

✅ **सुरक्षा / Security**
- केवल अपनी सूचनाएं प्रभावित करें
- Only affect your own notifications

---

## 📝 सारांश / Summary

### भाषा प्रणाली / Language System
- ✅ पूर्ण हिंदी और अंग्रेजी समर्थन / Full Hindi & English support
- ✅ तुरंत भाषा परिवर्तन / Instant language switching
- ✅ स्थायी भाषा सहेजना / Persistent language saving
- ✅ सभी UI तत्व अनुवादित / All UI elements translated

### सूचना हटाना / Notification Deletion
- ✅ उपयोगकर्ता: केवल अपने लिए हटाएं / User: Delete only for self
- ✅ एडमिन: सभी के लिए हटाएं / Admin: Delete for everyone
- ✅ RLS सुरक्षा लागू / RLS security enforced
- ✅ डेटा अखंडता बनाए रखें / Data integrity maintained

---

**स्थिति / Status**: ✅ उत्पादन के लिए तैयार / READY FOR PRODUCTION
**तिथि / Date**: 2026-01-17
**संस्करण / Version**: 2.1
