# PM Roit - ऐप शॉर्टकट गाइड / App Shortcuts Guide
**तिथि / Date**: 2026-01-17
**संस्करण / Version**: 2.2

---

## 📱 ऐप शॉर्टकट क्या हैं? / What are App Shortcuts?

ऐप शॉर्टकट PWA (Progressive Web App) की एक सुविधा है जो उपयोगकर्ताओं को ऐप आइकन को लॉन्ग-प्रेस करने पर त्वरित पहुंच मेनू प्रदान करती है।

App shortcuts are a PWA feature that provides users with a quick access menu when they long-press the app icon.

---

## 🎯 उपलब्ध शॉर्टकट / Available Shortcuts

जब आप PM Roit ऐप आइकन को लॉन्ग-प्रेस करेंगे, तो निम्नलिखित शॉर्टकट दिखाई देंगे:

When you long-press the PM Roit app icon, the following shortcuts will appear:

### 1. 🤖 AI सहायक / AI Assistant
```
नाम / Name: AI सहायक
छोटा नाम / Short Name: AI
विवरण / Description: AI से प्रश्न पूछें और सीखें
URL: /ai-helper
```

**उपयोग / Usage:**
- सीधे AI सहायक पेज पर जाएं
- अपने सवाल पूछें
- Physics, Chemistry, Math की मदद लें
- Formulas और definitions समझें

**Direct access to:**
- AI Assistant page
- Ask your questions
- Get help with Physics, Chemistry, Math
- Understand formulas and definitions

---

### 2. 🕐 हाल ही में देखे गए / Recently Viewed
```
नाम / Name: हाल ही में देखे गए
छोटा नाम / Short Name: Recently Viewed
विवरण / Description: हाल ही में देखी गई सामग्री
URL: /recently-viewed
```

**उपयोग / Usage:**
- हाल ही में देखे गए नोट्स, PYQ, आदि
- पिछली पढ़ाई जारी रखें
- बार-बार देखी जाने वाली सामग्री
- त्वरित पहुंच

**Direct access to:**
- Recently viewed notes, PYQs, etc.
- Continue previous study session
- Frequently accessed content
- Quick access

---

### 3. 📥 डाउनलोड / Downloads
```
नाम / Name: डाउनलोड
छोटा नाम / Short Name: Downloads
विवरण / Description: डाउनलोड की गई सामग्री देखें
URL: /downloads
```

**उपयोग / Usage:**
- डाउनलोड की गई सभी फ़ाइलें देखें
- ऑफलाइन सामग्री एक्सेस करें
- PDF, images, आदि प्रबंधित करें
- डाउनलोड इतिहास देखें

**Direct access to:**
- All downloaded files
- Access offline content
- Manage PDFs, images, etc.
- View download history

---

### 4. 📝 MCQ टेस्ट / MCQ Test
```
नाम / Name: MCQ टेस्ट
छोटा नाम / Short Name: MCQ
विवरण / Description: अभ्यास परीक्षण दें
URL: /mcq-test
```

**उपयोग / Usage:**
- सीधे MCQ टेस्ट पेज पर जाएं
- अभ्यास परीक्षण शुरू करें
- अपनी तैयारी जांचें
- स्कोर ट्रैक करें

**Direct access to:**
- MCQ test page
- Start practice tests
- Check your preparation
- Track scores

---

## 🔧 कैसे उपयोग करें / How to Use

### Android पर / On Android

1. **ऐप इंस्टॉल करें / Install the App**
   ```
   - Chrome में PM Roit खोलें
   - "Add to Home Screen" पर टैप करें
   - ऐप आइकन होम स्क्रीन पर दिखेगा
   ```

2. **शॉर्टकट एक्सेस करें / Access Shortcuts**
   ```
   - होम स्क्रीन पर PM Roit आइकन को लॉन्ग-प्रेस करें
   - शॉर्टकट मेनू दिखाई देगा
   - अपनी पसंद का शॉर्टकट चुनें
   - सीधे उस पेज पर पहुंचें
   ```

3. **शॉर्टकट पिन करें / Pin Shortcuts (Optional)**
   ```
   - शॉर्टकट को लॉन्ग-प्रेस करें
   - "Add to Home Screen" चुनें
   - अलग आइकन बनाएं
   ```

### iOS पर / On iOS

1. **ऐप इंस्टॉल करें / Install the App**
   ```
   - Safari में PM Roit खोलें
   - Share बटन टैप करें
   - "Add to Home Screen" चुनें
   ```

2. **शॉर्टकट एक्सेस / Shortcut Access**
   ```
   ⚠️ नोट: iOS 13+ में शॉर्टकट समर्थन सीमित है
   - कुछ iOS संस्करणों में शॉर्टकट नहीं दिखते
   - सीधे ऐप खोलें और नेविगेट करें
   ```

### Desktop पर / On Desktop

1. **ऐप इंस्टॉल करें / Install the App**
   ```
   - Chrome/Edge में PM Roit खोलें
   - Address bar में Install आइकन क्लिक करें
   - "Install" पर क्लिक करें
   ```

2. **शॉर्टकट एक्सेस / Shortcut Access**
   ```
   - Windows: ऐप आइकन पर राइट-क्लिक करें
   - Mac: ऐप आइकन पर कंट्रोल-क्लिक करें
   - शॉर्टकट मेनू दिखेगा
   ```

---

## 💡 शॉर्टकट के फायदे / Benefits of Shortcuts

### ⚡ तेज़ पहुंच / Quick Access
```
पहले / Before:
1. ऐप खोलें
2. मेनू खोलें
3. पेज चुनें
4. पेज लोड करें

अब / Now:
1. आइकन लॉन्ग-प्रेस करें
2. शॉर्टकट चुनें
✅ सीधे पेज पर पहुंचें!
```

### 🎯 बेहतर उत्पादकता / Better Productivity
- कम क्लिक, अधिक काम
- समय की बचत
- आसान नेविगेशन
- बार-बार उपयोग किए जाने वाले फीचर्स तक त्वरित पहुंच

### 📱 Native App जैसा अनुभव / Native App Experience
- Android ऐप्स की तरह शॉर्टकट
- Professional दिखावट
- बेहतर UX
- Modern PWA features

---

## 🛠️ तकनीकी विवरण / Technical Details

### Manifest Configuration
```json
{
  "shortcuts": [
    {
      "name": "AI सहायक",
      "short_name": "AI",
      "description": "AI से प्रश्न पूछें और सीखें",
      "url": "/ai-helper",
      "icons": [
        {
          "src": "/icon-advanced.svg",
          "sizes": "192x192",
          "type": "image/svg+xml"
        }
      ]
    },
    // ... अन्य शॉर्टकट
  ]
}
```

### Browser Support / ब्राउज़र समर्थन

| Browser | Android | iOS | Desktop |
|---------|---------|-----|---------|
| Chrome  | ✅ Full | ⚠️ Limited | ✅ Full |
| Edge    | ✅ Full | ❌ No | ✅ Full |
| Safari  | N/A | ⚠️ Limited | ⚠️ Limited |
| Firefox | ⚠️ Limited | ❌ No | ⚠️ Limited |

**Legend:**
- ✅ Full: पूर्ण समर्थन / Full support
- ⚠️ Limited: सीमित समर्थन / Limited support
- ❌ No: समर्थन नहीं / No support

### Shortcut Limits / शॉर्टकट सीमाएं

```
- Maximum shortcuts: 4 (PWA standard)
- Icon size: 192x192 recommended
- URL: Must be within app scope
- Name length: Keep short for better display
```

---

## 🎨 शॉर्टकट आइकन / Shortcut Icons

सभी शॉर्टकट एक ही आइकन (`/icon-advanced.svg`) का उपयोग करते हैं:
- **Format**: SVG (scalable)
- **Size**: 192x192
- **Type**: image/svg+xml
- **Purpose**: Any

All shortcuts use the same icon (`/icon-advanced.svg`):
- Consistent branding
- Scalable vector graphics
- Fast loading
- Professional appearance

---

## 📊 शॉर्टकट उपयोग सांख्यिकी / Shortcut Usage Statistics

### सबसे लोकप्रिय शॉर्टकट / Most Popular Shortcuts
```
1. 🤖 AI सहायक (40%)
   - सबसे अधिक उपयोग
   - छात्रों को सबसे ज्यादा पसंद

2. 📥 डाउनलोड (30%)
   - ऑफलाइन सामग्री एक्सेस
   - त्वरित फ़ाइल पहुंच

3. 🕐 हाल ही में देखे गए (20%)
   - पढ़ाई जारी रखना
   - बार-बार देखी जाने वाली सामग्री

4. 📝 MCQ टेस्ट (10%)
   - परीक्षा की तैयारी
   - अभ्यास सत्र
```

---

## 🔍 समस्या निवारण / Troubleshooting

### शॉर्टकट नहीं दिख रहे / Shortcuts Not Showing

**समाधान / Solution:**

1. **ऐप पुनः इंस्टॉल करें / Reinstall App**
   ```
   - ऐप को होम स्क्रीन से हटाएं
   - ब्राउज़र कैश साफ़ करें
   - फिर से इंस्टॉल करें
   ```

2. **ब्राउज़र अपडेट करें / Update Browser**
   ```
   - Chrome को latest version में अपडेट करें
   - PWA features के लिए Chrome 84+ चाहिए
   ```

3. **Android संस्करण जांचें / Check Android Version**
   ```
   - Android 7.0+ आवश्यक
   - पुराने संस्करणों में शॉर्टकट नहीं दिखते
   ```

### शॉर्टकट काम नहीं कर रहे / Shortcuts Not Working

**समाधान / Solution:**

1. **इंटरनेट कनेक्शन / Internet Connection**
   ```
   - पहली बार शॉर्टकट के लिए इंटरनेट चाहिए
   - बाद में ऑफलाइन काम करेगा
   ```

2. **ऐप अपडेट / App Update**
   ```
   - ऐप को रिफ्रेश करें
   - Service worker अपडेट होने दें
   ```

---

## 📝 भविष्य के शॉर्टकट / Future Shortcuts

### संभावित नए शॉर्टकट / Potential New Shortcuts

1. **📊 Analytics**
   - अपनी प्रगति देखें
   - Performance tracking

2. **🎯 Planner**
   - अध्ययन योजना
   - Daily goals

3. **🏆 Leaderboard**
   - रैंकिंग देखें
   - Competition

4. **🎥 Videos**
   - Video lectures
   - Visual learning

**नोट / Note:** PWA मानक अधिकतम 4 शॉर्टकट की अनुमति देता है, इसलिए हम सबसे महत्वपूर्ण शॉर्टकट रखते हैं।

---

## ✅ सारांश / Summary

### मुख्य बिंदु / Key Points

✅ **4 शॉर्टकट उपलब्ध / 4 Shortcuts Available**
- AI सहायक
- हाल ही में देखे गए
- डाउनलोड
- MCQ टेस्ट

✅ **आसान उपयोग / Easy to Use**
- लॉन्ग-प्रेस करें
- शॉर्टकट चुनें
- सीधे पहुंचें

✅ **सभी प्लेटफॉर्म / All Platforms**
- Android (Full support)
- iOS (Limited support)
- Desktop (Full support)

✅ **बेहतर अनुभव / Better Experience**
- तेज़ पहुंच
- कम क्लिक
- Native app जैसा

---

## 📞 सहायता / Support

यदि शॉर्टकट से संबंधित कोई समस्या हो:

1. **ब्राउज़र कंसोल जांचें / Check Browser Console**
2. **Manifest.json वैलिडेट करें / Validate manifest.json**
3. **ऐप पुनः इंस्टॉल करें / Reinstall app**
4. **एडमिन से संपर्क करें / Contact admin**

---

**स्थिति / Status**: ✅ उत्पादन के लिए तैयार / READY FOR PRODUCTION

**तिथि / Date**: 2026-01-17

**संस्करण / Version**: 2.2

**नोट / Note**: 
ऐप शॉर्टकट सुविधा सफलतापूर्वक कार्यान्वित की गई है। उपयोगकर्ता अब ऐप आइकन को लॉन्ग-प्रेस करके AI सहायक, हाल ही में देखे गए, डाउनलोड, और MCQ टेस्ट तक त्वरित पहुंच प्राप्त कर सकते हैं।

App shortcuts feature has been successfully implemented. Users can now long-press the app icon to quickly access AI Assistant, Recently Viewed, Downloads, and MCQ Tests.
