-- Create uploader feedback table
CREATE TABLE IF NOT EXISTS uploader_feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  uploader_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  subject TEXT NOT NULL,
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'replied', 'resolved')),
  admin_reply TEXT,
  replied_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
  replied_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_uploader_feedback_uploader_id ON uploader_feedback(uploader_id);
CREATE INDEX IF NOT EXISTS idx_uploader_feedback_status ON uploader_feedback(status);
CREATE INDEX IF NOT EXISTS idx_uploader_feedback_created_at ON uploader_feedback(created_at DESC);

-- Enable RLS
ALTER TABLE uploader_feedback ENABLE ROW LEVEL SECURITY;

-- Policies for uploader_feedback
-- Uploaders can view their own feedback
CREATE POLICY "uploaders_view_own_feedback" ON uploader_feedback
  FOR SELECT
  USING (
    auth.uid() = uploader_id 
    OR EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

-- Uploaders can create feedback
CREATE POLICY "uploaders_create_feedback" ON uploader_feedback
  FOR INSERT
  WITH CHECK (
    auth.uid() = uploader_id 
    AND EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role IN ('uploader', 'admin')
    )
  );

-- Only admins can update feedback (add replies)
CREATE POLICY "admins_update_feedback" ON uploader_feedback
  FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

-- Admins can delete feedback
CREATE POLICY "admins_delete_feedback" ON uploader_feedback
  FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_uploader_feedback_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to auto-update updated_at
CREATE TRIGGER uploader_feedback_updated_at
  BEFORE UPDATE ON uploader_feedback
  FOR EACH ROW
  EXECUTE FUNCTION update_uploader_feedback_updated_at();

-- Function to notify admins when feedback is submitted
CREATE OR REPLACE FUNCTION notify_admins_on_feedback()
RETURNS TRIGGER AS $$
DECLARE
  uploader_profile profiles%ROWTYPE;
BEGIN
  -- Get uploader profile
  SELECT * INTO uploader_profile FROM profiles WHERE id = NEW.uploader_id;
  
  -- Create notification for all admins
  INSERT INTO notifications (title, message, type, metadata, sent_by)
  VALUES (
    'नया अपलोडर फीडबैक',
    uploader_profile.full_name || ' ने फीडबैक भेजा: ' || NEW.subject,
    'system',
    jsonb_build_object(
      'feedback_id', NEW.id,
      'uploader_id', NEW.uploader_id,
      'uploader_name', uploader_profile.full_name,
      'subject', NEW.subject,
      'message', NEW.message,
      'type', 'uploader_feedback'
    ),
    NEW.uploader_id
  );
  
  -- Distribute to all admins
  INSERT INTO user_notifications (user_id, notification_id, read)
  SELECT id, (SELECT id FROM notifications ORDER BY created_at DESC LIMIT 1), false
  FROM profiles
  WHERE role = 'admin';
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to notify admins on new feedback
CREATE TRIGGER notify_admins_on_new_feedback
  AFTER INSERT ON uploader_feedback
  FOR EACH ROW
  EXECUTE FUNCTION notify_admins_on_feedback();

-- Function to notify uploader when admin replies
CREATE OR REPLACE FUNCTION notify_uploader_on_reply()
RETURNS TRIGGER AS $$
DECLARE
  admin_profile profiles%ROWTYPE;
BEGIN
  -- Only notify if admin_reply was added
  IF NEW.admin_reply IS NOT NULL AND (OLD.admin_reply IS NULL OR OLD.admin_reply != NEW.admin_reply) THEN
    -- Get admin profile
    SELECT * INTO admin_profile FROM profiles WHERE id = NEW.replied_by;
    
    -- Create notification for uploader
    INSERT INTO notifications (title, message, type, metadata, sent_by)
    VALUES (
      'फीडबैक का जवाब मिला',
      'एडमिन ने आपके फीडबैक का जवाब दिया: ' || NEW.subject,
      'system',
      jsonb_build_object(
        'feedback_id', NEW.id,
        'subject', NEW.subject,
        'admin_reply', NEW.admin_reply,
        'replied_by_name', admin_profile.full_name,
        'type', 'feedback_reply'
      ),
      NEW.replied_by
    );
    
    -- Send to uploader
    INSERT INTO user_notifications (user_id, notification_id, read)
    VALUES (NEW.uploader_id, (SELECT id FROM notifications ORDER BY created_at DESC LIMIT 1), false);
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to notify uploader on admin reply
CREATE TRIGGER notify_uploader_on_admin_reply
  AFTER UPDATE ON uploader_feedback
  FOR EACH ROW
  EXECUTE FUNCTION notify_uploader_on_reply();