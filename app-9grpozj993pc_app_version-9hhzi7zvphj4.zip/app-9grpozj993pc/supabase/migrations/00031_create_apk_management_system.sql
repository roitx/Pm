-- Create apk_files table for managing APK uploads
CREATE TABLE IF NOT EXISTS apk_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  version_name TEXT NOT NULL,
  version_code INTEGER NOT NULL,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size BIGINT NOT NULL,
  download_url TEXT NOT NULL,
  release_notes TEXT,
  is_active BOOLEAN DEFAULT true,
  uploaded_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_apk_files_active ON apk_files(is_active, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_apk_files_version ON apk_files(version_code DESC);

-- Enable RLS
ALTER TABLE apk_files ENABLE ROW LEVEL SECURITY;

-- RLS Policies for apk_files
-- Anyone can view active APK files
CREATE POLICY "Anyone can view active APK files"
  ON apk_files
  FOR SELECT
  USING (is_active = true);

-- Only admins can insert APK files
CREATE POLICY "Admins can insert APK files"
  ON apk_files
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Only admins can update APK files
CREATE POLICY "Admins can update APK files"
  ON apk_files
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Only admins can delete APK files
CREATE POLICY "Admins can delete APK files"
  ON apk_files
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Create storage bucket for APK files
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'apk-files',
  'apk-files',
  true,
  104857600, -- 100MB limit
  ARRAY['application/vnd.android.package-archive', 'application/octet-stream']
)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for apk-files bucket
-- Anyone can download APK files
CREATE POLICY "Anyone can download APK files"
  ON storage.objects
  FOR SELECT
  USING (bucket_id = 'apk-files');

-- Only admins can upload APK files
CREATE POLICY "Admins can upload APK files"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'apk-files'
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Only admins can delete APK files from storage
CREATE POLICY "Admins can delete APK files"
  ON storage.objects
  FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'apk-files'
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );