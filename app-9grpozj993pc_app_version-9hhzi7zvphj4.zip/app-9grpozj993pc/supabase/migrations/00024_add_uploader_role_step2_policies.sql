-- Update RLS policies for content table to allow uploaders to upload and edit their own content
-- Drop existing policies that might conflict
DROP POLICY IF EXISTS "uploader_can_insert_content" ON content;
DROP POLICY IF EXISTS "uploader_can_update_own_content" ON content;
DROP POLICY IF EXISTS "uploader_can_delete_own_content" ON content;

-- Create new policies for uploader role
-- Uploaders can insert content
CREATE POLICY "uploader_can_insert_content" ON content
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('uploader', 'admin')
    )
  );

-- Uploaders can update their own content, admins can update all
CREATE POLICY "uploader_can_update_own_content" ON content
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND (
        profiles.role = 'admin'
        OR (profiles.role = 'uploader' AND content.uploaded_by = auth.uid())
      )
    )
  );

-- Uploaders can delete their own content, admins can delete all
CREATE POLICY "uploader_can_delete_own_content" ON content
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND (
        profiles.role = 'admin'
        OR (profiles.role = 'uploader' AND content.uploaded_by = auth.uid())
      )
    )
  );

-- Update MCQ questions policies for uploaders
DROP POLICY IF EXISTS "uploader_can_insert_mcq" ON mcq_questions;
DROP POLICY IF EXISTS "uploader_can_update_own_mcq" ON mcq_questions;
DROP POLICY IF EXISTS "uploader_can_delete_own_mcq" ON mcq_questions;

-- Uploaders can insert MCQ questions
CREATE POLICY "uploader_can_insert_mcq" ON mcq_questions
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('uploader', 'admin')
    )
  );

-- Uploaders can update their own MCQ questions, admins can update all
CREATE POLICY "uploader_can_update_own_mcq" ON mcq_questions
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND (
        profiles.role = 'admin'
        OR (profiles.role = 'uploader' AND mcq_questions.created_by = auth.uid())
      )
    )
  );

-- Uploaders can delete their own MCQ questions, admins can delete all
CREATE POLICY "uploader_can_delete_own_mcq" ON mcq_questions
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND (
        profiles.role = 'admin'
        OR (profiles.role = 'uploader' AND mcq_questions.created_by = auth.uid())
      )
    )
  );