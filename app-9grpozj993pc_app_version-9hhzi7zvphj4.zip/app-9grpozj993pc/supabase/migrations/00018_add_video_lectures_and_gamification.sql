-- Video Lectures Table
CREATE TABLE IF NOT EXISTS video_lectures (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  video_url TEXT NOT NULL,
  thumbnail_url TEXT,
  class_number TEXT NOT NULL,
  subject TEXT NOT NULL,
  chapter TEXT NOT NULL,
  duration INTEGER, -- in seconds
  views INTEGER DEFAULT 0,
  uploaded_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- User Points Table
CREATE TABLE IF NOT EXISTS user_points (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  points INTEGER DEFAULT 0,
  level INTEGER DEFAULT 1,
  total_earned INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id)
);

-- Achievements Table
CREATE TABLE IF NOT EXISTS achievements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  points INTEGER DEFAULT 0,
  requirement_type TEXT NOT NULL, -- 'test_count', 'perfect_score', 'study_time', etc.
  requirement_value INTEGER NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- User Achievements Table
CREATE TABLE IF NOT EXISTS user_achievements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  achievement_id UUID REFERENCES achievements(id) ON DELETE CASCADE,
  earned_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, achievement_id)
);

-- Video Progress Table
CREATE TABLE IF NOT EXISTS video_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  video_id UUID REFERENCES video_lectures(id) ON DELETE CASCADE,
  progress INTEGER DEFAULT 0, -- percentage 0-100
  last_position INTEGER DEFAULT 0, -- in seconds
  completed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, video_id)
);

-- Points History Table
CREATE TABLE IF NOT EXISTS points_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  points INTEGER NOT NULL,
  reason TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_video_lectures_class ON video_lectures(class_number);
CREATE INDEX IF NOT EXISTS idx_video_lectures_subject ON video_lectures(subject);
CREATE INDEX IF NOT EXISTS idx_video_progress_user ON video_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_user_points_user ON user_points(user_id);
CREATE INDEX IF NOT EXISTS idx_user_achievements_user ON user_achievements(user_id);
CREATE INDEX IF NOT EXISTS idx_points_history_user ON points_history(user_id);

-- RLS Policies
ALTER TABLE video_lectures ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_points ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE video_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE points_history ENABLE ROW LEVEL SECURITY;

-- Video Lectures Policies (Everyone can read, only admins can write)
CREATE POLICY "Anyone can view video lectures" ON video_lectures FOR SELECT USING (true);
CREATE POLICY "Admins can insert video lectures" ON video_lectures FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
);
CREATE POLICY "Admins can update video lectures" ON video_lectures FOR UPDATE USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
);
CREATE POLICY "Admins can delete video lectures" ON video_lectures FOR DELETE USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
);

-- User Points Policies
CREATE POLICY "Users can view own points" ON user_points FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Users can view all points for leaderboard" ON user_points FOR SELECT USING (true);
CREATE POLICY "System can insert points" ON user_points FOR INSERT WITH CHECK (true);
CREATE POLICY "System can update points" ON user_points FOR UPDATE USING (true);

-- Achievements Policies
CREATE POLICY "Anyone can view achievements" ON achievements FOR SELECT USING (true);
CREATE POLICY "Admins can manage achievements" ON achievements FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
);

-- User Achievements Policies
CREATE POLICY "Users can view own achievements" ON user_achievements FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Users can view all achievements for leaderboard" ON user_achievements FOR SELECT USING (true);
CREATE POLICY "System can insert user achievements" ON user_achievements FOR INSERT WITH CHECK (true);

-- Video Progress Policies
CREATE POLICY "Users can view own video progress" ON video_progress FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Users can insert own video progress" ON video_progress FOR INSERT WITH CHECK (user_id = auth.uid());
CREATE POLICY "Users can update own video progress" ON video_progress FOR UPDATE USING (user_id = auth.uid());

-- Points History Policies
CREATE POLICY "Users can view own points history" ON points_history FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Admins can view all points history" ON points_history FOR SELECT USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
);
CREATE POLICY "System can insert points history" ON points_history FOR INSERT WITH CHECK (true);

-- Insert default achievements
INSERT INTO achievements (name, description, icon, points, requirement_type, requirement_value) VALUES
('पहला कदम', 'अपना पहला टेस्ट पूरा करें', '🎯', 10, 'test_count', 1),
('परफेक्ट स्कोर', '100% स्कोर प्राप्त करें', '💯', 50, 'perfect_score', 1),
('टेस्ट मास्टर', '10 टेस्ट पूरे करें', '🏆', 100, 'test_count', 10),
('अध्ययन योद्धा', '50 घंटे अध्ययन करें', '⚔️', 200, 'study_time', 50),
('डाउनलोड किंग', '100 फाइलें डाउनलोड करें', '📥', 150, 'download_count', 100),
('सवाल पूछने वाला', '10 सवाल पूछें', '❓', 75, 'doubt_count', 10),
('लगातार 7 दिन', '7 दिन लगातार लॉगिन करें', '🔥', 100, 'streak_days', 7),
('लगातार 30 दिन', '30 दिन लगातार लॉगिन करें', '🔥🔥', 500, 'streak_days', 30),
('वीडियो देखने वाला', '50 वीडियो देखें', '📹', 100, 'video_count', 50),
('बुकमार्क कलेक्टर', '50 आइटम बुकमार्क करें', '⭐', 75, 'bookmark_count', 50)
ON CONFLICT DO NOTHING;

-- Function to award points
CREATE OR REPLACE FUNCTION award_points(p_user_id UUID, p_points INTEGER, p_reason TEXT)
RETURNS void AS $$
BEGIN
  -- Insert or update user points
  INSERT INTO user_points (user_id, points, total_earned)
  VALUES (p_user_id, p_points, p_points)
  ON CONFLICT (user_id) 
  DO UPDATE SET 
    points = user_points.points + p_points,
    total_earned = user_points.total_earned + p_points,
    level = FLOOR((user_points.total_earned + p_points) / 100) + 1,
    updated_at = NOW();
  
  -- Insert points history
  INSERT INTO points_history (user_id, points, reason)
  VALUES (p_user_id, p_points, p_reason);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to check and award achievements
CREATE OR REPLACE FUNCTION check_achievements(p_user_id UUID)
RETURNS void AS $$
DECLARE
  achievement RECORD;
  test_count INTEGER;
  perfect_scores INTEGER;
  study_hours INTEGER;
BEGIN
  -- Get user stats
  SELECT COUNT(*) INTO test_count FROM mcq_test_results WHERE user_id = p_user_id;
  SELECT COUNT(*) INTO perfect_scores FROM mcq_test_results WHERE user_id = p_user_id AND score = 100;
  SELECT COALESCE(SUM(duration), 0) / 3600 INTO study_hours FROM study_sessions WHERE user_id = p_user_id;
  
  -- Check each achievement
  FOR achievement IN SELECT * FROM achievements LOOP
    -- Skip if already earned
    IF EXISTS (SELECT 1 FROM user_achievements WHERE user_id = p_user_id AND achievement_id = achievement.id) THEN
      CONTINUE;
    END IF;
    
    -- Check requirements
    IF (achievement.requirement_type = 'test_count' AND test_count >= achievement.requirement_value) OR
       (achievement.requirement_type = 'perfect_score' AND perfect_scores >= achievement.requirement_value) OR
       (achievement.requirement_type = 'study_time' AND study_hours >= achievement.requirement_value) THEN
      -- Award achievement
      INSERT INTO user_achievements (user_id, achievement_id) VALUES (p_user_id, achievement.id);
      -- Award points
      PERFORM award_points(p_user_id, achievement.points, 'Achievement: ' || achievement.name);
    END IF;
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;