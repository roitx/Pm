-- Add columns for original and auto-generated filenames to content table
ALTER TABLE content 
ADD COLUMN IF NOT EXISTS original_filename TEXT,
ADD COLUMN IF NOT EXISTS auto_generated_filename TEXT;

-- Add comment for documentation
COMMENT ON COLUMN content.original_filename IS 'Original filename uploaded by user (e.g., screenshot 82999.jpg)';
COMMENT ON COLUMN content.auto_generated_filename IS 'Auto-generated filename in format: classno_subject_chaptername (e.g., class12_physics_thermodynamics.pdf)';
