
-- Update about_page settings to support rich content structure
-- The setting_value JSONB will now support:
-- {
--   "app_name": "...",
--   "app_description": "...",
--   "contact_email": "...",
--   "contact_phone": "...",
--   "whatsapp": "...",
--   "youtube_url": "...",
--   "instagram_url": "...",
--   "facebook_url": "...",
--   "twitter_url": "...",
--   "founder": {
--     "name": "...",
--     "title": "...",
--     "image_url": "...",
--     "message": "..."
--   },
--   "mission": "...",
--   "vision": "...",
--   "faqs": [
--     {"question": "...", "answer": "..."}
--   ]
-- }

-- No schema changes needed, just documenting the new structure
-- The admin_settings table already supports JSONB for setting_value
COMMENT ON COLUMN admin_settings.setting_value IS 'JSONB field supporting rich about content including founder profile, mission, vision, and FAQs';
