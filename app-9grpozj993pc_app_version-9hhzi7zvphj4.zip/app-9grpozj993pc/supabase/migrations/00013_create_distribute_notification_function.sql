-- Create function to distribute daily motivation notification to all users
CREATE OR REPLACE FUNCTION distribute_notification()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Insert a notification for all users
  INSERT INTO notifications (title, message, type, sent_by, created_at)
  VALUES (
    'आज का प्रेरक विचार',
    'सफलता का रहस्य है - कभी हार न मानना। हर दिन एक नया अवसर है सीखने और बढ़ने का। अपने लक्ष्य की ओर आगे बढ़ते रहें!',
    'announcement',
    (SELECT id FROM auth.users WHERE email = 'masumboy141@gmail.com' LIMIT 1),
    NOW()
  );
END;
$$;