-- Add premium status to profiles
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS is_premium BOOLEAN DEFAULT FALSE;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS premium_expires_at TIMESTAMP WITH TIME ZONE;

-- Create premium_features table
CREATE TABLE IF NOT EXISTS premium_features (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  feature_key TEXT UNIQUE NOT NULL,
  feature_name TEXT NOT NULL,
  description TEXT,
  is_enabled BOOLEAN DEFAULT TRUE,
  is_premium BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default premium features
INSERT INTO premium_features (feature_key, feature_name, description, is_premium) VALUES
  ('ai_helper', 'AI सहायक', 'AI-संचालित शैक्षिक सहायक से असीमित प्रश्न पूछें', TRUE),
  ('unlimited_mcq', 'असीमित MCQ टेस्ट', 'असीमित MCQ टेस्ट एक्सेस करें', TRUE),
  ('unlimited_downloads', 'असीमित डाउनलोड', 'असीमित सामग्री डाउनलोड करें', TRUE),
  ('advanced_content', 'उन्नत सामग्री', 'प्रीमियम नोट्स और संदर्भ पुस्तकों तक पहुंच', TRUE),
  ('ad_free', 'विज्ञापन मुक्त', 'विज्ञापन-मुक्त अनुभव का आनंद लें', TRUE),
  ('priority_support', 'प्राथमिकता समर्थन', 'संदेह समाधान में प्राथमिकता प्राप्त करें', TRUE)
ON CONFLICT (feature_key) DO NOTHING;

-- Create user_feature_usage table to track usage
CREATE TABLE IF NOT EXISTS user_feature_usage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  feature_key TEXT NOT NULL,
  usage_count INTEGER DEFAULT 0,
  last_used_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, feature_key)
);

-- RLS Policies
ALTER TABLE premium_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_feature_usage ENABLE ROW LEVEL SECURITY;

-- Premium features: Everyone can read
CREATE POLICY "premium_features_select_all" ON premium_features FOR SELECT USING (TRUE);

-- Premium features: Only admins can modify
CREATE POLICY "premium_features_admin_all" ON premium_features FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
);

-- User feature usage: Users can read their own
CREATE POLICY "user_feature_usage_select_own" ON user_feature_usage FOR SELECT USING (
  auth.uid() = user_id
);

-- User feature usage: Users can insert/update their own
CREATE POLICY "user_feature_usage_insert_own" ON user_feature_usage FOR INSERT WITH CHECK (
  auth.uid() = user_id
);

CREATE POLICY "user_feature_usage_update_own" ON user_feature_usage FOR UPDATE USING (
  auth.uid() = user_id
);

-- Admins can view all usage
CREATE POLICY "user_feature_usage_admin_all" ON user_feature_usage FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
);

-- Create function to check if user has premium access
CREATE OR REPLACE FUNCTION has_premium_access(user_id_param UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = user_id_param 
    AND is_premium = TRUE 
    AND (premium_expires_at IS NULL OR premium_expires_at > NOW())
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to check feature access
CREATE OR REPLACE FUNCTION can_access_feature(user_id_param UUID, feature_key_param TEXT)
RETURNS BOOLEAN AS $$
DECLARE
  feature_is_premium BOOLEAN;
  user_has_premium BOOLEAN;
BEGIN
  -- Get feature premium status
  SELECT is_premium INTO feature_is_premium
  FROM premium_features
  WHERE feature_key = feature_key_param AND is_enabled = TRUE;
  
  -- If feature doesn't exist or is not premium, allow access
  IF feature_is_premium IS NULL OR feature_is_premium = FALSE THEN
    RETURN TRUE;
  END IF;
  
  -- Check if user has premium
  user_has_premium := has_premium_access(user_id_param);
  
  RETURN user_has_premium;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;