-- Update is_admin function with correct parameter name to avoid conflict
create or replace function public.is_admin(uid uuid)
returns boolean as $$
begin
  return exists (
    select 1
    from public.profiles
    where id = uid
    and role = 'admin'
  );
end;
$$ language plpgsql security definer;

-- Fix APK Files bucket policies
drop policy if exists "Admins can upload apks" on storage.objects;
drop policy if exists "Admins can update apks" on storage.objects;
drop policy if exists "Admins can delete apks" on storage.objects;
drop policy if exists "Anyone can read apks" on storage.objects;

create policy "Admins can upload apks"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'apk-files' and 
  public.is_admin(auth.uid())
);

create policy "Admins can update apks"
on storage.objects for update
to authenticated
using (
  bucket_id = 'apk-files' and 
  public.is_admin(auth.uid())
);

create policy "Admins can delete apks"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'apk-files' and 
  public.is_admin(auth.uid())
);

create policy "Anyone can read apks"
on storage.objects for select
to public
using (bucket_id = 'apk-files');

-- Ensure apk_files table policies are correct and visible to admins
drop policy if exists "Admins can insert APK files" on public.apk_files;
create policy "Admins can insert APK files"
on public.apk_files for insert
to authenticated
with check (public.is_admin(auth.uid()));

drop policy if exists "Admins can delete APK files" on public.apk_files;
create policy "Admins can delete APK files"
on public.apk_files for delete
to authenticated
using (public.is_admin(auth.uid()));

drop policy if exists "Admins can update APK files" on public.apk_files;
create policy "Admins can update APK files"
on public.apk_files for update
to authenticated
using (public.is_admin(auth.uid()));

drop policy if exists "Anyone can view active APK files" on public.apk_files;
create policy "Anyone can view active APK files"
on public.apk_files for select
using (is_active = true or public.is_admin(auth.uid()));
