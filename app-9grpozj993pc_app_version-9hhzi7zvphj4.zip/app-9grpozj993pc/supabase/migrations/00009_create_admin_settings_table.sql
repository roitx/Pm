-- Create admin_settings table for about page configuration
CREATE TABLE IF NOT EXISTS admin_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key TEXT UNIQUE NOT NULL,
  setting_value JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  updated_by UUID REFERENCES auth.users(id)
);

-- Insert default about page settings
INSERT INTO admin_settings (setting_key, setting_value) VALUES
('about_page', '{
  "app_name": "PM - Roit Study Hub",
  "app_description": "कक्षा 8-12 के छात्रों के लिए संपूर्ण अध्ययन सामग्री",
  "contact_email": "support@pmroit.com",
  "contact_phone": "+91 9876543210",
  "whatsapp": "+91 9876543210",
  "youtube_url": "https://youtube.com/@pmroit",
  "instagram_url": "https://instagram.com/pmroit",
  "facebook_url": "https://facebook.com/pmroit",
  "twitter_url": "https://twitter.com/pmroit"
}'::jsonb)
ON CONFLICT (setting_key) DO NOTHING;

-- Enable RLS
ALTER TABLE admin_settings ENABLE ROW LEVEL SECURITY;

-- Policy: Anyone can read settings
CREATE POLICY "Anyone can read admin settings"
  ON admin_settings FOR SELECT
  USING (true);

-- Policy: Only admins can update settings
CREATE POLICY "Only admins can update admin settings"
  ON admin_settings FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Create function to get stats
CREATE OR REPLACE FUNCTION get_admin_stats()
RETURNS JSON AS $$
DECLARE
  result JSON;
BEGIN
  SELECT json_build_object(
    'total_students', (SELECT COUNT(*) FROM profiles WHERE role = 'student'),
    'total_content', (SELECT COUNT(*) FROM content),
    'total_mcq_questions', (SELECT COUNT(*) FROM mcq_questions),
    'total_notifications', (SELECT COUNT(*) FROM notifications)
  ) INTO result;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;