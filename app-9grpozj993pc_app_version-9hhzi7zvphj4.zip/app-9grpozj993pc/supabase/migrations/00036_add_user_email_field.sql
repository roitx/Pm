-- Add user_email field to store user's real email separately from auth email
-- The 'email' field will continue to be used for authentication (username@miaoda.com)
-- The 'user_email' field will store the user's actual email address

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS user_email TEXT;

-- Create index for faster email lookups
CREATE INDEX IF NOT EXISTS idx_profiles_user_email ON profiles(user_email);

-- Add comment to clarify the difference
COMMENT ON COLUMN profiles.email IS 'Authentication email (username@miaoda.com format)';
COMMENT ON COLUMN profiles.user_email IS 'User''s real email address (can be changed by user)';