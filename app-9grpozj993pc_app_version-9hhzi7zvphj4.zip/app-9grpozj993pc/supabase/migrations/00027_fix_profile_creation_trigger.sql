
-- Drop the old trigger
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;

-- Create trigger for INSERT (when user signs up)
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- Also keep trigger for UPDATE (for backwards compatibility)
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();
