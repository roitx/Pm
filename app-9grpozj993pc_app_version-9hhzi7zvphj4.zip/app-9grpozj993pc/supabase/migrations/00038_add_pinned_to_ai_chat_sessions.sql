-- Add pinned column to ai_chat_sessions table
ALTER TABLE ai_chat_sessions ADD COLUMN IF NOT EXISTS pinned BOOLEAN DEFAULT FALSE;

-- Create index for pinned sessions
CREATE INDEX IF NOT EXISTS idx_ai_chat_sessions_pinned ON ai_chat_sessions(user_id, pinned DESC, updated_at DESC);