-- Re-create storage policies for apk-files
drop policy if exists "Admins can upload apks" on storage.objects;
drop policy if exists "Admins can update apks" on storage.objects;
drop policy if exists "Admins can delete apks" on storage.objects;
drop policy if exists "Anyone can read apks" on storage.objects;

create policy "Admins can upload apks"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'apk-files' and 
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);

create policy "Admins can update apks"
on storage.objects for update
to authenticated
using (
  bucket_id = 'apk-files' and 
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);

create policy "Admins can delete apks"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'apk-files' and 
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);

create policy "Anyone can read apks"
on storage.objects for select
to public
using (bucket_id = 'apk-files');
