-- Fix handle_new_user to prevent duplicate insert errors

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  user_count INTEGER;
  new_role public.user_role;
  premium_expires TIMESTAMP WITH TIME ZONE;
  profile_exists BOOLEAN;
BEGIN
  -- Check if profile already exists
  SELECT EXISTS(SELECT 1 FROM profiles WHERE id = NEW.id) INTO profile_exists;
  
  -- Only insert if profile doesn't exist
  IF NOT profile_exists THEN
    -- Count existing profiles to determine if this is the first user
    SELECT COUNT(*) INTO user_count FROM profiles;
    
    -- Determine role: first user is admin, others are regular users
    IF user_count = 0 THEN
      new_role := 'admin'::public.user_role;
      premium_expires := NULL; -- Admin gets unlimited premium (NULL means unlimited)
    ELSE
      new_role := 'user'::public.user_role;
      premium_expires := NULL; -- Regular users don't get premium by default
    END IF;
    
    -- Insert new profile
    INSERT INTO public.profiles (id, email, full_name, role, is_premium, premium_expires_at)
    VALUES (
      NEW.id,
      NEW.email,
      COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
      new_role,
      CASE WHEN new_role = 'admin' THEN true ELSE false END,
      premium_expires
    );
  END IF;
  
  RETURN NEW;
END;
$$;