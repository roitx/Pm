-- Fix admin role logic and add premium features for admin and uploader

-- Update handle_new_user function to make first user admin and add premium features
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  user_count INTEGER;
  new_role public.user_role;
  premium_expires TIMESTAMP WITH TIME ZONE;
BEGIN
  -- Count existing profiles
  SELECT COUNT(*) INTO user_count FROM profiles;
  
  -- Determine role: first user is admin, others are regular users
  IF user_count = 0 THEN
    new_role := 'admin'::public.user_role;
    premium_expires := NULL; -- Admin gets unlimited premium (NULL means unlimited)
  ELSE
    new_role := 'user'::public.user_role;
    premium_expires := NULL; -- Regular users don't get premium by default
  END IF;
  
  -- Insert new profile
  INSERT INTO public.profiles (id, email, full_name, role, is_premium, premium_expires_at)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    new_role,
    CASE WHEN new_role = 'admin' THEN true ELSE false END,
    premium_expires
  );
  
  RETURN NEW;
END;
$$;

-- Create function to update premium when role changes to admin or uploader
CREATE OR REPLACE FUNCTION update_premium_on_role_change()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  -- Prevent admin from being converted to other roles
  IF OLD.role = 'admin' AND NEW.role != 'admin' THEN
    RAISE EXCEPTION 'एडमिन को अन्य भूमिका में परिवर्तित नहीं किया जा सकता';
  END IF;
  
  -- If role changed to admin, give unlimited premium
  IF NEW.role = 'admin' AND OLD.role != 'admin' THEN
    NEW.is_premium := true;
    NEW.premium_expires_at := NULL; -- NULL means unlimited
  END IF;
  
  -- If role changed to uploader, give 6 months premium
  IF NEW.role = 'uploader' AND OLD.role != 'uploader' THEN
    NEW.is_premium := true;
    NEW.premium_expires_at := NOW() + INTERVAL '6 months';
  END IF;
  
  RETURN NEW;
END;
$$;

-- Drop existing trigger if exists
DROP TRIGGER IF EXISTS on_role_change_update_premium ON profiles;

-- Create trigger for role changes
CREATE TRIGGER on_role_change_update_premium
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  WHEN (OLD.role IS DISTINCT FROM NEW.role)
  EXECUTE FUNCTION update_premium_on_role_change();

-- Update existing admin users to have unlimited premium
UPDATE profiles
SET is_premium = true, premium_expires_at = NULL
WHERE role = 'admin';

-- Update existing uploader users to have 6 months premium (if not already premium)
UPDATE profiles
SET 
  is_premium = true, 
  premium_expires_at = CASE 
    WHEN premium_expires_at IS NULL OR premium_expires_at < NOW() 
    THEN NOW() + INTERVAL '6 months'
    ELSE premium_expires_at
  END
WHERE role = 'uploader';