-- Add date_of_birth to profiles table
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS date_of_birth DATE;

-- Create 3d_structures table
CREATE TABLE IF NOT EXISTS public.threed_structures (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  class INTEGER NOT NULL,
  subject TEXT NOT NULL,
  chapter TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  file_url TEXT NOT NULL,
  file_type TEXT NOT NULL,
  thumbnail_url TEXT,
  uploaded_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create external_notes table
CREATE TABLE IF NOT EXISTS public.external_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  class INTEGER NOT NULL,
  subject TEXT NOT NULL,
  chapter TEXT NOT NULL,
  source TEXT NOT NULL, -- 'PW' or 'RS Sir' or other sources
  title TEXT NOT NULL,
  description TEXT,
  file_url TEXT NOT NULL,
  file_type TEXT NOT NULL,
  uploaded_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.threed_structures ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.external_notes ENABLE ROW LEVEL SECURITY;

-- RLS Policies for 3d_structures
CREATE POLICY "Anyone can view 3D structures"
  ON public.threed_structures FOR SELECT
  USING (true);

CREATE POLICY "Admin can insert 3D structures"
  ON public.threed_structures FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'uploader')
    )
  );

CREATE POLICY "Admin can update 3D structures"
  ON public.threed_structures FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'uploader')
    )
  );

CREATE POLICY "Admin can delete 3D structures"
  ON public.threed_structures FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'uploader')
    )
  );

-- RLS Policies for external_notes
CREATE POLICY "Anyone can view external notes"
  ON public.external_notes FOR SELECT
  USING (true);

CREATE POLICY "Admin can insert external notes"
  ON public.external_notes FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'uploader')
    )
  );

CREATE POLICY "Admin can update external notes"
  ON public.external_notes FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'uploader')
    )
  );

CREATE POLICY "Admin can delete external notes"
  ON public.external_notes FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'uploader')
    )
  );

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_threed_structures_class ON public.threed_structures(class);
CREATE INDEX IF NOT EXISTS idx_threed_structures_subject ON public.threed_structures(subject);
CREATE INDEX IF NOT EXISTS idx_threed_structures_chapter ON public.threed_structures(chapter);
CREATE INDEX IF NOT EXISTS idx_external_notes_class ON public.external_notes(class);
CREATE INDEX IF NOT EXISTS idx_external_notes_subject ON public.external_notes(subject);
CREATE INDEX IF NOT EXISTS idx_external_notes_chapter ON public.external_notes(chapter);
CREATE INDEX IF NOT EXISTS idx_external_notes_source ON public.external_notes(source);