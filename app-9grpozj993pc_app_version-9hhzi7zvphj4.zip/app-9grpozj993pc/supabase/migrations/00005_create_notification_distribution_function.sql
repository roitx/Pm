-- Create function to distribute notifications to all users
CREATE OR REPLACE FUNCTION distribute_notification_to_users()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert notification for all users (except the sender if exists)
  INSERT INTO user_notifications (user_id, notification_id, read)
  SELECT 
    id,
    NEW.id,
    false
  FROM profiles
  WHERE id != COALESCE(NEW.sent_by, '00000000-0000-0000-0000-000000000000'::uuid);
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to automatically distribute notifications
DROP TRIGGER IF EXISTS on_notification_created ON notifications;
CREATE TRIGGER on_notification_created
  AFTER INSERT ON notifications
  FOR EACH ROW
  EXECUTE FUNCTION distribute_notification_to_users();

-- Add comment
COMMENT ON FUNCTION distribute_notification_to_users() IS 'Automatically creates user_notifications entries for all users when admin creates a notification';