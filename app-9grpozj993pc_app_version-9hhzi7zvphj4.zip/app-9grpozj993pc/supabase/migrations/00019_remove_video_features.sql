-- Remove video-related tables as they are not needed
DROP TABLE IF EXISTS video_progress CASCADE;
DROP TABLE IF EXISTS video_lectures CASCADE;

-- Keep gamification tables as they are useful for student engagement
-- (user_points, achievements, user_achievements, points_history)

-- Update achievements to remove video-related ones
DELETE FROM achievements WHERE requirement_type = 'video_count';

-- Add more relevant achievements
INSERT INTO achievements (name, description, icon, points, requirement_type, requirement_value) VALUES
('नियमित अध्ययन', '5 दिन लगातार अध्ययन करें', '📚', 50, 'streak_days', 5),
('प्रश्न विशेषज्ञ', '50 MCQ प्रश्न हल करें', '🎓', 100, 'mcq_solved', 50),
('डाउनलोड मास्टर', '50 फाइलें डाउनलोड करें', '📥', 75, 'download_count', 50),
('सक्रिय छात्र', '20 दिन लगातार लॉगिन करें', '⭐', 200, 'streak_days', 20)
ON CONFLICT DO NOTHING;