
-- Enable auto-confirm for users since we disabled email verification
-- This ensures users are immediately active after signup

-- Update the handle_new_user function to ensure it works with auto-confirmed users
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  user_count INTEGER;
  new_role public.user_role;
  premium_expires TIMESTAMP WITH TIME ZONE;
  profile_exists BOOLEAN;
BEGIN
  -- Log the trigger execution
  RAISE LOG 'handle_new_user triggered for user: %', NEW.id;
  
  -- Check if profile already exists
  SELECT EXISTS(SELECT 1 FROM profiles WHERE id = NEW.id) INTO profile_exists;
  
  IF profile_exists THEN
    RAISE LOG 'Profile already exists for user: %', NEW.id;
    RETURN NEW;
  END IF;
  
  -- Count existing profiles to determine if this is the first user
  SELECT COUNT(*) INTO user_count FROM profiles;
  RAISE LOG 'Existing profile count: %', user_count;
  
  -- Determine role: first user is admin, others are regular users
  IF user_count = 0 THEN
    new_role := 'admin'::public.user_role;
    premium_expires := NULL; -- Admin gets unlimited premium
    RAISE LOG 'Creating admin user';
  ELSE
    new_role := 'user'::public.user_role;
    premium_expires := NULL; -- Regular users don't get premium by default
    RAISE LOG 'Creating regular user';
  END IF;
  
  -- Insert new profile
  BEGIN
    INSERT INTO public.profiles (
      id, 
      email, 
      full_name, 
      role, 
      is_premium, 
      premium_expires_at,
      created_at,
      updated_at
    )
    VALUES (
      NEW.id,
      NEW.email,
      COALESCE(NEW.raw_user_meta_data->>'full_name', COALESCE(NEW.raw_user_meta_data->>'username', '')),
      new_role,
      CASE WHEN new_role = 'admin' THEN true ELSE false END,
      premium_expires,
      NOW(),
      NOW()
    );
    
    RAISE LOG 'Profile created successfully for user: %', NEW.id;
    
  EXCEPTION WHEN OTHERS THEN
    RAISE WARNING 'Error creating profile for user %: % %', NEW.id, SQLERRM, SQLSTATE;
    -- Don't fail the auth signup, just log the error
  END;
  
  RETURN NEW;
END;
$function$;

-- Ensure triggers are properly set up
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;

-- Create trigger for INSERT (when user signs up)
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- Also keep trigger for UPDATE (for backwards compatibility)
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  WHEN (OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL)
  EXECUTE FUNCTION handle_new_user();
