-- Add daily usage tracking columns to user_feature_usage
ALTER TABLE user_feature_usage ADD COLUMN IF NOT EXISTS daily_usage_count INTEGER DEFAULT 0;
ALTER TABLE user_feature_usage ADD COLUMN IF NOT EXISTS daily_usage_date DATE DEFAULT CURRENT_DATE;

-- Add daily limits to premium_features
ALTER TABLE premium_features ADD COLUMN IF NOT EXISTS daily_limit INTEGER;
ALTER TABLE premium_features ADD COLUMN IF NOT EXISTS free_daily_limit INTEGER;

-- Update existing features with daily limits
UPDATE premium_features SET 
  daily_limit = NULL,  -- NULL means unlimited for premium users
  free_daily_limit = 50  -- 50 messages per day for free users
WHERE feature_key = 'ai_helper';

UPDATE premium_features SET 
  daily_limit = NULL,  -- NULL means unlimited for premium users
  free_daily_limit = 20  -- 20 downloads per day for free users
WHERE feature_key = 'unlimited_downloads';

-- Create function to check feature access with daily limits
CREATE OR REPLACE FUNCTION can_access_feature_with_limit(user_id_param UUID, feature_key_param TEXT)
RETURNS BOOLEAN AS $$
DECLARE
  feature_is_premium BOOLEAN;
  user_has_premium BOOLEAN;
  feature_free_limit INTEGER;
  user_daily_count INTEGER;
  user_usage_date DATE;
BEGIN
  -- Get feature details
  SELECT is_premium, free_daily_limit INTO feature_is_premium, feature_free_limit
  FROM premium_features
  WHERE feature_key = feature_key_param AND is_enabled = TRUE;
  
  -- If feature doesn't exist, deny access
  IF feature_is_premium IS NULL THEN
    RETURN FALSE;
  END IF;
  
  -- Check if user has premium
  user_has_premium := has_premium_access(user_id_param);
  
  -- If user has premium, allow access
  IF user_has_premium = TRUE THEN
    RETURN TRUE;
  END IF;
  
  -- If feature is not premium (free for all), allow access
  IF feature_is_premium = FALSE THEN
    RETURN TRUE;
  END IF;
  
  -- Check daily usage for free users
  IF feature_free_limit IS NOT NULL THEN
    -- Get user's daily usage
    SELECT daily_usage_count, daily_usage_date INTO user_daily_count, user_usage_date
    FROM user_feature_usage
    WHERE user_id = user_id_param AND feature_key = feature_key_param;
    
    -- If no usage record exists, allow access (will be created on first use)
    IF user_daily_count IS NULL THEN
      RETURN TRUE;
    END IF;
    
    -- Reset count if it's a new day
    IF user_usage_date < CURRENT_DATE THEN
      RETURN TRUE;
    END IF;
    
    -- Check if user has exceeded daily limit
    IF user_daily_count >= feature_free_limit THEN
      RETURN FALSE;
    END IF;
    
    -- User is within daily limit
    RETURN TRUE;
  END IF;
  
  -- Default: deny access for premium features without free limit
  RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to track feature usage with daily limits
CREATE OR REPLACE FUNCTION track_feature_usage_with_limit(user_id_param UUID, feature_key_param TEXT)
RETURNS VOID AS $$
DECLARE
  existing_usage RECORD;
BEGIN
  -- Get existing usage record
  SELECT * INTO existing_usage
  FROM user_feature_usage
  WHERE user_id = user_id_param AND feature_key = feature_key_param;
  
  IF existing_usage IS NULL THEN
    -- Create new record
    INSERT INTO user_feature_usage (user_id, feature_key, usage_count, daily_usage_count, daily_usage_date)
    VALUES (user_id_param, feature_key_param, 1, 1, CURRENT_DATE);
  ELSE
    -- Check if it's a new day
    IF existing_usage.daily_usage_date < CURRENT_DATE THEN
      -- Reset daily count for new day
      UPDATE user_feature_usage
      SET 
        usage_count = usage_count + 1,
        daily_usage_count = 1,
        daily_usage_date = CURRENT_DATE,
        last_used_at = NOW()
      WHERE id = existing_usage.id;
    ELSE
      -- Increment counts
      UPDATE user_feature_usage
      SET 
        usage_count = usage_count + 1,
        daily_usage_count = daily_usage_count + 1,
        last_used_at = NOW()
      WHERE id = existing_usage.id;
    END IF;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;