
-- Drop and recreate the handle_new_user function with better error handling
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
  user_count INTEGER;
  new_role public.user_role;
  premium_expires TIMESTAMP WITH TIME ZONE;
  profile_exists BOOLEAN;
BEGIN
  -- Log the trigger execution
  RAISE NOTICE 'handle_new_user triggered for user: %', NEW.id;
  
  -- Check if profile already exists
  SELECT EXISTS(SELECT 1 FROM profiles WHERE id = NEW.id) INTO profile_exists;
  
  IF profile_exists THEN
    RAISE NOTICE 'Profile already exists for user: %', NEW.id;
    RETURN NEW;
  END IF;
  
  -- Count existing profiles to determine if this is the first user
  SELECT COUNT(*) INTO user_count FROM profiles;
  RAISE NOTICE 'Existing profile count: %', user_count;
  
  -- Determine role: first user is admin, others are regular users
  IF user_count = 0 THEN
    new_role := 'admin'::public.user_role;
    premium_expires := NULL; -- Admin gets unlimited premium
    RAISE NOTICE 'Creating admin user';
  ELSE
    new_role := 'user'::public.user_role;
    premium_expires := NULL; -- Regular users don't get premium by default
    RAISE NOTICE 'Creating regular user';
  END IF;
  
  -- Insert new profile
  BEGIN
    INSERT INTO public.profiles (
      id, 
      email, 
      full_name, 
      role, 
      is_premium, 
      premium_expires_at
    )
    VALUES (
      NEW.id,
      NEW.email,
      COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
      new_role,
      CASE WHEN new_role = 'admin' THEN true ELSE false END,
      premium_expires
    );
    
    RAISE NOTICE 'Profile created successfully for user: %', NEW.id;
    
  EXCEPTION WHEN OTHERS THEN
    RAISE WARNING 'Error creating profile for user %: % %', NEW.id, SQLERRM, SQLSTATE;
    -- Don't fail the auth signup, just log the error
    -- The SignupPage will retry and handle this
  END;
  
  RETURN NEW;
END;
$function$;
