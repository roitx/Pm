-- Create app_assets bucket
insert into storage.buckets (id, name, public)
values ('app-9grpozj993pc_app_assets', 'app-9grpozj993pc_app_assets', true)
on conflict (id) do nothing;

-- Set up policies for app_assets bucket
-- Allow public read access
create policy "Public Read Access"
on storage.objects for select
using (bucket_id = 'app-9grpozj993pc_app_assets');

-- Allow authenticated users (admins) to upload
create policy "Admin Upload Access"
on storage.objects for insert
with check (
  bucket_id = 'app-9grpozj993pc_app_assets' 
  and auth.role() = 'authenticated'
);

-- Allow authenticated users (admins) to update/delete
create policy "Admin Update Access"
on storage.objects for update
using (bucket_id = 'app-9grpozj993pc_app_assets');

create policy "Admin Delete Access"
on storage.objects for delete
using (bucket_id = 'app-9grpozj993pc_app_assets');
