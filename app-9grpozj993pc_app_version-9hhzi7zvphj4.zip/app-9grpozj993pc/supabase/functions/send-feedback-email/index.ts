import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { name, email, message, userProfile } = await req.json();

    // Validate input
    if (!name || !email || !message) {
      return new Response(
        JSON.stringify({ error: 'सभी फ़ील्ड आवश्यक हैं' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Create Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Store feedback in database with user profile
    const { error: dbError } = await supabase.from('feedback').insert({
      name,
      email,
      message,
      user_id: userProfile?.id || null,
      user_profile: userProfile,
      created_at: new Date().toISOString(),
    });

    if (dbError) {
      console.error('Database error:', dbError);
      throw dbError;
    }

    // Get admin email from settings
    const { data: settingsData } = await supabase
      .from('admin_settings')
      .select('setting_value')
      .eq('setting_key', 'about_page')
      .single();

    const adminEmail = settingsData?.setting_value?.contact_email || 'masumboy141@gmail.com';

    // Log feedback details (only admin will receive this)
    console.log('Feedback received for admin:', { 
      name, 
      email, 
      message, 
      adminEmail,
      userProfile,
      note: 'This feedback is ONLY for admin, NOT sent to uploaders or other users'
    });

    // Create a notification for ONLY admins (NOT uploaders)
    // Get ONLY admin user IDs (exclude uploaders)
    const { data: adminUsers } = await supabase
      .from('profiles')
      .select('id')
      .eq('role', 'admin'); // केवल admin role, uploader नहीं

    if (adminUsers && adminUsers.length > 0) {
      // Create compact notification message with "Details" option
      const notificationMessage = `📧 ${email}\n\n💬 ${message}\n\n👉 पूरी जानकारी के लिए "विवरण देखें" पर टैप करें`;
      
      // Store full user profile in metadata for details view
      const notificationMetadata = {
        feedback_details: {
          user_profile: userProfile,
          email: email,
          name: name,
          message: message,
          timestamp: new Date().toISOString()
        }
      };

      // Create notification record
      const { data: notification, error: notifError } = await supabase
        .from('notifications')
        .insert({
          title: `नया फीडबैक: ${name}`,
          message: notificationMessage,
          type: 'system',
          metadata: notificationMetadata,
          created_at: new Date().toISOString(),
        })
        .select()
        .single();

      if (notifError) {
        console.error('Notification creation error:', notifError);
      } else if (notification) {
        // Distribute notification to ALL admins
        const userNotifications = adminUsers.map(admin => ({
          user_id: admin.id,
          notification_id: notification.id,
          read: false,
          created_at: new Date().toISOString(),
        }));

        const { error: distributionError } = await supabase
          .from('user_notifications')
          .insert(userNotifications);

        if (distributionError) {
          console.error('Notification distribution error:', distributionError);
        } else {
          console.log(`Feedback notification sent to ${adminUsers.length} admin(s)`);
        }
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'फीडबैक सफलतापूर्वक भेज दिया गया है। हम जल्द ही आपसे संपर्क करेंगे।' 
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: 'फीडबैक भेजने में त्रुटि हुई' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
