// AI Helper Edge Function for PM - Roit Educational App
// Uses Gemini 1.5 Flash for educational assistance

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ChatMessage {
  role: 'user' | 'model';
  parts: Array<{ text: string }>;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages, systemPrompt } = await req.json();

    if (!messages || !Array.isArray(messages)) {
      return new Response(
        JSON.stringify({ error: 'संदेश आवश्यक हैं' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // format messages for gemini api
    const formattedMessages: ChatMessage[] = messages.map((msg: { role: string; content: string }) => ({
      role: msg.role === 'user' ? 'user' : 'model',
      parts: [{ text: msg.content }],
    }));

    // Call Gemini API via proxy with timeout
    const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');
    const authHeader = req.headers.get('Authorization');
    
    console.log(`AI Function invoked. API Key present: ${!!GEMINI_API_KEY}. Auth present: ${!!authHeader}`);
    if (GEMINI_API_KEY) {
      console.log(`API Key starts with: ${GEMINI_API_KEY.substring(0, 8)}...`);
    }

    // Use the provided proxy URL structure
    const GEMINI_MODEL = "gemini-flash-latest";
    const directUrl = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`;
    const proxyUrl = `https://api-integrations.appmedo.com/app-9grpozj993pc/api-pLVzJnE6NKDL/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`;
    
    console.log(`Calling AI API. Model: ${GEMINI_MODEL}`);

    async function tryFetch(url: string, body: any, timeoutMs: number, headers: Record<string, string> = {}) {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
      
      try {
        const res = await fetch(url, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            ...headers
          },
          body: JSON.stringify(body),
          signal: controller.signal,
        });
        clearTimeout(timeoutId);
        return res;
      } catch (err) {
        clearTimeout(timeoutId);
        throw err;
      }
    }

    try {
      const payload = {
        system_instruction: {
          parts: [{
            text: `You are PM Roit, an expert educational AI assistant for Class 8-12 students in India. 
            
            Rules for response:
            1. Always respond in Hindi unless asked in English.
            2. Use relevant emojis in every answer to make it engaging (e.g., 📚, ✨, 💡, ✅).
            3. Important concepts, formulas, or key definitions MUST be wrapped in markdown blockquotes (starting with > ) so they appear in a clear box.
            4. For complex topics, provide a structured step-by-step explanation.
            5. Use simple text for formulas, avoid complex LaTeX.
            6. Be encouraging and supportive.
            7. If a user says 'refresh', 'reset', or similar, acknowledge that you are starting a fresh session.
            
            Example of important info in a box:
            > 💡 **महत्वपूर्ण सूत्र:**
            > F = m × a
            > जहां F बल है, m द्रव्यमान है, और a त्वरण है।`
          }]
        },
        contents: formattedMessages,
        generationConfig: {
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 2048,
        },
      };

      console.log('Attempting AI API call...');
      
      // Try direct URL first, then proxy
      let response;
      let errorText = '';
      
      try {
        console.log('Trying direct Google API...');
        response = await tryFetch(directUrl, payload, 20000);
      } catch (e) {
        console.warn('Direct API call failed, trying proxy...', e);
      }

      if (!response || !response.ok) {
        if (response) errorText = await response.text();
        console.warn(`Direct API failed (Status: ${response?.status || 'N/A'}). Error: ${errorText}`);
        
        try {
          console.log('Trying Proxy API...');
          response = await tryFetch(proxyUrl, payload, 20000);
        } catch (e) {
          console.error('Proxy API call also failed:', e);
        }
      }

      if (!response || !response.ok) {
        if (response) errorText = await response.text();
        console.error(`AI API Final Error (${response?.status || 'N/A'}):`, errorText);
        
        // Check for specific error types
        let userError = 'AI सेवा अस्थायी रूप से अनुपलब्ध है।';
        if (response.status === 401 || response.status === 403) {
          userError = 'AI सेवा प्रमाणीकरण (Authentication) विफल रहा।';
        } else if (response.status === 429) {
          userError = 'AI सेवा पर बहुत अधिक अनुरोध हैं (Rate limit)। कृपया कुछ देर बाद प्रयास करें।';
        }
        
        return new Response(
          JSON.stringify({ 
            error: userError, 
            details: `Status: ${response.status}`,
            hint: 'कृपया कुछ सेकंड बाद पुनः प्रयास करें या इंटरनेट कनेक्शन जांचें।'
          }),
          { 
            status: response.status >= 500 ? 500 : (response.status || 500), 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        );
      }

      const jsonData = await response.json();
      const fullResponse = jsonData.candidates?.[0]?.content?.parts?.[0]?.text || 'कोई उत्तर नहीं मिला';

      return new Response(
        JSON.stringify({ 
          response: fullResponse,
          success: true 
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    } catch (fetchError: any) {
      if (fetchError.name === 'AbortError') {
        console.error('AI request timeout');
        return new Response(
          JSON.stringify({ 
            error: 'AI सेवा प्रतिक्रिया में बहुत समय ले रही है।',
            hint: 'कृपया पुनः प्रयास करें।'
          }),
          { 
            status: 504, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        );
      }
      
      console.error('Fetch error:', fetchError);
      return new Response(
        JSON.stringify({ error: 'नेटवर्क त्रुटि: AI सेवा से कनेक्ट नहीं हो सका' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

  } catch (error) {
    console.error('Fatal Error in AI Helper:', error);
    return new Response(
      JSON.stringify({ 
        error: 'कुछ गलत हो गया। कृपया पुनः प्रयास करें।',
        details: error instanceof Error ? error.message : 'Unknown error'
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
