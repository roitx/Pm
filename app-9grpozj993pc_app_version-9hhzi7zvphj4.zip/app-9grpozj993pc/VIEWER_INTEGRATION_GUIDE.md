# PDF और Image Viewer - उपयोग स्थान

## अवलोकन
यह ऐप में उन्नत PDF और Image viewer को निम्नलिखित स्थानों पर एकीकृत किया गया है:

## 1. Content Viewer Page
**Route**: `/content/view/:id`

**विवरण**: मुख्य सामग्री देखने का पेज जो स्वचालित रूप से फ़ाइल प्रकार का पता लगाता है

**सुविधाएं**:
- ✅ PDF फ़ाइलों के लिए पूर्ण PDF Viewer
- ✅ इमेज फ़ाइलों के लिए Image Viewer
- ✅ बाहरी लिंक के लिए Embedded Viewer
- ✅ डाउनलोड और बुकमार्क सुविधाएं
- ✅ दैनिक डाउनलोड सीमा ट्रैकिंग

**कैसे पहुंचें**:
- Dashboard से किसी भी सामग्री पर क्लिक करें
- Downloads page से "देखें" बटन
- Recently Viewed page से "देखें" बटन
- Bookmarks page से "देखें" बटन

## 2. External Notes Page
**Route**: `/external-notes`

**विवरण**: बाहरी नोट्स और अध्ययन सामग्री देखने का पेज

**सुविधाएं**:
- ✅ Preview Dialog में PDF Viewer
- ✅ Preview Dialog में Image Viewer
- ✅ फ़िल्टर: कक्षा, विषय, स्रोत, अध्याय
- ✅ खोज सुविधा
- ✅ डाउनलोड बटन

**कैसे उपयोग करें**:
1. External Notes page खोलें
2. फ़िल्टर का उपयोग करके नोट्स खोजें
3. किसी नोट पर "देखें" बटन क्लिक करें
4. Preview Dialog में PDF/Image viewer खुलेगा
5. सभी viewer controls उपलब्ध होंगे

## 3. Downloads Page
**Route**: `/downloads`

**विवरण**: डाउनलोड इतिहास देखने का पेज

**सुविधाएं**:
- ✅ डाउनलोड की गई सभी सामग्री की सूची
- ✅ "देखें" बटन से Content Viewer खुलता है
- ✅ सीधे डाउनलोड बटन
- ✅ कक्षा, विषय, अध्याय की जानकारी

**कैसे उपयोग करें**:
1. Downloads page खोलें
2. किसी भी आइटम पर "देखें" बटन क्लिक करें
3. Content Viewer Page खुलेगा
4. पूर्ण PDF/Image viewer सुविधाएं उपलब्ध होंगी

## 4. Recently Viewed Page
**Route**: `/recently-viewed`

**विवरण**: हाल ही में देखी गई सामग्री का पेज

**सुविधाएं**:
- ✅ हाल ही में देखी गई सभी सामग्री
- ✅ "देखें" बटन से Content Viewer खुलता है
- ✅ समय के अनुसार क्रमबद्ध
- ✅ कक्षा, विषय, अध्याय की जानकारी

**कैसे उपयोग करें**:
1. Recently Viewed page खोलें
2. किसी भी आइटम पर "देखें" बटन क्लिक करें
3. Content Viewer Page खुलेगा
4. पूर्ण PDF/Image viewer सुविधाएं उपलब्ध होंगी

## 5. Bookmarks Page
**Route**: `/bookmarks`

**विवरण**: बुकमार्क की गई सामग्री का पेज

**सुविधाएं**:
- ✅ बुकमार्क की गई सभी सामग्री
- ✅ "देखें" बटन से Content Viewer खुलता है
- ✅ बुकमार्क हटाने का विकल्प
- ✅ कक्षा, विषय, अध्याय की जानकारी

**कैसे उपयोग करें**:
1. Bookmarks page खोलें
2. किसी भी आइटम पर "देखें" बटन क्लिक करें
3. Content Viewer Page खुलेगा
4. पूर्ण PDF/Image viewer सुविधाएं उपलब्ध होंगी

## Viewer Features Comparison

### PDF Viewer
| Feature | Content Viewer | External Notes Preview |
|---------|---------------|----------------------|
| Page Navigation | ✅ | ✅ |
| Zoom Controls | ✅ | ✅ |
| Annotation Tools UI | ✅ | ✅ |
| Download | ✅ | ✅ |
| Print | ✅ | ✅ |
| Rotate | ✅ | ✅ |
| Fullscreen | ✅ | ✅ |
| More Options Menu | ✅ | ✅ |

### Image Viewer
| Feature | Content Viewer | External Notes Preview |
|---------|---------------|----------------------|
| Zoom Controls | ✅ | ✅ |
| Rotate | ✅ | ✅ |
| Fullscreen | ✅ | ✅ |
| Download | ✅ | ✅ |
| Help Overlay | ✅ | ✅ |
| Reset | ✅ | ✅ |

## User Flow Examples

### Example 1: Dashboard से PDF देखना
```
Dashboard → Content Card क्लिक → Content Viewer Page → PDF Viewer
```

### Example 2: External Notes से PDF देखना
```
External Notes → फ़िल्टर लगाएं → "देखें" बटन → Preview Dialog → PDF Viewer
```

### Example 3: Downloads से पुनः देखना
```
Downloads Page → "देखें" बटन → Content Viewer Page → PDF/Image Viewer
```

### Example 4: Recently Viewed से देखना
```
Recently Viewed → "देखें" बटन → Content Viewer Page → PDF/Image Viewer
```

## Technical Details

### Components Used
- **PDFViewer**: `@/components/ui/PDFViewer.tsx`
- **ImageViewer**: `@/components/ui/ImageViewer.tsx`
- **EmbeddedViewer**: `@/components/ui/EmbeddedViewer.tsx`

### File Type Detection
```typescript
// PDF Detection
const isPDF = content.file_type === 'application/pdf' || 
              content.file_url.toLowerCase().endsWith('.pdf');

// Image Detection
const isImage = content.file_type?.startsWith('image/') || 
                /\.(jpg|jpeg|png|gif|webp)$/i.test(content.file_url);

// External Link Detection
const isExternalLink = content.file_type === 'link/external' || 
                       content.file_url.startsWith('http');
```

### Integration Pattern
```typescript
{isPDF ? (
  <PDFViewer url={url} title={title} embedded={true} />
) : isImage ? (
  <ImageViewer src={url} alt={title} open={open} onClose={onClose} />
) : (
  <EmbeddedViewer url={url} title={title} />
)}
```

## Mobile Support
- ✅ सभी viewers मोबाइल-responsive हैं
- ✅ Touch gestures समर्थित
- ✅ Pinch to zoom
- ✅ Swipe navigation
- ✅ Responsive toolbar

## Browser Compatibility
- ✅ Chrome/Edge: पूर्ण समर्थन
- ✅ Firefox: पूर्ण समर्थन
- ✅ Safari: पूर्ण समर्थन
- ✅ Mobile browsers: पूर्ण समर्थन

## Performance
- ✅ Lazy loading
- ✅ Efficient rendering
- ✅ Minimal re-renders
- ✅ Optimized for large files

## Accessibility
- ✅ Keyboard navigation
- ✅ Screen reader support
- ✅ ARIA labels
- ✅ Focus management

## Future Enhancements
- 📝 PDF annotation saving
- 📝 Image editing tools
- 📝 Multi-page image viewer
- 📝 PDF text selection and copy
- 📝 PDF bookmarks and outline
- 📝 Collaborative viewing
- 📝 Comments and notes
