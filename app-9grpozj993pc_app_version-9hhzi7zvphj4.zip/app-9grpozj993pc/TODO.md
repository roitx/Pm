# Task: Fix AI Assistant, PDF Viewer, and Feedback System

## Plan
- [x] Step 1: Fix AI Assistant Responsiveness
  - [x] Investigate `supabase/functions/ai-helper/index.ts` logs
  - [x] Verify API endpoint and key usage
  - [x] Ensure edge function correctly handles streaming and returns valid JSON
- [x] Step 2: Fix PDF Viewer (Exact Match to Image 1)
  - [x] Review `src/components/ui/PDFViewer.tsx`
  - [x] Update UI to match Screenshot_2026-02-03-13-11-49-23.jpg (Image 1)
  - [x] Ensure buttons are inside the viewer area (integrated toolbar)
- [x] Step 3: Fix Feedback System
  - [x] Ensure uploader feedback is only visible to admins
  - [x] Verify `createUploaderFeedback` in `api.ts`
  - [x] Check RLS policies for `uploader_feedback` table
- [x] Step 4: Final Verification
  - [x] Run `npm run lint`
  - [x] Test AI chat, PDF viewing, and feedback submission

## Notes
- AI error in Image 2: "AI सेवा अस्थायी रूप से अनुपलब्ध है" suggests a 500 or timeout.
- PDF Viewer in Image 1 has a very specific custom toolbar.
- Feedback destination needs to be checked.
