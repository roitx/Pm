import { createContext, useContext, useEffect, useState } from 'react';
import type { ReactNode } from 'react';
import { supabase } from '@/db/supabase';
import type { User } from '@supabase/supabase-js';
import type { Profile } from '@/types/types';

export async function getProfile(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();

  if (error) {
    console.error('获取用户信息失败:', error);
    return null;
  }
  return data;
}
interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signInWithUsername: (username: string, password: string) => Promise<{ error: Error | null }>;
  signUpWithUsername: (username: string, password: string, email?: string) => Promise<{ error: Error | null; user: User | null }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshProfile = async () => {
    // Get current session to ensure we have the latest user
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session?.user) {
      setProfile(null);
      return;
    }

    const profileData = await getProfile(session.user.id);
    setProfile(profileData);
  };

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        getProfile(session.user.id).then((profileData) => {
          setProfile(profileData);
          setLoading(false);
        });
      } else {
        setLoading(false);
      }
    });
    // In this function, do NOT use any await calls. Use `.then()` instead to avoid deadlocks.
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        getProfile(session.user.id).then(setProfile);
      } else {
        setProfile(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const signInWithUsername = async (identifier: string, password: string) => {
    try {
      // Detect if identifier is email, phone, or username
      let email = '';
      
      // Check if it's an email
      if (identifier.includes('@')) {
        // First, check if it's a direct auth email (username@miaoda.com)
        if (identifier.endsWith('@miaoda.com')) {
          email = identifier;
        } else {
          // It's a real email - look up in user_email field
          console.log('Looking up user by real email:', identifier);
          const { data: profiles, error: profileError } = await supabase
            .from('profiles')
            .select('email')
            .eq('user_email', identifier)
            .limit(1);
          
          console.log('Email lookup result:', profiles, profileError);
          
          if (profileError) {
            console.error('Email lookup error:', profileError);
            throw new Error('ईमेल से खाता खोजने में त्रुटि');
          }
          
          if (!profiles || profiles.length === 0) {
            throw new Error('इस ईमेल से कोई खाता नहीं मिला');
          }
          
          email = profiles[0].email;
          console.log('Found auth email for user email:', email);
        }
      }
      // Check if it's a phone number (10 digits)
      else if (/^[0-9]{10}$/.test(identifier)) {
        // Find user by phone number
        console.log('Looking up user by phone:', identifier);
        const { data: profiles, error: profileError } = await supabase
          .from('profiles')
          .select('email')
          .eq('phone', identifier)
          .limit(1);
        
        console.log('Phone lookup result:', profiles, profileError);
        
        if (profileError) {
          console.error('Phone lookup error:', profileError);
          throw new Error('फ़ोन नंबर से खाता खोजने में त्रुटि');
        }
        
        if (!profiles || profiles.length === 0) {
          throw new Error('इस फ़ोन नंबर से कोई खाता नहीं मिला');
        }
        
        email = profiles[0].email;
        console.log('Found email for phone:', email);
      }
      // Otherwise, treat as username
      else {
        email = `${identifier}@miaoda.com`;
      }

      console.log('Attempting login with email:', email);
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        console.error('Login error:', error);
        throw error;
      }
      
      console.log('Login successful');
      return { error: null };
    } catch (error) {
      console.error('SignIn error:', error);
      return { error: error as Error };
    }
  };

  const signUpWithUsername = async (username: string, password: string, email?: string) => {
    try {
      const userEmail = email || `${username}@miaoda.com`;
      
      const { data, error } = await supabase.auth.signUp({
        email: userEmail,
        password,
        options: {
          emailRedirectTo: undefined,
          data: {
            username: username,
          }
        }
      });

      if (error) {
        console.error('Supabase signup error:', error);
        throw new Error(error.message || 'साइन अप में त्रुटि');
      }
      
      if (!data.user) {
        throw new Error('उपयोगकर्ता नहीं बना');
      }

      // Check if user was actually created
      if (data.user && !data.session) {
        // User created but no session - this is expected with email confirmation disabled
        console.log('User created:', data.user.id);
      }

      return { error: null, user: data.user };
    } catch (error: any) {
      console.error('Signup error:', error);
      return { error: error as Error, user: null };
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
  };

  return (
    <AuthContext.Provider value={{ user, profile, loading, signInWithUsername, signUpWithUsername, signOut, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
