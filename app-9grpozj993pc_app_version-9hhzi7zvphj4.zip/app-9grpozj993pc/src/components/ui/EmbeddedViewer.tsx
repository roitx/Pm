import * as React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ExternalLink, Loader2 } from 'lucide-react';
import { useState } from 'react';

interface EmbeddedViewerProps {
  url: string;
  title?: string;
  className?: string;
}

/**
 * EmbeddedViewer Component
 * 
 * एम्बेडेड व्यूअर कंपोनेंट - बाहरी लिंक को ऐप में ही iframe में खोलता है
 * Opens external links embedded within the app using iframe
 * 
 * Features:
 * - Embedded iframe display
 * - Loading state
 * - External link button
 * - Responsive design
 * - Error handling
 */
export function EmbeddedViewer({ url, title, className }: EmbeddedViewerProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const getCleanUrl = (rawUrl: string) => {
    if (!rawUrl) return '';
    if (rawUrl.startsWith('http')) {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      if (rawUrl.includes('supabase.co') && supabaseUrl) {
        const urlParts = rawUrl.split('/storage/v1/object/public/');
        if (urlParts.length === 2) {
          return `${supabaseUrl}/storage/v1/object/public/${urlParts[1]}`;
        }
      }
      return rawUrl;
    }
    return rawUrl;
  };

  const cleanUrl = getCleanUrl(url);

  const handleLoad = () => {
    setLoading(false);
  };

  const handleError = () => {
    setLoading(false);
    setError(true);
  };

  const openInNewTab = () => {
    window.open(cleanUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <Card className={`overflow-hidden ${className || ''}`}>
      <div className="p-4 border-b border-border flex items-center justify-between bg-muted/30">
        <div className="flex-1 min-w-0">
          {title && (
            <h3 className="font-semibold truncate">{title}</h3>
          )}
          <p className="text-xs text-muted-foreground truncate">{cleanUrl}</p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={openInNewTab}
          className="ml-4 shrink-0"
        >
          <ExternalLink className="h-4 w-4 mr-2" />
          नए टैब में खोलें
        </Button>
      </div>

      <div className="relative w-full" style={{ height: 'calc(100vh - 200px)', minHeight: '400px' }}>
        {loading && !error && (
          <div className="absolute inset-0 flex items-center justify-center bg-muted/50">
            <div className="text-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">लोड हो रहा है...</p>
            </div>
          </div>
        )}

        {error ? (
          <div className="absolute inset-0 flex items-center justify-center bg-muted/30">
            <div className="text-center p-8">
              <p className="text-lg font-semibold mb-2">⚠️ लोड नहीं हो सका</p>
              <p className="text-sm text-muted-foreground mb-4">
                यह सामग्री एम्बेडेड व्यूअर में नहीं खुल सकती
              </p>
              <Button onClick={openInNewTab} variant="default">
                <ExternalLink className="h-4 w-4 mr-2" />
                नए टैब में खोलें
              </Button>
            </div>
          </div>
        ) : (
          <iframe
            src={cleanUrl}
            title={title || 'Embedded Content'}
            className="w-full h-full border-0"
            onLoad={handleLoad}
            onError={handleError}
            sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            loading="lazy"
          />
        )}
      </div>
    </Card>
  );
}
