// गणित का Σ (Sigma) आइकन - PM Roit (Soft Colors)
export function BookIcon({ className = "w-20 h-20", animate = false }: { className?: string; animate?: boolean }) {
  return (
    <div className={`${className} ${animate ? 'animate-bounce-slow' : ''}`}>
      <svg viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
        {/* ग्रेडिएंट परिभाषाएं - Soft Colors */}
        <defs>
          <linearGradient id="bgGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#93c5fd"/>
            <stop offset="50%" stopColor="#c4b5fd"/>
            <stop offset="100%" stopColor="#f9a8d4"/>
          </linearGradient>
          <linearGradient id="sigmaGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fde68a"/>
            <stop offset="100%" stopColor="#fcd34d"/>
          </linearGradient>
        </defs>
        
        {/* पृष्ठभूमि वृत्त */}
        <circle cx="256" cy="256" r="256" fill="url(#bgGradient)"/>
        
        {/* Σ (Sigma) प्रतीक */}
        <g transform="translate(256, 256)">
          {/* मुख्य Sigma आकार */}
          <path
            d="M -80 -120 L 80 -120 L 80 -90 L -20 -90 L 60 0 L -20 90 L 80 90 L 80 120 L -80 120 L -80 90 L 20 0 L -80 -90 Z"
            fill="url(#sigmaGradient)"
            stroke="#fbbf24"
            strokeWidth="8"
            strokeLinejoin="miter"
            strokeLinecap="square"
          />
          
          {/* आंतरिक चमक */}
          <path
            d="M -60 -100 L 60 -100 L 60 -90 L -10 -90 L 50 0 L -10 90 L 60 90 L 60 100 L -60 100 L -60 90 L 10 0 L -60 -90 Z"
            fill="none"
            stroke="#fffbeb"
            strokeWidth="4"
            opacity="0.7"
          />
        </g>
        
        {/* गणित के प्रतीक - कोनों में */}
        {/* + प्रतीक */}
        <g transform="translate(120, 120)">
          <line x1="-15" y1="0" x2="15" y2="0" stroke="#fffbeb" strokeWidth="6" strokeLinecap="round"/>
          <line x1="0" y1="-15" x2="0" y2="15" stroke="#fffbeb" strokeWidth="6" strokeLinecap="round"/>
        </g>
        
        {/* × प्रतीक */}
        <g transform="translate(392, 120)">
          <line x1="-12" y1="-12" x2="12" y2="12" stroke="#fffbeb" strokeWidth="6" strokeLinecap="round"/>
          <line x1="12" y1="-12" x2="-12" y2="12" stroke="#fffbeb" strokeWidth="6" strokeLinecap="round"/>
        </g>
        
        {/* ÷ प्रतीक */}
        <g transform="translate(120, 392)">
          <circle cx="0" cy="-8" r="4" fill="#fffbeb"/>
          <line x1="-12" y1="0" x2="12" y2="0" stroke="#fffbeb" strokeWidth="5" strokeLinecap="round"/>
          <circle cx="0" cy="8" r="4" fill="#fffbeb"/>
        </g>
        
        {/* = प्रतीक */}
        <g transform="translate(392, 392)">
          <line x1="-12" y1="-5" x2="12" y2="-5" stroke="#fffbeb" strokeWidth="5" strokeLinecap="round"/>
          <line x1="-12" y1="5" x2="12" y2="5" stroke="#fffbeb" strokeWidth="5" strokeLinecap="round"/>
        </g>
      </svg>
    </div>
  );
}
