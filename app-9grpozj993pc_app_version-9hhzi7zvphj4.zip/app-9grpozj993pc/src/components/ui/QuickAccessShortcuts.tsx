import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { 
  BookOpen, 
  Brain, 
  ClipboardList, 
  FileText, 
  Lightbulb,
  Calculator,
  Zap
} from 'lucide-react';

interface Shortcut {
  title: string;
  description: string;
  icon: any;
  path: string;
  color: string;
}

const shortcuts: Shortcut[] = [
  {
    title: 'नोट्स',
    description: 'विस्तृत अध्ययन सामग्री',
    icon: BookOpen,
    path: '/content/notes',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    title: 'AI सहायक',
    description: 'तुरंत प्रश्न पूछें',
    icon: Brain,
    path: '/ai-helper',
    color: 'from-purple-500 to-pink-500',
  },
  {
    title: 'कैलकुलेटर',
    description: 'वैज्ञानिक कैलकुलेटर',
    icon: Calculator,
    path: '/calculator',
    color: 'from-indigo-500 to-purple-500',
  },
  {
    title: 'MCQ टेस्ट',
    description: 'अभ्यास परीक्षण',
    icon: ClipboardList,
    path: '/mcq-test',
    color: 'from-green-500 to-emerald-500',
  },
  {
    title: 'PYQ',
    description: 'पिछले वर्ष के प्रश्न',
    icon: FileText,
    path: '/content/pyq',
    color: 'from-orange-500 to-red-500',
  },
  {
    title: 'महत्वपूर्ण प्रश्न',
    description: 'परीक्षा के लिए जरूरी',
    icon: Lightbulb,
    path: '/content/important_questions',
    color: 'from-yellow-500 to-orange-500',
  },
  {
    title: 'IIT-JEE',
    description: 'उन्नत स्तर के प्रश्न',
    icon: Zap,
    path: '/iit-jee-test',
    color: 'from-red-500 to-pink-500',
  },
];

export function QuickAccessShortcuts() {
  const navigate = useNavigate();

  return (
    <Card className="glass-card border-primary/20">
      <CardContent className="p-4">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Zap className="h-5 w-5 text-primary" />
          त्वरित पहुंच
        </h3>
        <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
          {shortcuts.map((shortcut, index) => {
            const Icon = shortcut.icon;
            return (
              <Button
                key={index}
                variant="outline"
                className="h-auto flex-col gap-2 p-4 hover-glow group"
                onClick={() => navigate(shortcut.path)}
              >
                <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${shortcut.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <div className="text-center">
                  <p className="font-semibold text-sm">{shortcut.title}</p>
                  <p className="text-xs text-muted-foreground">{shortcut.description}</p>
                </div>
              </Button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
