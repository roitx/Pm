import * as React from 'react';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface ManualDateSelectorProps {
  value: string; // Format: YYYY-MM-DD
  onChange: (date: string) => void;
  label?: string;
  required?: boolean;
  disabled?: boolean;
}

export function ManualDateSelector({
  value,
  onChange,
  label = 'जन्म तिथि',
  required = false,
  disabled = false,
}: ManualDateSelectorProps) {
  // Parse existing value
  const [year, month, day] = value ? value.split('-') : ['', '', ''];

  // Generate years (1950 to current year)
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: currentYear - 1949 }, (_, i) => currentYear - i);

  // Month names in Hindi
  const months = [
    { value: '01', label: 'जनवरी' },
    { value: '02', label: 'फरवरी' },
    { value: '03', label: 'मार्च' },
    { value: '04', label: 'अप्रैल' },
    { value: '05', label: 'मई' },
    { value: '06', label: 'जून' },
    { value: '07', label: 'जुलाई' },
    { value: '08', label: 'अगस्त' },
    { value: '09', label: 'सितंबर' },
    { value: '10', label: 'अक्टूबर' },
    { value: '11', label: 'नवंबर' },
    { value: '12', label: 'दिसंबर' },
  ];

  // Generate days (1-31)
  const days = Array.from({ length: 31 }, (_, i) => {
    const dayNum = i + 1;
    return dayNum.toString().padStart(2, '0');
  });

  // Update date when any part changes
  const handleDayChange = (newDay: string) => {
    const currentYear = year || new Date().getFullYear().toString();
    const currentMonth = month || '01';
    onChange(`${currentYear}-${currentMonth}-${newDay}`);
  };

  const handleMonthChange = (newMonth: string) => {
    const currentYear = year || new Date().getFullYear().toString();
    const currentDay = day || '01';
    onChange(`${currentYear}-${newMonth}-${currentDay}`);
  };

  const handleYearChange = (newYear: string) => {
    const currentMonth = month || '01';
    const currentDay = day || '01';
    onChange(`${newYear}-${currentMonth}-${currentDay}`);
  };

  return (
    <div className="space-y-2">
      {label && (
        <Label>
          {label} {required && '*'}
        </Label>
      )}
      <div className="grid grid-cols-3 gap-2">
        {/* Day Selector */}
        <Select value={day} onValueChange={handleDayChange} disabled={disabled}>
          <SelectTrigger>
            <SelectValue placeholder="दिन" />
          </SelectTrigger>
          <SelectContent>
            {days.map((d) => (
              <SelectItem key={d} value={d}>
                {d}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Month Selector */}
        <Select value={month} onValueChange={handleMonthChange} disabled={disabled}>
          <SelectTrigger>
            <SelectValue placeholder="महीना" />
          </SelectTrigger>
          <SelectContent>
            {months.map((m) => (
              <SelectItem key={m.value} value={m.value}>
                {m.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Year Selector */}
        <Select value={year} onValueChange={handleYearChange} disabled={disabled}>
          <SelectTrigger>
            <SelectValue placeholder="वर्ष" />
          </SelectTrigger>
          <SelectContent>
            {years.map((y) => (
              <SelectItem key={y} value={y.toString()}>
                {y}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
