interface BookLogoProps {
  className?: string;
  size?: number;
  vibrant?: boolean; // New prop for extra vibrant colors
}

export function BookLogo({ className = "", size = 40, vibrant = false }: BookLogoProps) {
  // Use more vibrant colors for splash screen
  const bgGradient = vibrant 
    ? { start: "#5B7CFF", mid: "#8B6EDE", end: "#D869F9" }
    : { start: "#6B8CFF", mid: "#9B7EDE", end: "#E879F9" };
  
  const sigmaGradient = vibrant
    ? { start: "#FF9726", end: "#FFB74D" }
    : { start: "#FFA726", end: "#FFB74D" };

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 512 512"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={{ filter: vibrant ? 'saturate(1.3) brightness(1.1)' : undefined }}
    >
      {/* ग्रेडिएंट परिभाषाएं */}
      <defs>
        {/* पृष्ठभूमि ग्रेडिएंट - Blue to Purple to Pink */}
        <linearGradient id={`bgGrad-${vibrant ? 'vibrant' : 'normal'}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={bgGradient.start}/>
          <stop offset="50%" stopColor={bgGradient.mid}/>
          <stop offset="100%" stopColor={bgGradient.end}/>
        </linearGradient>
        
        {/* Sigma ग्रेडिएंट - Orange/Yellow */}
        <linearGradient id={`sigmaGrad-${vibrant ? 'vibrant' : 'normal'}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={sigmaGradient.start}/>
          <stop offset="100%" stopColor={sigmaGradient.end}/>
        </linearGradient>
      </defs>
      
      {/* पृष्ठभूमि सर्कल */}
      <circle cx="256" cy="256" r="256" fill={`url(#bgGrad-${vibrant ? 'vibrant' : 'normal'})`}/>
      
      {/* Sigma प्रतीक (Σ) */}
      <g transform="translate(256, 256)">
        {/* मुख्य Sigma */}
        <path
          d="M -70 -110 L 70 -110 L 70 -80 L -10 -80 L 60 0 L -10 80 L 70 80 L 70 110 L -70 110 L -70 80 L 20 0 L -70 -80 Z"
          fill={`url(#sigmaGrad-${vibrant ? 'vibrant' : 'normal'})`}
          stroke={vibrant ? "#FF8800" : "#FF9800"}
          strokeWidth="5"
          strokeLinejoin="miter"
        />
        
        {/* आंतरिक हाइलाइट */}
        <path
          d="M -50 -95 L 50 -95 L 50 -80 L 0 -80 L 50 0 L 0 80 L 50 80 L 50 95 L -50 95 L -50 80 L 10 0 L -50 -80 Z"
          fill="none"
          stroke="#FFE0B2"
          strokeWidth="3"
          opacity={vibrant ? "0.7" : "0.5"}
        />
      </g>
      
      {/* गणित के चिह्न - Sigma के पास */}
      {/* ऊपर बाएं: Plus (+) */}
      <g transform="translate(160, 140)">
        <text 
          x="0" 
          y="0" 
          fontFamily="Arial, sans-serif" 
          fontSize="42" 
          fontWeight="bold" 
          fill="white" 
          textAnchor="middle" 
          dominantBaseline="central"
          style={{ filter: vibrant ? 'drop-shadow(0 2px 4px rgba(0,0,0,0.3))' : undefined }}
        >
          +
        </text>
      </g>
      
      {/* ऊपर दाएं: Multiply (×) */}
      <g transform="translate(352, 140)">
        <text 
          x="0" 
          y="0" 
          fontFamily="Arial, sans-serif" 
          fontSize="42" 
          fontWeight="bold" 
          fill="white" 
          textAnchor="middle" 
          dominantBaseline="central"
          style={{ filter: vibrant ? 'drop-shadow(0 2px 4px rgba(0,0,0,0.3))' : undefined }}
        >
          ×
        </text>
      </g>
      
      {/* नीचे बाएं: Divide (÷) */}
      <g transform="translate(160, 372)">
        <text 
          x="0" 
          y="0" 
          fontFamily="Arial, sans-serif" 
          fontSize="42" 
          fontWeight="bold" 
          fill="white" 
          textAnchor="middle" 
          dominantBaseline="central"
          style={{ filter: vibrant ? 'drop-shadow(0 2px 4px rgba(0,0,0,0.3))' : undefined }}
        >
          ÷
        </text>
      </g>
      
      {/* नीचे दाएं: Equals (=) */}
      <g transform="translate(352, 372)">
        <text 
          x="0" 
          y="0" 
          fontFamily="Arial, sans-serif" 
          fontSize="42" 
          fontWeight="bold" 
          fill="white" 
          textAnchor="middle" 
          dominantBaseline="central"
          style={{ filter: vibrant ? 'drop-shadow(0 2px 4px rgba(0,0,0,0.3))' : undefined }}
        >
          =
        </text>
      </g>
    </svg>
  );
}
