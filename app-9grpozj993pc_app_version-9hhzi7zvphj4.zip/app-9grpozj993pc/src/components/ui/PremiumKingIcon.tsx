import * as React from 'react';
import { Crown } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PremiumKingIconProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export function PremiumKingIcon({ className, size = 'md' }: PremiumKingIconProps) {
  const sizeClasses = {
    sm: 'h-4 w-4',
    md: 'h-6 w-6',
    lg: 'h-8 w-8',
  };

  return (
    <div className={cn('relative inline-flex items-center justify-center', className)}>
      {/* ग्लो इफेक्ट */}
      <div className="absolute inset-0 bg-gradient-to-br from-yellow-400 via-amber-500 to-orange-500 rounded-full blur-md opacity-60 animate-pulse" />
      
      {/* किंग आइकन */}
      <div className="relative bg-gradient-to-br from-yellow-400 via-amber-500 to-orange-500 rounded-full p-1.5 shadow-lg">
        <Crown className={cn(sizeClasses[size], 'text-white drop-shadow-md')} />
      </div>
    </div>
  );
}
