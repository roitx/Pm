import * as React from 'react';
import { Progress } from '@/components/ui/progress';
import { motion } from 'framer-motion';

interface LoadingAnimationProps {
  progress?: number;
  message?: string;
  className?: string;
}

export function LoadingAnimation({ 
  progress = 0, 
  message = 'लोड हो रहा है...', 
  className = '' 
}: LoadingAnimationProps) {
  return (
    <div className={`flex flex-col items-center justify-center min-h-[400px] ${className}`}>
      {/* Animated Character */}
      <motion.div
        animate={{
          y: [0, -20, 0],
        }}
        transition={{
          duration: 2,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut"
        }}
        className="mb-8"
      >
        <div className="relative w-32 h-32">
          {/* Blue Character Body */}
          <motion.div
            animate={{
              scale: [1, 1.05, 1],
            }}
            transition={{
              duration: 2,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut"
            }}
            className="absolute inset-0 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full"
          />
          
          {/* Character Face */}
          <div className="absolute inset-0 flex items-center justify-center">
            {/* Eyes */}
            <div className="flex gap-4 mb-4">
              <motion.div
                animate={{
                  scaleY: [1, 0.1, 1],
                }}
                transition={{
                  duration: 3,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "easeInOut"
                }}
                className="w-3 h-3 bg-white rounded-full"
              />
              <motion.div
                animate={{
                  scaleY: [1, 0.1, 1],
                }}
                transition={{
                  duration: 3,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "easeInOut",
                  delay: 0.1
                }}
                className="w-3 h-3 bg-white rounded-full"
              />
            </div>
          </div>

          {/* Character Smile */}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
            <div className="w-8 h-4 border-b-2 border-white rounded-full" />
          </div>

          {/* Character Arms */}
          <motion.div
            animate={{
              rotate: [0, 10, 0, -10, 0],
            }}
            transition={{
              duration: 2,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut"
            }}
            className="absolute -left-6 top-1/2 w-12 h-3 bg-gradient-to-r from-blue-500 to-blue-400 rounded-full -rotate-45"
          />
          <motion.div
            animate={{
              rotate: [0, -10, 0, 10, 0],
            }}
            transition={{
              duration: 2,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut"
            }}
            className="absolute -right-6 top-1/2 w-12 h-3 bg-gradient-to-l from-blue-500 to-blue-400 rounded-full rotate-45"
          />

          {/* Character Legs */}
          <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
            <motion.div
              animate={{
                scaleY: [1, 0.8, 1],
              }}
              transition={{
                duration: 2,
                repeat: Number.POSITIVE_INFINITY,
                ease: "easeInOut"
              }}
              className="w-6 h-8 bg-gradient-to-b from-blue-500 to-blue-600 rounded-full"
            />
            <motion.div
              animate={{
                scaleY: [1, 0.8, 1],
              }}
              transition={{
                duration: 2,
                repeat: Number.POSITIVE_INFINITY,
                ease: "easeInOut",
                delay: 0.2
              }}
              className="w-6 h-8 bg-gradient-to-b from-blue-500 to-blue-600 rounded-full"
            />
          </div>
        </div>
      </motion.div>

      {/* Loading Message */}
      <motion.p
        animate={{
          opacity: [0.5, 1, 0.5],
        }}
        transition={{
          duration: 2,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut"
        }}
        className="text-lg font-medium text-foreground mb-4"
      >
        {message}
      </motion.p>

      {/* Progress Bar */}
      {progress > 0 && (
        <div className="w-full max-w-md space-y-2">
          <Progress value={progress} className="h-2" />
          <p className="text-center text-sm text-muted-foreground">
            {Math.round(progress)}%
          </p>
        </div>
      )}

      {/* Loading Dots */}
      {progress === 0 && (
        <div className="flex gap-2 mt-4">
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              animate={{
                scale: [1, 1.5, 1],
                opacity: [0.3, 1, 0.3],
              }}
              transition={{
                duration: 1.5,
                repeat: Number.POSITIVE_INFINITY,
                ease: "easeInOut",
                delay: i * 0.2
              }}
              className="w-2 h-2 bg-primary rounded-full"
            />
          ))}
        </div>
      )}
    </div>
  );
}
