import * as React from 'react';
import { useState, useRef, useEffect } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { 
  X, 
  ZoomIn, 
  ZoomOut, 
  RotateCw, 
  RotateCcw,
  Download, 
  Maximize2, 
  Minimize2, 
  Loader2,
  Printer,
  Save,
  ExternalLink,
  MoreVertical,
  Hand,
  MousePointer,
  ChevronsUp,
  ChevronsDown,
  Pencil,
  Type,
  Eraser,
  Palette,
  Share2,
  FlipHorizontal,
  FlipVertical
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { Separator } from '@/components/ui/separator';

interface ImageViewerProps {
  src: string;
  alt?: string;
  open: boolean;
  onClose: () => void;
}

export function ImageViewer({ src, alt = 'Image', open, onClose }: ImageViewerProps) {
  const [zoom, setZoom] = useState(100);
  const [rotation, setRotation] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [cursorMode, setCursorMode] = useState<'pointer' | 'hand'>('pointer');
  const [flipHorizontal, setFlipHorizontal] = useState(false);
  const [flipVertical, setFlipVertical] = useState(false);
  const [drawingMode, setDrawingMode] = useState(false);
  const [textMode, setTextMode] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  const getCleanUrl = (rawUrl: string) => {
    if (!rawUrl) return '';
    const trimmedUrl = rawUrl.trim();
    if (trimmedUrl.startsWith('http')) {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      if (trimmedUrl.includes('supabase.co') && supabaseUrl) {
        // If it already uses the correct domain, don't touch it
        if (trimmedUrl.startsWith(supabaseUrl)) return trimmedUrl;

        const urlParts = trimmedUrl.split('/storage/v1/object/public/');
        if (urlParts.length === 2) {
          // Rebuild with current project's domain
          return `${supabaseUrl}/storage/v1/object/public/${urlParts[1]}`;
        }
      }
      return trimmedUrl;
    }
    return trimmedUrl;
  };

  const cleanUrl = getCleanUrl(src);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    
    // Reset image loaded state when src changes
    setImageLoaded(false);
    
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, [src, open]);

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 25, 300));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 25, 50));
  };

  const handleRotateClockwise = () => {
    setRotation(prev => (prev + 90) % 360);
  };

  const handleRotateCounterclockwise = () => {
    setRotation(prev => (prev - 90 + 360) % 360);
  };

  const handleFullscreen = async () => {
    if (!document.fullscreenElement && containerRef.current) {
      try {
        await containerRef.current.requestFullscreen();
      } catch (err) {
        console.error('Fullscreen error:', err);
      }
    } else if (document.fullscreenElement) {
      await document.exitFullscreen();
    }
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = cleanUrl;
    link.download = alt || 'image';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: 'डाउनलोड शुरू',
      description: 'इमेज डाउनलोड हो रही है...',
    });
  };

  const handleSave = () => {
    handleDownload();
  };

  const handlePrint = () => {
    window.open(cleanUrl, '_blank');
    toast({
      title: 'प्रिंट',
      description: 'नई टैब में खोलें और प्रिंट करें',
    });
  };

  const handleOpenInNewTab = () => {
    window.open(cleanUrl, '_blank');
  };

  const toggleCursorMode = () => {
    setCursorMode(prev => prev === 'pointer' ? 'hand' : 'pointer');
  };

  const handleClose = () => {
    if (document.fullscreenElement) {
      document.exitFullscreen();
    }
    setZoom(100);
    setRotation(0);
    setFlipHorizontal(false);
    setFlipVertical(false);
    setDrawingMode(false);
    setTextMode(false);
    onClose();
  };

  const handleReset = () => {
    setZoom(100);
    setRotation(0);
    setFlipHorizontal(false);
    setFlipVertical(false);
  };

  const handleFlipHorizontal = () => {
    setFlipHorizontal(!flipHorizontal);
  };

  const handleFlipVertical = () => {
    setFlipVertical(!flipVertical);
  };

  const toggleDrawingMode = () => {
    setDrawingMode(!drawingMode);
    setTextMode(false);
  };

  const toggleTextMode = () => {
    setTextMode(!textMode);
    setDrawingMode(false);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: alt || 'इमेज',
        url: cleanUrl,
      }).catch(err => console.error('Share error:', err));
    } else {
      navigator.clipboard.writeText(cleanUrl);
      toast({
        title: 'लिंक कॉपी किया गया',
        description: 'इमेज लिंक क्लिपबोर्ड में कॉपी किया गया',
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent 
        ref={containerRef}
        className="max-w-[95vw] max-h-[95vh] p-0 overflow-hidden bg-black/95"
      >
        {/* Toolbar - Always visible with high z-index */}
        <div className="absolute top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-md border-b border-border p-3 shadow-md">
          <div className="flex items-center justify-between gap-2">
            {/* Left/Center: Zoom Controls */}
            <div className="flex items-center gap-1 bg-muted rounded-lg p-1 border border-border">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleZoomOut}
                disabled={zoom <= 50}
                title="ज़ूम आउट"
                className="h-8 w-8 hover:bg-accent"
              >
                <ZoomOut className="h-4 w-4" />
              </Button>
              <span className="text-sm font-bold min-w-[50px] text-center px-2">
                {zoom}%
              </span>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleZoomIn}
                disabled={zoom >= 300}
                title="ज़ूम इन"
                className="h-8 w-8 hover:bg-accent"
              >
                <ZoomIn className="h-4 w-4" />
              </Button>
            </div>

            {/* Right Controls */}
            <div className="flex items-center gap-2">
              <Button
                variant="secondary"
                size="sm"
                onClick={handleReset}
                title="रीसेट करें"
                className="h-8 px-3 bg-muted hover:bg-accent border border-border"
              >
                रीसेट
              </Button>
              <Button
                variant="secondary"
                size="icon"
                onClick={handleFullscreen}
                title={isFullscreen ? 'फुलस्क्रीन से बाहर निकलें' : 'फुलस्क्रीन'}
                className="h-8 w-8 bg-muted hover:bg-accent border border-border"
              >
                {isFullscreen ? (
                  <Minimize2 className="h-4 w-4" />
                ) : (
                  <Maximize2 className="h-4 w-4" />
                )}
              </Button>
              <Button
                variant="default"
                size="icon"
                onClick={handleDownload}
                title="डाउनलोड करें"
                className="h-8 w-8"
              >
                <Download className="h-4 w-4" />
              </Button>

              <Button
                variant="destructive"
                size="icon"
                onClick={handleClose}
                title="बंद करें"
                className="h-8 w-8 ml-2 shadow-md"
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Image Container */}
        <div 
          className="w-full h-[calc(95vh-60px)] mt-[60px] flex items-center justify-center overflow-auto bg-muted/20 relative"
          style={{
            cursor: cursorMode === 'hand' ? 'grab' : drawingMode ? 'crosshair' : 'default',
          }}
        >
          {!imageLoaded && (
            <div className="absolute inset-0 flex items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          )}
          <img
            src={cleanUrl}
            alt={alt}
            onLoad={() => setImageLoaded(true)}
            onError={() => {
              setImageLoaded(true);
              toast({
                title: 'त्रुटि',
                description: 'इमेज लोड करने में विफल',
                variant: 'destructive',
              });
            }}
            className={`max-w-full max-h-full object-contain transition-all duration-300 ${!imageLoaded ? 'opacity-0' : 'opacity-100'}`}
            style={{
              transform: `scale(${zoom / 100}) rotate(${rotation}deg) scaleX(${flipHorizontal ? -1 : 1}) scaleY(${flipVertical ? -1 : 1})`,
            }}
            loading="eager"
          />

          {/* Drawing Canvas Overlay (when drawing mode is active) */}
          {drawingMode && (
            <canvas
              ref={canvasRef}
              className="absolute inset-0 w-full h-full cursor-crosshair z-20"
              style={{ pointerEvents: 'auto' }}
            />
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
