import * as React from 'react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Smile } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

interface EmojiPickerProps {
  onEmojiSelect: (emoji: string) => void;
}

// इमोजी की श्रेणियां
const EMOJI_CATEGORIES = {
  'स्माइली': ['😀', '😃', '😄', '😁', '😅', '😂', '🤣', '😊', '😇', '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚', '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🤩', '🥳'],
  'हाथ': ['👍', '👎', '👌', '✌️', '🤞', '🤟', '🤘', '🤙', '👈', '👉', '👆', '👇', '☝️', '✋', '🤚', '🖐️', '🖖', '👋', '🤝', '🙏', '💪', '🦾', '✍️', '👏', '🙌'],
  'दिल': ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '❣️', '💕', '💞', '💓', '💗', '💖', '💘', '💝'],
  'प्रतीक': ['✅', '❌', '⭐', '🌟', '✨', '💫', '🔥', '💯', '🎯', '🎓', '📚', '📖', '📝', '✏️', '📊', '📈', '🏆', '🥇', '🥈', '🥉', '🎉', '🎊', '🎈'],
  'विज्ञान': ['🔬', '🧪', '🧬', '🔭', '⚗️', '🧮', '📐', '📏', '🔢', '➕', '➖', '✖️', '➗', '🟰', '💡', '🔋', '⚡', '🌍', '🌎', '🌏', '🪐', '🌙', '⭐'],
};

export function EmojiPicker({ onEmojiSelect }: EmojiPickerProps) {
  const [open, setOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('स्माइली');

  const handleEmojiClick = (emoji: string) => {
    onEmojiSelect(emoji);
    setOpen(false);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="h-9 w-9 shrink-0"
          type="button"
          title="इमोजी जोड़ें"
        >
          <Smile className="h-4 w-4" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="flex flex-col h-[320px]">
          {/* श्रेणी टैब */}
          <div className="flex gap-1 p-2 border-b overflow-x-auto">
            {Object.keys(EMOJI_CATEGORIES).map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="text-xs shrink-0"
              >
                {category}
              </Button>
            ))}
          </div>

          {/* इमोजी ग्रिड */}
          <ScrollArea className="flex-1 p-2">
            <div className="grid grid-cols-8 gap-1">
              {EMOJI_CATEGORIES[selectedCategory as keyof typeof EMOJI_CATEGORIES].map((emoji, index) => (
                <button
                  key={`${emoji}-${index}`}
                  onClick={() => handleEmojiClick(emoji)}
                  className="text-2xl hover:bg-muted rounded p-1 transition-colors"
                  type="button"
                  title={emoji}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </ScrollArea>
        </div>
      </PopoverContent>
    </Popover>
  );
}
