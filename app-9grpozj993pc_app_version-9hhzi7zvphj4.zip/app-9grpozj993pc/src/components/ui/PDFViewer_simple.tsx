import * as React from 'react';
import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { 
  FileText, 
  Download,
  ExternalLink,
  Loader2,
  AlertCircle
} from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface PDFViewerProps {
  url: string;
  title?: string;
  embedded?: boolean;
}

export function PDFViewer({ url, title, embedded = true }: PDFViewerProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    setLoading(true);
    setError(false);
  }, [url]);

  const handleLoad = () => {
    setLoading(false);
    setError(false);
  };

  const handleError = () => {
    setLoading(false);
    setError(true);
    toast({
      title: 'त्रुटि',
      description: 'PDF लोड करने में समस्या हुई',
      variant: 'destructive',
    });
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = url;
    link.download = title || 'document.pdf';
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: 'डाउनलोड शुरू हुआ',
      description: 'आपकी फ़ाइल डाउनलोड हो रही है',
    });
  };

  const handleOpenInNewTab = () => {
    window.open(url, '_blank');
    toast({
      title: 'नई टैब में खुला',
      description: 'PDF नई टैब में खोल दिया गया है',
    });
  };

  return (
    <div className={embedded ? "flex flex-col h-[70vh] overflow-hidden border rounded-lg bg-card" : "fixed inset-0 z-50 bg-background flex flex-col"}>
      {/* Simple Header with Title and Actions */}
      <div className="border-b shrink-0 p-3 bg-muted/30">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <FileText className="h-5 w-5 text-primary shrink-0" />
            <h3 className="font-semibold truncate text-sm xl:text-base">
              {title || 'PDF दस्तावेज़'}
            </h3>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Button
              variant="outline"
              size="sm"
              onClick={handleOpenInNewTab}
              className="h-8"
              title="नई टैब में खोलें"
            >
              <ExternalLink className="h-4 w-4 xl:mr-2" />
              <span className="hidden xl:inline">नई टैब में खोलें</span>
            </Button>
            <Button
              variant="default"
              size="sm"
              onClick={handleDownload}
              className="h-8 bg-primary hover:bg-primary/90"
              title="डाउनलोड करें"
            >
              <Download className="h-4 w-4 xl:mr-2" />
              <span className="hidden xl:inline">डाउनलोड करें</span>
            </Button>
          </div>
        </div>
      </div>

      {/* PDF Content Area - iframe has built-in controls */}
      <div className="flex-1 relative bg-muted/20">
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/80 z-10">
            <div className="flex flex-col items-center gap-3">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">PDF लोड हो रहा है...</p>
            </div>
          </div>
        )}

        {error ? (
          <div className="absolute inset-0 flex items-center justify-center p-4">
            <Alert variant="destructive" className="max-w-md">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription className="ml-2">
                PDF लोड करने में समस्या हुई। कृपया नई टैब में खोलें या डाउनलोड करें।
              </AlertDescription>
            </Alert>
          </div>
        ) : (
          <iframe
            ref={iframeRef}
            src={url}
            className="w-full h-full border-0"
            title={title || 'PDF Viewer'}
            onLoad={handleLoad}
            onError={handleError}
            sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
          />
        )}
      </div>
    </div>
  );
}
