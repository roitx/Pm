import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Sparkles, Zap, BookOpen } from 'lucide-react';
import { BookLogo } from '@/components/ui/BookLogo';

export function WelcomeAnimation() {
  const [show, setShow] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    const hasSeenWelcome = localStorage.getItem('has-seen-welcome');
    if (!hasSeenWelcome) {
      setShow(true);
      const timer = setInterval(() => {
        setStep(prev => {
          if (prev >= 3) {
            clearInterval(timer);
            return prev;
          }
          return prev + 1;
        });
      }, 2000);
      return () => clearInterval(timer);
    }
  }, []);

  const handleComplete = () => {
    localStorage.setItem('has-seen-welcome', 'true');
    setShow(false);
  };

  if (!show) return null;

  const features = [
    {
      icon: BookOpen,
      title: 'विस्तृत अध्ययन सामग्री',
      description: 'नोट्स, PYQ, महत्वपूर्ण प्रश्न और बहुत कुछ',
      color: 'from-blue-500 to-cyan-500',
    },
    {
      icon: Zap,
      title: 'AI सहायक',
      description: 'तुरंत अपने सवालों के जवाब पाएं',
      color: 'from-purple-500 to-pink-500',
    },
    {
      icon: Sparkles,
      title: 'MCQ और टेस्ट',
      description: 'अभ्यास करें और अपनी तैयारी जांचें',
      color: 'from-green-500 to-emerald-500',
    },
  ];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-background/95 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      >
        <Card className="max-w-md w-full glass-card border-2 border-primary/50">
          <CardContent className="p-8 text-center space-y-6">
            {/* Logo - Sigma Icon */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', duration: 0.8 }}
              className="w-24 h-24 mx-auto"
            >
              <BookLogo size={96} vibrant={true} />
            </motion.div>

            {/* Title */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <h1 className="text-3xl font-bold gradient-text mb-2">
                PM - Roit में आपका स्वागत है!
              </h1>
              <p className="text-muted-foreground">
                Class 8-12 के लिए संपूर्ण अध्ययन मंच
              </p>
            </motion.div>

            {/* Features */}
            <div className="space-y-4">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ 
                      opacity: step >= index ? 1 : 0.3,
                      x: step >= index ? 0 : -20,
                      scale: step === index ? 1.05 : 1,
                    }}
                    transition={{ delay: index * 0.2 }}
                    className="flex items-center gap-4 p-4 rounded-lg bg-muted/30"
                  >
                    <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${feature.color} flex items-center justify-center shrink-0`}>
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <div className="text-left">
                      <h3 className="font-semibold">{feature.title}</h3>
                      <p className="text-sm text-muted-foreground">{feature.description}</p>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Button */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: step >= 3 ? 1 : 0 }}
              transition={{ delay: 2 }}
            >
              <Button
                onClick={handleComplete}
                className="w-full bg-gradient-to-r from-primary to-secondary"
                disabled={step < 3}
              >
                शुरू करें
              </Button>
            </motion.div>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}
