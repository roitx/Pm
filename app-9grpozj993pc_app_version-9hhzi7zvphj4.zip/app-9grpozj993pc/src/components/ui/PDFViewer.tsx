import * as React from 'react';
import { useState, useRef, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Download,
  Loader2,
  FileText,
  Search,
  ZoomIn,
  ZoomOut,
  ChevronLeft,
  ChevronRight,
  RotateCw,
  RotateCcw,
  Printer,
  ChevronsRight,
  Pencil,
  Type,
  Highlighter,
  Image as ImageIcon,
  MousePointer2,
  Hand,
  X,
  Maximize2,
  ArrowUpToLine,
  ArrowDownToLine,
  Layout,
  Columns,
  Rows,
  Save,
  MonitorPlay,
  Eye,
  Menu
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { Document, Page, pdfjs } from 'react-pdf';
import 'react-pdf/dist/esm/Page/AnnotationLayer.css';
import 'react-pdf/dist/esm/Page/TextLayer.css';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';

// Set up the worker for react-pdf
// Use a fixed version to avoid mismatches
pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@3.11.174/build/pdf.worker.min.js`;

interface PDFViewerProps {
  url: string;
  title?: string;
  subtitle?: string;
  onClose?: () => void;
  onDownload?: () => void;
}

export function PDFViewer({ url, title, subtitle, onClose, onDownload }: PDFViewerProps) {
  const [numPages, setNumPages] = useState<number | null>(null);
  const [pageNumber, setPageNumber] = useState(1);
  const [scale, setScale] = useState(1.0);
  const [rotation, setRotation] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [layoutMode, setLayoutMode] = useState<'single' | 'scroll'>('scroll');
  const [cursorMode, setCursorMode] = useState<'select' | 'hand'>('select');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [inputPage, setInputPage] = useState("1");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  const containerRef = useRef<HTMLDivElement>(null);
  const viewerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const [pageWidth, setPageWidth] = useState<number>(800);

  const getCleanUrl = (rawUrl: string) => {
    if (!rawUrl) return '';
    const trimmedUrl = rawUrl.trim();
    if (trimmedUrl.startsWith('http')) {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      if (trimmedUrl.includes('supabase.co') && supabaseUrl) {
        if (trimmedUrl.startsWith(supabaseUrl)) return trimmedUrl;
        const urlParts = trimmedUrl.split('/storage/v1/object/public/');
        if (urlParts.length === 2) {
          return `${supabaseUrl}/storage/v1/object/public/${urlParts[1]}`;
        }
      }
      return trimmedUrl;
    }
    return trimmedUrl;
  };

  const cleanUrl = getCleanUrl(url);

  const updateWidth = useCallback(() => {
    if (viewerRef.current) {
      const width = viewerRef.current.clientWidth - 40;
      setPageWidth(Math.min(width, 1000)); // Max width for better readability
    }
  }, []);

  useEffect(() => {
    updateWidth();
    window.addEventListener('resize', updateWidth);
    return () => window.removeEventListener('resize', updateWidth);
  }, [updateWidth]);

  useEffect(() => {
    setInputPage(pageNumber.toString());
  }, [pageNumber]);

  function onDocumentLoadSuccess({ numPages }: { numPages: number }) {
    setNumPages(numPages);
    setLoading(false);
  }

  function onDocumentLoadError(err: Error) {
    console.error('PDF load error:', err);
    setError(true);
    setLoading(false);
    toast({
      title: 'त्रुटि',
      description: 'PDF लोड करने में विफल।',
      variant: 'destructive',
    });
  }

  const handlePageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const page = parseInt(inputPage);
    if (page >= 1 && page <= (numPages || 1)) {
      setPageNumber(page);
      if (layoutMode === 'scroll') {
        const pageElement = document.getElementById(`pdf-page-${page}`);
        if (pageElement) {
          pageElement.scrollIntoView({ behavior: 'smooth' });
        }
      }
    } else {
      setInputPage(pageNumber.toString());
    }
  };

  const handleDownload = () => {
    if (onDownload) {
      onDownload();
      return;
    }
    const link = document.createElement('a');
    link.href = cleanUrl;
    link.download = title || 'document.pdf';
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    const printWindow = window.open(cleanUrl, '_blank');
    if (printWindow) {
      printWindow.addEventListener('load', () => {
        printWindow.print();
      });
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(err => {
        toast({ title: 'त्रुटि', description: 'फुलस्क्रीन मोड उपलब्ध नहीं है' });
      });
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false));
    }
  };

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    if (layoutMode !== 'scroll' || !numPages) return;
    const container = e.currentTarget;
    const scrollPos = container.scrollTop + container.clientHeight / 3;
    
    // Find which page is currently mostly visible
    for (let i = 1; i <= numPages; i++) {
      const pageEl = document.getElementById(`pdf-page-${i}`);
      if (pageEl && pageEl.offsetTop <= scrollPos && (pageEl.offsetTop + pageEl.offsetHeight) > scrollPos) {
        if (pageNumber !== i) setPageNumber(i);
        break;
      }
    }
  };

  return (
    <div className="flex flex-col w-full h-full bg-[#f8f9fa] overflow-hidden fixed inset-0 z-[100]" ref={containerRef}>
      {/* Header - Top Bar */}
      <div className="bg-white px-4 py-3 flex items-center justify-between border-b border-gray-200 shadow-sm z-30">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={onClose} className="md:hidden">
             <ChevronLeft className="h-6 w-6" />
          </Button>
          <div className="hidden md:flex bg-blue-100 p-2 rounded-lg">
            <FileText className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-base md:text-lg font-bold text-gray-800 line-clamp-1">
              {title || 'Document'}
            </h1>
            {subtitle && (
              <p className="text-xs md:text-sm text-gray-500 line-clamp-1">
                {subtitle}
              </p>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            onClick={handleDownload}
            className="bg-[#3b82f6] hover:bg-[#2563eb] text-white font-medium"
          >
            <Download className="mr-2 h-4 w-4" />
            डाउनलोड करें
          </Button>
          {onClose && (
            <Button variant="ghost" size="icon" onClick={onClose} className="text-gray-500 hover:bg-gray-100 hidden md:flex">
              <X className="h-6 w-6" />
            </Button>
          )}
        </div>
      </div>

      {/* Secondary Toolbar - Tools & Navigation */}
      <div className="bg-white px-4 py-2 flex items-center justify-between border-b border-gray-200 z-20 overflow-x-auto no-scrollbar gap-4">
        
        {/* Left: Page Navigation */}
        <div className="flex items-center gap-1 border-r border-gray-200 pr-4">
          <Button 
            variant="ghost" 
            size="icon" 
            disabled={pageNumber <= 1}
            onClick={() => {
              const newPage = Math.max(pageNumber - 1, 1);
              setPageNumber(newPage);
              if (layoutMode === 'scroll') document.getElementById(`pdf-page-${newPage}`)?.scrollIntoView();
            }}
            className="h-8 w-8 text-gray-600"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <form onSubmit={handlePageSubmit} className="flex items-center gap-2">
            <Input 
              value={inputPage}
              onChange={(e) => setInputPage(e.target.value)}
              className="h-8 w-12 text-center p-0 text-sm border-gray-300"
            />
            <span className="text-sm text-gray-600 whitespace-nowrap">of {numPages || '--'}</span>
          </form>
          <Button 
            variant="ghost" 
            size="icon" 
            disabled={pageNumber >= (numPages || 1)}
            onClick={() => {
              const newPage = Math.min(pageNumber + 1, numPages || 1);
              setPageNumber(newPage);
              if (layoutMode === 'scroll') document.getElementById(`pdf-page-${newPage}`)?.scrollIntoView();
            }}
            className="h-8 w-8 text-gray-600"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        {/* Center: Zoom & Tools */}
        <div className="flex items-center gap-2 flex-1 justify-center min-w-[200px]">
          <div className="flex items-center bg-gray-100 rounded-md p-0.5">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setScale(prev => Math.max(prev - 0.1, 0.3))}
              className="h-7 w-7 text-gray-600 hover:bg-white rounded-sm"
            >
              <ZoomOut className="h-3.5 w-3.5" />
            </Button>
            <span className="w-12 text-center text-xs font-medium text-gray-700 select-none">
              {Math.round(scale * 100)}%
            </span>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setScale(prev => Math.min(prev + 0.1, 5.0))}
              className="h-7 w-7 text-gray-600 hover:bg-white rounded-sm"
            >
              <ZoomIn className="h-3.5 w-3.5" />
            </Button>
          </div>
          
          <div className="hidden md:flex items-center gap-1 border-l border-gray-200 pl-4 ml-2">
            <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:text-gray-900" title="Pencil">
              <Pencil className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:text-gray-900" title="Text">
              <Type className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:text-gray-900" title="Highlight">
              <Highlighter className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:text-gray-900" title="Image">
              <ImageIcon className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Right: Menu */}
        <div className="flex items-center gap-2 border-l border-gray-200 pl-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="secondary" size="icon" className="h-8 w-8 bg-gray-200 hover:bg-gray-300 text-gray-700">
                <ChevronsRight className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-64">
              <DropdownMenuItem onClick={() => window.open(cleanUrl, '_blank')}>
                <FileText className="mr-2 h-4 w-4" /> Open
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handlePrint}>
                <Printer className="mr-2 h-4 w-4" /> Print
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleDownload}>
                <Save className="mr-2 h-4 w-4" /> Save
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={toggleFullscreen}>
                <MonitorPlay className="mr-2 h-4 w-4" /> Presentation Mode
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => {
                if(layoutMode === 'scroll') {
                   document.getElementById(`pdf-page-${pageNumber}`)?.scrollIntoView();
                }
              }}>
                <Eye className="mr-2 h-4 w-4" /> Current Page
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => {
                setPageNumber(1);
                if (layoutMode === 'scroll') document.getElementById('pdf-page-1')?.scrollIntoView();
              }}>
                <ArrowUpToLine className="mr-2 h-4 w-4" /> Go to First Page
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => {
                if (!numPages) return;
                setPageNumber(numPages);
                if (layoutMode === 'scroll') document.getElementById(`pdf-page-${numPages}`)?.scrollIntoView();
              }}>
                <ArrowDownToLine className="mr-2 h-4 w-4" /> Go to Last Page
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setRotation(prev => (prev + 90) % 360)}>
                <RotateCw className="mr-2 h-4 w-4" /> Rotate Clockwise
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setRotation(prev => (prev - 90 + 360) % 360)}>
                <RotateCcw className="mr-2 h-4 w-4" /> Rotate Counterclockwise
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setCursorMode('select')} className={cn(cursorMode === 'select' && "bg-accent")}>
                <MousePointer2 className="mr-2 h-4 w-4" /> Text Selection Tool
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setCursorMode('hand')} className={cn(cursorMode === 'hand' && "bg-accent")}>
                <Hand className="mr-2 h-4 w-4" /> Hand Tool
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setLayoutMode('scroll')} className={cn(layoutMode === 'scroll' && "bg-accent")}>
                <Columns className="mr-2 h-4 w-4" /> Page Scrolling
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setLayoutMode('single')} className={cn(layoutMode === 'single' && "bg-accent")}>
                <Rows className="mr-2 h-4 w-4" /> Vertical Scrolling
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Main Content Area */}
      <div 
        className={cn(
          "flex-1 overflow-auto flex justify-center bg-[#525659] p-4 relative",
          cursorMode === 'hand' && "cursor-grab active:cursor-grabbing"
        )}
        onScroll={handleScroll}
        ref={viewerRef}
      >
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center bg-white z-50">
            <div className="text-center">
              <Loader2 className="h-10 w-10 animate-spin text-primary mx-auto mb-4" />
              <p className="text-gray-500 font-medium">Loading Document...</p>
            </div>
          </div>
        )}
        
        {error && (
          <div className="absolute inset-0 flex items-center justify-center z-40">
            <div className="bg-white p-6 rounded-lg shadow-lg text-center max-w-md mx-4">
              <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="h-8 w-8 text-red-600" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">PDF लोड करने में विफल</h3>
              <p className="text-gray-600 mb-6">
                यह फ़ाइल शायद भ्रष्ट है या सही फॉर्मेट में नहीं है। आप इसे डाउनलोड करके देख सकते हैं।
              </p>
              <div className="flex gap-3 justify-center">
                <Button variant="outline" onClick={onClose}>
                  बंद करें
                </Button>
                <Button onClick={handleDownload}>
                  डाउनलोड करें
                </Button>
              </div>
            </div>
          </div>
        )}

        {!error && (
          <Document
            file={cleanUrl}
            onLoadSuccess={onDocumentLoadSuccess}
            onLoadError={onDocumentLoadError}
            loading={null}
            className="flex flex-col items-center gap-4"
          >
            {layoutMode === 'single' ? (
              <div className="relative shadow-2xl">
                <Page 
                  pageNumber={pageNumber} 
                  scale={scale} 
                  rotate={rotation}
                  width={pageWidth}
                  renderAnnotationLayer={true}
                  renderTextLayer={true}
                  className="bg-white"
                />
              </div>
            ) : (
              Array.from(new Array(numPages), (el, index) => (
                <div 
                  key={`page_${index + 1}`} 
                  id={`pdf-page-${index + 1}`}
                  className="relative shadow-2xl mb-4"
                >
                  <Page 
                    pageNumber={index + 1} 
                    scale={scale} 
                    rotate={rotation}
                    width={pageWidth}
                    renderAnnotationLayer={true}
                    renderTextLayer={true}
                    className="bg-white"
                  />
                </div>
              ))
            )}
          </Document>
        )}
      </div>
    </div>
  );
}
