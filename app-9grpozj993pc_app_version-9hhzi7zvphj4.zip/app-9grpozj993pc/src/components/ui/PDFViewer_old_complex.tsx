import * as React from 'react';
import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Download,
  Loader2,
  FileText,
  ExternalLink,
  Printer,
  Save,
  MoreVertical,
  RotateCw,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  ChevronLeft,
  ChevronRight,
  Search,
  Pencil,
  Type,
  Image as ImageIcon,
  X,
  Maximize2,
  Minimize2,
  Hand,
  MousePointer,
  Eraser,
  Palette,
  Share2,
  Monitor,
  ArrowUpToLine,
  ArrowDownToLine,
  ScrollText,
  AlignVerticalSpaceAround,
  ChevronsRight
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

interface PDFViewerProps {
  url: string;
  title?: string;
  subtitle?: string;
  onClose?: () => void;
  onDownload?: () => void;
  embedded?: boolean;
}

export function PDFViewer({ url, title, subtitle, onClose, onDownload, embedded = true }: PDFViewerProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [useGoogleViewer, setUseGoogleViewer] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [zoom, setZoom] = useState(100);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(2);
  const [pageInput, setPageInput] = useState('1');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [presentationMode, setPresentationMode] = useState(false);
  const [drawingMode, setDrawingMode] = useState(false);
  const [textMode, setTextMode] = useState(false);
  const [handTool, setHandTool] = useState(false);
  const [textSelection, setTextSelection] = useState(true);
  const [searchMode, setSearchMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [scrollMode, setScrollMode] = useState<'page' | 'vertical'>('vertical');
  const containerRef = useRef<HTMLDivElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  const getCleanUrl = (rawUrl: string) => {
    if (!rawUrl) return '';
    // If it's already a full URL, return it
    if (rawUrl.startsWith('http')) {
      // If it's an old Supabase URL, try to update it to current one
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      if (rawUrl.includes('supabase.co') && supabaseUrl) {
        const urlParts = rawUrl.split('/storage/v1/object/public/');
        if (urlParts.length === 2) {
          return `${supabaseUrl}/storage/v1/object/public/${urlParts[1]}`;
        }
      }
      return rawUrl;
    }
    return rawUrl;
  };

  const cleanUrl = getCleanUrl(url);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = cleanUrl;
    link.download = title || 'document.pdf';
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: 'डाउनलोड शुरू',
      description: 'फ़ाइल डाउनलोड हो रही है...',
    });
  };

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 25, 300));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 25, 50));
  };

  const handleRotateClockwise = () => {
    setRotation(prev => (prev + 90) % 360);
  };

  const handleRotateCounterclockwise = () => {
    setRotation(prev => (prev - 90 + 360) % 360);
  };

  const handleFullscreen = async () => {
    if (!document.fullscreenElement && containerRef.current) {
      try {
        await containerRef.current.requestFullscreen();
        toast({
          title: 'फुलस्क्रीन',
          description: 'फुलस्क्रीन मोड में खोला गया',
        });
      } catch (err) {
        console.error('Fullscreen error:', err);
      }
    } else if (document.fullscreenElement) {
      await document.exitFullscreen();
    }
  };

  const handlePrint = () => {
    window.open(cleanUrl, '_blank');
    toast({
      title: 'प्रिंट',
      description: 'नई टैब में खोलें और प्रिंट करें',
    });
  };

  const handleSave = () => {
    handleDownload();
  };

  const handleOpenInNewTab = () => {
    window.open(cleanUrl, '_blank');
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      const newPage = currentPage - 1;
      setCurrentPage(newPage);
      setPageInput(String(newPage));
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      const newPage = currentPage + 1;
      setCurrentPage(newPage);
      setPageInput(String(newPage));
    }
  };

  const handlePageInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPageInput(e.target.value);
  };

  const handlePageInputSubmit = () => {
    const page = Number.parseInt(pageInput, 10);
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    } else {
      setPageInput(String(currentPage));
      toast({
        title: 'अमान्य पृष्ठ',
        description: `कृपया 1 से ${totalPages} के बीच पृष्ठ संख्या दर्ज करें`,
        variant: 'destructive',
      });
    }
  };

  const toggleDrawingMode = () => {
    setDrawingMode(!drawingMode);
    setTextMode(false);
  };

  const toggleTextMode = () => {
    setTextMode(!textMode);
    setDrawingMode(false);
  };

  const toggleSearchMode = () => {
    setSearchMode(!searchMode);
    if (searchMode) {
      setSearchQuery('');
    }
  };

  const togglePresentationMode = () => {
    setPresentationMode(!presentationMode);
    if (!presentationMode) {
      handleFullscreen();
    }
  };

  const toggleHandTool = () => {
    setHandTool(!handTool);
    setTextSelection(handTool);
  };

  const toggleTextSelection = () => {
    setTextSelection(!textSelection);
    setHandTool(!textSelection);
  };

  const goToFirstPage = () => {
    setCurrentPage(1);
    setPageInput('1');
  };

  const goToLastPage = () => {
    setCurrentPage(totalPages);
    setPageInput(String(totalPages));
  };

  const goToCurrentPage = () => {
    // Current page is already visible
  };

  const toggleScrollMode = () => {
    setScrollMode(prev => prev === 'page' ? 'vertical' : 'page');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: title || 'PDF दस्तावेज़',
        url: cleanUrl,
      }).catch(err => console.error('Share error:', err));
    } else {
      navigator.clipboard.writeText(cleanUrl);
      toast({
        title: 'लिंक कॉपी किया गया',
        description: 'PDF लिंक क्लिपबोर्ड में कॉपी किया गया',
      });
    }
  };

  const [showAlternative, setShowAlternative] = useState(false);

  useEffect(() => {
    let timer: any;
    if (loading) {
      timer = setTimeout(() => {
        setShowAlternative(true);
      }, 5000); // Show alternative option after 5 seconds
    } else {
      setShowAlternative(false);
    }
    return () => clearTimeout(timer);
  }, [loading]);

  const toggleViewerMode = () => {
    setUseGoogleViewer(!useGoogleViewer);
    setLoading(true);
  };

  if (error) {
    return (
      <Card className="glass-card">
        <CardContent className="flex flex-col items-center justify-center py-12 space-y-4">
          <div className="text-6xl"><FileText className="inline h-16 w-16 text-destructive" /></div>
          <h3 className="text-xl font-semibold">PDF लोड नहीं हो सका</h3>
          <p className="text-muted-foreground text-center max-w-md">
            PDF फ़ाइल लोड करने में त्रुटि हुई। कृपया डाउनलोड करें।
          </p>
          <Button onClick={handleDownload} className="bg-gradient-to-r from-primary to-secondary">
            <Download className="mr-2 h-4 w-4" />
            डाउनलोड करें
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card overflow-hidden shadow-2xl border-primary/10" ref={containerRef}>
      <CardContent className="p-0">
        {/* Header Area to match Image 3 */}
        <div className="bg-background/95 backdrop-blur-md border-b border-border p-3 md:p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex flex-col min-w-0 w-full sm:w-auto">
            <h2 className="text-lg md:text-xl xl:text-2xl font-bold tracking-tight truncate">{title || 'PDF Viewer'}</h2>
            <p className="text-[10px] md:text-xs xl:text-sm text-muted-foreground truncate">{subtitle || 'दस्तावेज़ पूर्वावलोकन'}</p>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
            <Button
              onClick={onDownload || handleDownload}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold h-9 px-4 md:px-6 text-sm flex-1 sm:flex-none"
            >
              <Download className="mr-2 h-4 w-4 md:h-5 md:w-5" />
              डाउनलोड करें
            </Button>
            {onClose && (
              <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full shrink-0">
                <X className="h-5 w-5 md:h-6 md:w-6" />
              </Button>
            )}
          </div>
        </div>

        {/* Toolbar */}
        <div className="bg-muted/30 border-b border-border p-2 flex items-center justify-between gap-2 overflow-x-auto no-scrollbar">
          {/* Left: Search */}
          <div className="flex items-center gap-1">
            <Button
              variant={searchMode ? "default" : "ghost"}
              size="icon"
              onClick={toggleSearchMode}
              title="खोजें"
              className="h-8 w-8"
            >
              <Search className="h-4 w-4" />
            </Button>
          </div>

          {/* Center: Page & Zoom */}
          <div className="flex items-center gap-4">
            {/* Page Navigation */}
            <div className="flex items-center gap-1 bg-background/50 rounded-md border border-border px-2 py-0.5">
              <Input
                value={pageInput}
                onChange={handlePageInputChange}
                onBlur={handlePageInputSubmit}
                onKeyDown={(e) => e.key === 'Enter' && handlePageInputSubmit()}
                className="h-6 w-8 text-center text-xs p-0 bg-transparent border-none focus-visible:ring-0"
              />
              <span className="text-[11px] font-medium text-muted-foreground">
                of {totalPages}
              </span>
            </div>

            {/* Zoom Controls */}
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleZoomOut}
                disabled={zoom <= 50}
                title="ज़ूम आउट"
                className="h-8 w-8"
              >
                <ZoomOut className="h-4 w-4" />
              </Button>
              <Separator orientation="vertical" className="h-4" />
              <Button
                variant="ghost"
                size="icon"
                onClick={handleZoomIn}
                disabled={zoom >= 300}
                title="ज़ूम इन"
                className="h-8 w-8"
              >
                <ZoomIn className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Right: Tools & More */}
          <div className="flex items-center gap-1">
            <Button
              variant={drawingMode ? "default" : "ghost"}
              size="icon"
              onClick={toggleDrawingMode}
              title="ड्राइंग टूल"
              className="h-8 w-8 hidden sm:flex"
            >
              <Pencil className="h-4 w-4" />
            </Button>
            <Button
              variant={textMode ? "default" : "ghost"}
              size="icon"
              onClick={toggleTextMode}
              title="टेक्स्ट टूल"
              className="h-8 w-8 hidden sm:flex"
            >
              <Type className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              title="इमेज जोड़ें"
              className="h-8 w-8 hidden sm:flex"
            >
              <ImageIcon className="h-4 w-4" />
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <ChevronsRight className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-64">
                  <DropdownMenuLabel>फ़ाइल विकल्प</DropdownMenuLabel>
                  <DropdownMenuItem onClick={handleOpenInNewTab}>
                    <ExternalLink className="mr-2 h-4 w-4" />
                    <span>Open</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handlePrint}>
                    <Printer className="mr-2 h-4 w-4" />
                    <span>Print</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleSave}>
                    <Save className="mr-2 h-4 w-4" />
                    <span>Save</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleShare}>
                    <Share2 className="mr-2 h-4 w-4" />
                    <span>शेयर करें</span>
                  </DropdownMenuItem>
                  
                  <DropdownMenuSeparator />
                  <DropdownMenuLabel>व्यू विकल्प</DropdownMenuLabel>
                  <DropdownMenuItem onClick={togglePresentationMode}>
                    <Monitor className="mr-2 h-4 w-4" />
                    <span>Presentation Mode</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={goToCurrentPage}>
                    <FileText className="mr-2 h-4 w-4" />
                    <span>Current Page</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={goToFirstPage}>
                    <ArrowUpToLine className="mr-2 h-4 w-4" />
                    <span>Go to First Page</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={goToLastPage}>
                    <ArrowDownToLine className="mr-2 h-4 w-4" />
                    <span>Go to Last Page</span>
                  </DropdownMenuItem>
                  
                  <DropdownMenuSeparator />
                  <DropdownMenuLabel>रोटेशन</DropdownMenuLabel>
                  <DropdownMenuItem onClick={handleRotateClockwise}>
                    <RotateCw className="mr-2 h-4 w-4" />
                    <span>Rotate Clockwise</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleRotateCounterclockwise}>
                    <RotateCcw className="mr-2 h-4 w-4" />
                    <span>Rotate Counterclockwise</span>
                  </DropdownMenuItem>
                  
                  <DropdownMenuSeparator />
                  <DropdownMenuLabel>टूल्स</DropdownMenuLabel>
                  <DropdownMenuItem onClick={toggleTextSelection}>
                    <MousePointer className="mr-2 h-4 w-4" />
                    <span>Text Selection Tool</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={toggleHandTool}>
                    <Hand className="mr-2 h-4 w-4" />
                    <span>Hand Tool</span>
                  </DropdownMenuItem>
                  
                  <DropdownMenuSeparator />
                  <DropdownMenuLabel>स्क्रॉलिंग</DropdownMenuLabel>
                  <DropdownMenuItem onClick={toggleScrollMode}>
                    <ScrollText className="mr-2 h-4 w-4" />
                    <span>Page Scrolling</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={toggleScrollMode}>
                    <AlignVerticalSpaceAround className="mr-2 h-4 w-4" />
                    <span>Vertical Scrolling</span>
                  </DropdownMenuItem>
                  
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleFullscreen}>
                    {isFullscreen ? (
                      <>
                        <Minimize2 className="mr-2 h-4 w-4" />
                        <span>फुलस्क्रीन से बाहर निकलें</span>
                      </>
                    ) : (
                      <>
                        <Maximize2 className="mr-2 h-4 w-4" />
                        <span>फुलस्क्रीन</span>
                      </>
                    )}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

          {/* Search Bar (Conditional) */}
          {searchMode && (
            <div className="flex items-center gap-2 bg-muted/50 rounded-lg p-2">
              <Search className="h-4 w-4 text-muted-foreground ml-2" />
              <Input
                type="text"
                placeholder="PDF में खोजें..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 border-0 bg-transparent focus-visible:ring-0"
              />
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleSearchMode}
                className="h-7 w-7"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>

        {/* PDF Viewer */}
        <div className="relative bg-muted/30 min-h-[70vh]">
          {loading && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/50 backdrop-blur-sm z-10">
              <div className="flex flex-col items-center gap-3">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <p className="text-sm text-muted-foreground">PDF लोड हो रहा है...</p>
                {showAlternative && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={toggleViewerMode}
                    className="mt-2"
                  >
                    {useGoogleViewer ? 'सामान्य व्यूअर का उपयोग करें' : 'वैकल्पिक व्यूअर का उपयोग करें'}
                  </Button>
                )}
              </div>
            </div>
          )}
          
          <div 
            className="w-full h-full flex items-center justify-center p-2 md:p-4"
            style={{
              transform: `rotate(${rotation}deg)`,
              transformOrigin: 'center',
              transition: 'transform 0.3s ease',
            }}
          >
            {useGoogleViewer || /iPhone|iPad|iPod|Android/i.test(navigator.userAgent) ? (
              <iframe
                src={`https://docs.google.com/viewer?url=${encodeURIComponent(cleanUrl)}&embedded=true`}
                title={title || 'PDF Viewer'}
                className="w-full h-[70vh] md:h-[80vh] border-0 rounded-lg shadow-xl bg-white"
                onLoad={() => setLoading(false)}
              />
            ) : (
              <iframe
                ref={iframeRef}
                src={`${cleanUrl}#toolbar=0&navpanes=0&scrollbar=0`}
                title={title || 'PDF Viewer'}
                className="w-full h-[70vh] md:h-[80vh] border-0 rounded-lg shadow-xl bg-white"
                onLoad={() => setLoading(false)}
                onError={() => {
                  setUseGoogleViewer(true);
                }}
              />
            )}
          </div>

          {/* Drawing Canvas Overlay (when drawing mode is active) */}
          {drawingMode && (
            <canvas
              ref={canvasRef}
              className="absolute inset-0 w-full h-full cursor-crosshair z-20"
              style={{ pointerEvents: 'auto' }}
            />
          )}
        </div>
      </CardContent>
    </Card>
  );
}
