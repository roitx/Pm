// दैनिक प्रेरणा सेवा - Daily Motivation Service
import { supabase } from '@/db/supabase';

// प्रेरणादायक संदेशों की सूची
const motivationalQuotes = [
  {
    title: '🌟 आज का प्रेरणा संदेश',
    message: 'सफलता का रहस्य है - निरंतर प्रयास। हर दिन कुछ नया सीखें और आगे बढ़ें! 📚',
  },
  {
    title: '💪 आज का प्रेरणा संदेश',
    message: 'कठिन परिश्रम कभी व्यर्थ नहीं जाता। आज भी अपना सर्वश्रेष्ठ दें! 🎯',
  },
  {
    title: '🎓 आज का प्रेरणा संदेश',
    message: 'ज्ञान ही शक्ति है। हर दिन कुछ नया सीखकर खुद को मजबूत बनाएं! 💡',
  },
  {
    title: '🚀 आज का प्रेरणा संदेश',
    message: 'सपने देखो, मेहनत करो, सफलता पाओ। आज एक कदम और आगे बढ़ें! ⭐',
  },
  {
    title: '✨ आज का प्रेरणा संदेश',
    message: 'असफलता सफलता की सीढ़ी है। गलतियों से सीखें और आगे बढ़ते रहें! 🌈',
  },
  {
    title: '🎯 आज का प्रेरणा संदेश',
    message: 'लक्ष्य निर्धारित करें और उसे पाने के लिए प्रतिदिन प्रयास करें! 🏆',
  },
  {
    title: '📖 आज का प्रेरणा संदेश',
    message: 'पढ़ाई में निरंतरता ही सफलता की कुंजी है। आज भी मेहनत जारी रखें! 💯',
  },
  {
    title: '🌅 आज का प्रेरणा संदेश',
    message: 'हर नया दिन एक नई शुरुआत है। आज को अपना सर्वश्रेष्ठ दिन बनाएं! 🌟',
  },
  {
    title: '💫 आज का प्रेरणा संदेश',
    message: 'विश्वास रखें खुद पर। आप जो चाहें वो कर सकते हैं! 🎊',
  },
  {
    title: '🔥 आज का प्रेरणा संदेश',
    message: 'जोश और मेहनत से हर मुश्किल आसान हो जाती है। आगे बढ़ते रहें! 💪',
  },
  {
    title: '🌺 आज का प्रेरणा संदेश',
    message: 'छोटे-छोटे कदम भी बड़ी सफलता की ओर ले जाते हैं। आज एक कदम और! 👣',
  },
  {
    title: '⚡ आज का प्रेरणा संदेश',
    message: 'समय का सदुपयोग करें। हर पल कीमती है, इसे व्यर्थ न जाने दें! ⏰',
  },
  {
    title: '🎨 आज का प्रेरणा संदेश',
    message: 'रचनात्मक बनें और नए तरीकों से सीखें। ज्ञान की कोई सीमा नहीं! 🧠',
  },
  {
    title: '🏅 आज का प्रेरणा संदेश',
    message: 'चैंपियन बनने के लिए चैंपियन की तरह मेहनत करें! 🥇',
  },
  {
    title: '🌟 आज का प्रेरणा संदेश',
    message: 'आपकी मेहनत आपको जरूर सफलता दिलाएगी। बस लगे रहें! 🎯',
  },
];

// दैनिक प्रेरणा संदेश जोड़ने का फंक्शन
export async function sendDailyMotivation() {
  try {
    // आज की तारीख चेक करें
    const today = new Date().toDateString();
    const lastMotivationDate = localStorage.getItem('lastMotivationDate');
    
    // अगर आज पहले से motivation भेजा जा चुका है तो return करें
    if (lastMotivationDate === today) {
      console.log('✅ Daily motivation already sent today');
      return { success: true, message: 'Already sent today' };
    }
    
    // रैंडम प्रेरणा संदेश चुनें
    const randomIndex = Math.floor(Math.random() * motivationalQuotes.length);
    const motivation = motivationalQuotes[randomIndex];
    
    console.log('📨 Sending daily motivation:', motivation.title);
    
    // Notification बनाएं
    const { data: notification, error: notificationError } = await supabase
      .from('notifications')
      .insert({
        title: motivation.title,
        message: motivation.message,
        type: 'announcement',
        metadata: { category: 'daily_motivation', date: today },
        sent_by: null, // System generated
      })
      .select()
      .maybeSingle();
    
    if (notificationError) {
      console.error('❌ Error creating daily motivation:', notificationError);
      return { success: false, error: notificationError };
    }
    
    if (!notification) {
      console.error('❌ No notification created');
      return { success: false, error: 'No notification created' };
    }
    
    console.log('✅ Notification created:', notification.id);
    
    // सभी users को notification भेजें using RPC function
    const { error: rpcError } = await supabase.rpc('distribute_notification', {
      p_notification_id: notification.id,
    });
    
    if (rpcError) {
      console.error('❌ Error distributing notification:', rpcError);
      return { success: false, error: rpcError };
    }
    
    // आज की तारीख save करें
    localStorage.setItem('lastMotivationDate', today);
    console.log('✅ Daily motivation sent successfully!');
    
    return { success: true, notification };
    
  } catch (error) {
    console.error('❌ Error in sendDailyMotivation:', error);
    return { success: false, error };
  }
}

// ऐप शुरू होने पर daily motivation चेक करें (user login के बाद)
export function initializeDailyMotivation(userId: string | null) {
  if (!userId) {
    console.log('⏸️ Daily motivation: Waiting for user login');
    return;
  }
  
  console.log('🚀 Initializing daily motivation system for user:', userId);
  
  // 2 seconds delay to ensure user is fully logged in
  setTimeout(() => {
    sendDailyMotivation();
  }, 2000);
  
  // हर 2 घंटे में चेक करें (अगर user ऐप खुला रखे)
  const interval = setInterval(() => {
    sendDailyMotivation();
  }, 2 * 60 * 60 * 1000); // 2 hours
  
  // Cleanup function
  return () => clearInterval(interval);
}

