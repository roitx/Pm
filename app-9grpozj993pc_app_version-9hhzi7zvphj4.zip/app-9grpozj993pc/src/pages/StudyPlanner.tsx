import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Calendar, Clock, BookOpen, Target, Plus, CheckCircle2, Circle } from 'lucide-react';

export default function StudyPlanner() {
  const navigate = useNavigate();
  const [selectedDay, setSelectedDay] = useState<string>('monday');

  // साप्ताहिक योजना डेटा
  const weekDays = [
    { id: 'monday', name: 'सोमवार', short: 'सोम' },
    { id: 'tuesday', name: 'मंगलवार', short: 'मंग' },
    { id: 'wednesday', name: 'बुधवार', short: 'बुध' },
    { id: 'thursday', name: 'गुरुवार', short: 'गुरु' },
    { id: 'friday', name: 'शुक्रवार', short: 'शुक्र' },
    { id: 'saturday', name: 'शनिवार', short: 'शनि' },
    { id: 'sunday', name: 'रविवार', short: 'रवि' },
  ];

  const studyPlan = {
    monday: [
      { id: 1, subject: 'गणित', topic: 'द्विघात समीकरण', time: '09:00 - 10:30', duration: '1.5 घंटे', completed: true, priority: 'high' },
      { id: 2, subject: 'भौतिकी', topic: 'गति के नियम', time: '11:00 - 12:30', duration: '1.5 घंटे', completed: true, priority: 'high' },
      { id: 3, subject: 'रसायन विज्ञान', topic: 'रासायनिक बंधन', time: '14:00 - 15:30', duration: '1.5 घंटे', completed: false, priority: 'medium' },
      { id: 4, subject: 'अंग्रेजी', topic: 'व्याकरण अभ्यास', time: '16:00 - 17:00', duration: '1 घंटा', completed: false, priority: 'low' },
    ],
    tuesday: [
      { id: 5, subject: 'रसायन विज्ञान', topic: 'कार्बनिक रसायन', time: '09:00 - 10:30', duration: '1.5 घंटे', completed: false, priority: 'high' },
      { id: 6, subject: 'जीव विज्ञान', topic: 'कोशिका विभाजन', time: '11:00 - 12:30', duration: '1.5 घंटे', completed: false, priority: 'high' },
      { id: 7, subject: 'गणित', topic: 'त्रिकोणमिति', time: '14:00 - 15:30', duration: '1.5 घंटे', completed: false, priority: 'medium' },
    ],
    wednesday: [
      { id: 8, subject: 'भौतिकी', topic: 'विद्युत धारा', time: '09:00 - 10:30', duration: '1.5 घंटे', completed: false, priority: 'high' },
      { id: 9, subject: 'गणित', topic: 'समाकलन', time: '11:00 - 12:30', duration: '1.5 घंटे', completed: false, priority: 'high' },
      { id: 10, subject: 'हिंदी', topic: 'साहित्य पाठ', time: '14:00 - 15:00', duration: '1 घंटा', completed: false, priority: 'low' },
    ],
    thursday: [
      { id: 11, subject: 'रसायन विज्ञान', topic: 'रासायनिक गतिकी', time: '09:00 - 10:30', duration: '1.5 घंटे', completed: false, priority: 'high' },
      { id: 12, subject: 'जीव विज्ञान', topic: 'आनुवंशिकी', time: '11:00 - 12:30', duration: '1.5 घंटे', completed: false, priority: 'medium' },
      { id: 13, subject: 'भौतिकी', topic: 'प्रकाशिकी', time: '14:00 - 15:30', duration: '1.5 घंटे', completed: false, priority: 'medium' },
    ],
    friday: [
      { id: 14, subject: 'गणित', topic: 'सांख्यिकी', time: '09:00 - 10:30', duration: '1.5 घंटे', completed: false, priority: 'high' },
      { id: 15, subject: 'भौतिकी', topic: 'आधुनिक भौतिकी', time: '11:00 - 12:30', duration: '1.5 घंटे', completed: false, priority: 'high' },
      { id: 16, subject: 'अंग्रेजी', topic: 'निबंध लेखन', time: '14:00 - 15:00', duration: '1 घंटा', completed: false, priority: 'low' },
    ],
    saturday: [
      { id: 17, subject: 'रिवीजन', topic: 'सप्ताह की समीक्षा', time: '09:00 - 11:00', duration: '2 घंटे', completed: false, priority: 'high' },
      { id: 18, subject: 'MCQ अभ्यास', topic: 'सभी विषय', time: '11:30 - 13:00', duration: '1.5 घंटे', completed: false, priority: 'high' },
      { id: 19, subject: 'संदेह समाधान', topic: 'कठिन प्रश्न', time: '14:00 - 15:30', duration: '1.5 घंटे', completed: false, priority: 'medium' },
    ],
    sunday: [
      { id: 20, subject: 'मॉक टेस्ट', topic: 'पूर्ण पाठ्यक्रम', time: '10:00 - 13:00', duration: '3 घंटे', completed: false, priority: 'high' },
      { id: 21, subject: 'विश्राम', topic: 'मनोरंजन और आराम', time: '14:00 - 18:00', duration: '4 घंटे', completed: false, priority: 'low' },
    ],
  };

  const currentDayPlan = studyPlan[selectedDay as keyof typeof studyPlan] || [];

  // आंकड़े गणना
  const totalTasks = currentDayPlan.length;
  const completedTasks = currentDayPlan.filter(task => task.completed).length;
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-500/10 text-red-500 border-red-500/20';
      case 'medium': return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
      case 'low': return 'bg-green-500/10 text-green-500 border-green-500/20';
      default: return 'bg-muted';
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'high': return 'उच्च';
      case 'medium': return 'मध्यम';
      case 'low': return 'निम्न';
      default: return '';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate('/student')}
                className="shrink-0"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold gradient-text">अध्ययन योजनाकार</h1>
                <p className="text-sm text-muted-foreground">अपने समय को प्रभावी ढंग से प्रबंधित करें</p>
              </div>
            </div>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              <span className="hidden xl:inline">नया कार्य</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-8">
          <Card className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border-blue-500/20">
            <CardContent className="p-4 xl:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">कुल कार्य</p>
                  <p className="text-2xl xl:text-3xl font-bold">{totalTasks}</p>
                </div>
                <Target className="w-8 h-8 xl:w-10 xl:h-10 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/20">
            <CardContent className="p-4 xl:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">पूर्ण</p>
                  <p className="text-2xl xl:text-3xl font-bold">{completedTasks}</p>
                </div>
                <CheckCircle2 className="w-8 h-8 xl:w-10 xl:h-10 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500/10 to-red-500/10 border-orange-500/20">
            <CardContent className="p-4 xl:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">शेष</p>
                  <p className="text-2xl xl:text-3xl font-bold">{totalTasks - completedTasks}</p>
                </div>
                <Circle className="w-8 h-8 xl:w-10 xl:h-10 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/20">
            <CardContent className="p-4 xl:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">पूर्णता</p>
                  <p className="text-2xl xl:text-3xl font-bold">{completionRate}%</p>
                </div>
                <Calendar className="w-8 h-8 xl:w-10 xl:h-10 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Week Days Selector */}
        <Card className="mb-8">
          <CardContent className="p-4">
            <div className="flex gap-2 overflow-x-auto pb-2">
              {weekDays.map((day) => (
                <Button
                  key={day.id}
                  variant={selectedDay === day.id ? 'default' : 'outline'}
                  className="flex-shrink-0"
                  onClick={() => setSelectedDay(day.id)}
                >
                  <span className="hidden xl:inline">{day.name}</span>
                  <span className="xl:hidden">{day.short}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Daily Schedule */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              {weekDays.find(d => d.id === selectedDay)?.name} की योजना
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {currentDayPlan.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
                  <Calendar className="w-12 h-12 text-muted-foreground" />
                </div>
                <h3 className="text-xl font-semibold mb-2">कोई कार्य नहीं</h3>
                <p className="text-muted-foreground mb-4">
                  इस दिन के लिए कोई अध्ययन योजना नहीं है
                </p>
                <Button className="gap-2">
                  <Plus className="w-4 h-4" />
                  कार्य जोड़ें
                </Button>
              </div>
            ) : (
              currentDayPlan.map((task) => (
                <Card
                  key={task.id}
                  className={`transition-all duration-300 hover:shadow-lg ${
                    task.completed ? 'opacity-60' : ''
                  }`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      {/* Checkbox */}
                      <div className="flex-shrink-0 mt-1">
                        {task.completed ? (
                          <CheckCircle2 className="w-6 h-6 text-green-500" />
                        ) : (
                          <Circle className="w-6 h-6 text-muted-foreground" />
                        )}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-start gap-2 mb-2">
                          <h3 className={`font-bold text-lg ${task.completed ? 'line-through' : ''}`}>
                            {task.subject}
                          </h3>
                          <Badge variant="outline" className={getPriorityColor(task.priority)}>
                            {getPriorityLabel(task.priority)} प्राथमिकता
                          </Badge>
                        </div>

                        <p className="text-muted-foreground mb-3">
                          {task.topic}
                        </p>

                        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {task.time}
                          </span>
                          <span className="flex items-center gap-1">
                            <BookOpen className="w-4 h-4" />
                            {task.duration}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
