import * as React from 'react';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DynamicIcon } from '@/components/ui/DynamicIcon';
import { PDFViewer } from '@/components/ui/PDFViewer';
import { ImageViewer } from '@/components/ui/ImageViewer';
import { useToast } from '@/hooks/use-toast';
import { getContent, deleteContent, getMCQQuestions, deleteMCQQuestion, updateMCQQuestion, updateContent, getThreeDStructures, deleteThreeDStructure, updateThreeDStructure, getExternalNotes, deleteExternalNote, updateExternalNote } from '@/db/api';
import { CLASSES, CATEGORIES } from '@/lib/constants';
import { Loader2, Search, Trash2, FileText, Image, File, ArrowLeft, CheckCircle, ClipboardList, Plus, Edit, Eye, Package, Paperclip, LayoutGrid } from 'lucide-react';
import type { Content, MCQQuestion, ThreeDStructure, ExternalNote } from '@/types/types';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

export default function AdminContentManagementPage() {
  const navigate = useNavigate();
  const { toast } = useToast();

  // Content state
  const [contents, setContents] = useState<Content[]>([]);
  const [filteredContents, setFilteredContents] = useState<Content[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedClass, setSelectedClass] = useState<string>('all');
  const [contentToDelete, setContentToDelete] = useState<Content | null>(null);
  const [deleting, setDeleting] = useState(false);
  
  // Viewer states
  const [viewerOpen, setViewerOpen] = useState(false);
  const [viewingContent, setViewingContent] = useState<Content | null>(null);
  const [imageViewerOpen, setImageViewerOpen] = useState(false);
  
  // Edit content state
  const [contentToEdit, setContentToEdit] = useState<Content | null>(null);
  const [editingContent, setEditingContent] = useState(false);
  const [contentEditForm, setContentEditForm] = useState<Partial<Content>>({});

  // MCQ state
  const [mcqQuestions, setMcqQuestions] = useState<MCQQuestion[]>([]);
  const [filteredMcqQuestions, setFilteredMcqQuestions] = useState<MCQQuestion[]>([]);
  const [mcqLoading, setMcqLoading] = useState(false);
  const [mcqSearchQuery, setMcqSearchQuery] = useState('');
  const [mcqSelectedClass, setMcqSelectedClass] = useState<string>('all');
  const [mcqToDelete, setMcqToDelete] = useState<MCQQuestion | null>(null);
  const [deletingMcq, setDeletingMcq] = useState(false);
  const [mcqToEdit, setMcqToEdit] = useState<MCQQuestion | null>(null);
  const [editingMcq, setEditingMcq] = useState(false);
  const [editForm, setEditForm] = useState<Partial<MCQQuestion>>({});
  const [selectedMcqIds, setSelectedMcqIds] = useState<Set<string>>(new Set());
  const [bulkDeletingMcq, setBulkDeletingMcq] = useState(false);

  // IIT-JEE state
  const [iitjeeQuestions, setIitjeeQuestions] = useState<MCQQuestion[]>([]);
  const [filteredIitjeeQuestions, setFilteredIitjeeQuestions] = useState<MCQQuestion[]>([]);
  const [iitjeeLoading, setIitjeeLoading] = useState(false);
  const [iitjeeSearchQuery, setIitjeeSearchQuery] = useState('');
  const [iitjeeSelectedClass, setIitjeeSelectedClass] = useState<string>('all');
  const [iitjeeToDelete, setIitjeeToDelete] = useState<MCQQuestion | null>(null);
  const [deletingIitjee, setDeletingIitjee] = useState(false);
  const [iitjeeToEdit, setIitjeeToEdit] = useState<MCQQuestion | null>(null);
  const [editingIitjee, setEditingIitjee] = useState(false);
  const [iitjeeEditForm, setIitjeeEditForm] = useState<Partial<MCQQuestion>>({});
  const [selectedIitjeeIds, setSelectedIitjeeIds] = useState<Set<string>>(new Set());
  const [bulkDeletingIitjee, setBulkDeletingIitjee] = useState(false);

  // 3D Structures state
  const [threeDStructures, setThreeDStructures] = useState<ThreeDStructure[]>([]);
  const [filtered3DStructures, setFiltered3DStructures] = useState<ThreeDStructure[]>([]);
  const [threeDLoading, setThreeDLoading] = useState(false);
  const [threeDSearchQuery, setThreeDSearchQuery] = useState('');
  const [threeDSelectedClass, setThreeDSelectedClass] = useState<string>('all');
  const [threeDToDelete, setThreeDToDelete] = useState<ThreeDStructure | null>(null);
  const [deletingThreeD, setDeletingThreeD] = useState(false);
  const [threeDToView, setThreeDToView] = useState<ThreeDStructure | null>(null);
  const [threeDToEdit, setThreeDToEdit] = useState<ThreeDStructure | null>(null);
  const [editingThreeD, setEditingThreeD] = useState(false);

  // External Notes state
  const [externalNotes, setExternalNotes] = useState<ExternalNote[]>([]);
  const [filteredExternalNotes, setFilteredExternalNotes] = useState<ExternalNote[]>([]);
  const [externalLoading, setExternalLoading] = useState(false);
  const [externalSearchQuery, setExternalSearchQuery] = useState('');
  const [externalSelectedClass, setExternalSelectedClass] = useState<string>('all');
  const [externalToDelete, setExternalToDelete] = useState<ExternalNote | null>(null);
  const [deletingExternal, setDeletingExternal] = useState(false);

  useEffect(() => {
    loadContents();
    loadMcqQuestions();
    loadIitjeeQuestions();
    load3DStructures();
    loadExternalNotes();
  }, []);

  useEffect(() => {
    filterContents();
  }, [searchQuery, selectedCategory, selectedClass, contents]);

  useEffect(() => {
    filterMcqQuestions();
  }, [mcqSearchQuery, mcqSelectedClass, mcqQuestions]);

  useEffect(() => {
    filterIitjeeQuestions();
  }, [iitjeeSearchQuery, iitjeeSelectedClass, iitjeeQuestions]);

  useEffect(() => {
    filter3DStructures();
  }, [threeDSearchQuery, threeDSelectedClass, threeDStructures]);

  useEffect(() => {
    filterExternalNotes();
  }, [externalSearchQuery, externalSelectedClass, externalNotes]);

  // Content functions
  const loadContents = async () => {
    setLoading(true);
    try {
      const data = await getContent();
      setContents(data);
    } catch (error) {
      console.error('Error loading contents:', error);
      toast({
        title: 'त्रुटि',
        description: 'सामग्री लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const filterContents = () => {
    let filtered = [...contents];

    if (searchQuery) {
      filtered = filtered.filter(
        (content) =>
          content.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          content.subject?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          content.chapter?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter((content) => content.category === selectedCategory);
    }

    if (selectedClass !== 'all') {
      filtered = filtered.filter((content) => content.class === Number(selectedClass));
    }

    setFilteredContents(filtered);
  };

  // Handle viewing content
  const handleViewContent = (content: Content) => {
    setViewingContent(content);
    if (content.file_type.includes('image')) {
      setImageViewerOpen(true);
    } else {
      setViewerOpen(true);
    }
  };
  
  // Handle editing content
  const handleEditContent = (content: Content) => {
    setContentToEdit(content);
    setContentEditForm({
      title: content.title,
      description: content.description || '',
      original_filename: content.original_filename || '',
      class: content.class,
      subject: content.subject,
      chapter: content.chapter || '',
    });
  };
  
  const handleSaveContentEdit = async () => {
    if (!contentToEdit) return;
    
    setEditingContent(true);
    try {
      await updateContent(contentToEdit.id, contentEditForm);
      toast({
        title: 'सफलता',
        description: 'सामग्री सफलतापूर्वक अपडेट की गई',
      });
      loadContents();
      setContentToEdit(null);
      setContentEditForm({});
    } catch (error) {
      console.error('Error updating content:', error);
      toast({
        title: 'त्रुटि',
        description: 'सामग्री अपडेट करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setEditingContent(false);
    }
  };

  const handleDeleteContent = async () => {
    if (!contentToDelete) return;

    setDeleting(true);
    try {
      await deleteContent(contentToDelete.id);
      toast({
        title: 'सफलता',
        description: 'सामग्री सफलतापूर्वक हटाई गई',
      });
      loadContents();
    } catch (error) {
      console.error('Error deleting content:', error);
      toast({
        title: 'त्रुटि',
        description: 'सामग्री हटाने में विफल',
        variant: 'destructive',
      });
    } finally {
      setDeleting(false);
      setContentToDelete(null);
    }
  };

  // MCQ functions
  const loadMcqQuestions = async () => {
    setMcqLoading(true);
    try {
      const allQuestions: MCQQuestion[] = [];
      for (const cls of CLASSES) {
        try {
          const questions = await getMCQQuestions({
            category: 'mcq_tests',
            class: cls,
            subject: 'all',
            chapter: 'all',
            limit: 1000
          });
          console.log(`MCQ प्रश्न लोड किए गए - कक्षा ${cls}:`, questions.length);
          allQuestions.push(...questions);
        } catch (err) {
          console.error(`Error loading MCQ for class ${cls}:`, err);
        }
      }
      console.log('कुल MCQ प्रश्न:', allQuestions.length);
      setMcqQuestions(allQuestions);
    } catch (error) {
      console.error('Error loading MCQ questions:', error);
    } finally {
      setMcqLoading(false);
    }
  };

  const filterMcqQuestions = () => {
    let filtered = [...mcqQuestions];

    if (mcqSearchQuery) {
      filtered = filtered.filter(
        (q) =>
          q.question.toLowerCase().includes(mcqSearchQuery.toLowerCase()) ||
          q.subject?.toLowerCase().includes(mcqSearchQuery.toLowerCase()) ||
          q.chapter?.toLowerCase().includes(mcqSearchQuery.toLowerCase())
      );
    }

    if (mcqSelectedClass !== 'all') {
      filtered = filtered.filter((q) => q.class === Number(mcqSelectedClass));
    }

    setFilteredMcqQuestions(filtered);
  };

  const handleDeleteMcq = async () => {
    if (!mcqToDelete) return;

    setDeletingMcq(true);
    try {
      await deleteMCQQuestion(mcqToDelete.id);
      toast({
        title: 'सफलता',
        description: 'MCQ प्रश्न सफलतापूर्वक हटाया गया',
      });
      loadMcqQuestions();
    } catch (error) {
      console.error('Error deleting MCQ:', error);
      toast({
        title: 'त्रुटि',
        description: 'MCQ प्रश्न हटाने में विफल',
        variant: 'destructive',
      });
    } finally {
      setDeletingMcq(false);
      setMcqToDelete(null);
    }
  };

  const handleEditMcq = (question: MCQQuestion) => {
    setMcqToEdit(question);
    setEditForm({
      question: question.question,
      option_a: question.option_a,
      option_b: question.option_b,
      option_c: question.option_c,
      option_d: question.option_d,
      correct_answer: question.correct_answer,
    });
  };

  const handleSaveEditMcq = async () => {
    if (!mcqToEdit) return;

    setEditingMcq(true);
    try {
      await updateMCQQuestion(mcqToEdit.id, editForm);
      toast({
        title: 'सफलता',
        description: 'MCQ प्रश्न सफलतापूर्वक अपडेट किया गया',
      });
      setMcqToEdit(null);
      setEditForm({});
      loadMcqQuestions();
    } catch (error) {
      console.error('Error updating MCQ:', error);
      toast({
        title: 'त्रुटि',
        description: 'MCQ प्रश्न अपडेट करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setEditingMcq(false);
    }
  };

  const toggleMcqSelection = (id: string) => {
    const newSelection = new Set(selectedMcqIds);
    if (newSelection.has(id)) {
      newSelection.delete(id);
    } else {
      newSelection.add(id);
    }
    setSelectedMcqIds(newSelection);
  };

  const handleBulkDeleteMcq = async () => {
    if (selectedMcqIds.size === 0) return;

    setBulkDeletingMcq(true);
    try {
      const deletePromises = Array.from(selectedMcqIds).map(id => deleteMCQQuestion(id));
      await Promise.all(deletePromises);
      
      toast({
        title: 'सफलता',
        description: `${selectedMcqIds.size} MCQ प्रश्न सफलतापूर्वक हटाए गए`,
      });
      setSelectedMcqIds(new Set());
      loadMcqQuestions();
    } catch (error) {
      console.error('Error bulk deleting MCQ:', error);
      toast({
        title: 'त्रुटि',
        description: 'MCQ प्रश्न हटाने में विफल',
        variant: 'destructive',
      });
    } finally {
      setBulkDeletingMcq(false);
    }
  };

  // IIT-JEE functions
  const loadIitjeeQuestions = async () => {
    setIitjeeLoading(true);
    try {
      const allQuestions: MCQQuestion[] = [];
      for (const cls of CLASSES) {
        try {
          const questions = await getMCQQuestions({
            category: 'iit_jee_questions',
            class: cls,
            subject: 'all',
            chapter: 'all',
            limit: 1000
          });
          console.log(`IIT-JEE प्रश्न लोड किए गए - कक्षा ${cls}:`, questions.length);
          allQuestions.push(...questions);
        } catch (err) {
          console.error(`Error loading IIT-JEE for class ${cls}:`, err);
        }
      }
      console.log('कुल IIT-JEE प्रश्न:', allQuestions.length);
      setIitjeeQuestions(allQuestions);
    } catch (error) {
      console.error('Error loading IIT-JEE questions:', error);
    } finally {
      setIitjeeLoading(false);
    }
  };

  const filterIitjeeQuestions = () => {
    let filtered = [...iitjeeQuestions];

    if (iitjeeSearchQuery) {
      filtered = filtered.filter(
        (q) =>
          q.question.toLowerCase().includes(iitjeeSearchQuery.toLowerCase()) ||
          q.subject?.toLowerCase().includes(iitjeeSearchQuery.toLowerCase()) ||
          q.chapter?.toLowerCase().includes(iitjeeSearchQuery.toLowerCase())
      );
    }

    if (iitjeeSelectedClass !== 'all') {
      filtered = filtered.filter((q) => q.class === Number(iitjeeSelectedClass));
    }

    setFilteredIitjeeQuestions(filtered);
  };

  const handleDeleteIitjee = async () => {
    if (!iitjeeToDelete) return;

    setDeletingIitjee(true);
    try {
      await deleteMCQQuestion(iitjeeToDelete.id);
      toast({
        title: 'सफलता',
        description: 'IIT-JEE प्रश्न सफलतापूर्वक हटाया गया',
      });
      loadIitjeeQuestions();
    } catch (error) {
      console.error('Error deleting IIT-JEE:', error);
      toast({
        title: 'त्रुटि',
        description: 'IIT-JEE प्रश्न हटाने में विफल',
        variant: 'destructive',
      });
    } finally {
      setDeletingIitjee(false);
      setIitjeeToDelete(null);
    }
  };

  const handleEditIitjee = (question: MCQQuestion) => {
    setIitjeeToEdit(question);
    setIitjeeEditForm({
      question: question.question,
      option_a: question.option_a,
      option_b: question.option_b,
      option_c: question.option_c,
      option_d: question.option_d,
      correct_answer: question.correct_answer,
    });
  };

  const handleSaveEditIitjee = async () => {
    if (!iitjeeToEdit) return;

    setEditingIitjee(true);
    try {
      await updateMCQQuestion(iitjeeToEdit.id, iitjeeEditForm);
      toast({
        title: 'सफलता',
        description: 'IIT-JEE प्रश्न सफलतापूर्वक अपडेट किया गया',
      });
      setIitjeeToEdit(null);
      setIitjeeEditForm({});
      loadIitjeeQuestions();
    } catch (error) {
      console.error('Error updating IIT-JEE:', error);
      toast({
        title: 'त्रुटि',
        description: 'IIT-JEE प्रश्न अपडेट करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setEditingIitjee(false);
    }
  };

  const toggleIitjeeSelection = (id: string) => {
    const newSelection = new Set(selectedIitjeeIds);
    if (newSelection.has(id)) {
      newSelection.delete(id);
    } else {
      newSelection.add(id);
    }
    setSelectedIitjeeIds(newSelection);
  };

  const handleBulkDeleteIitjee = async () => {
    if (selectedIitjeeIds.size === 0) return;

    setBulkDeletingIitjee(true);
    try {
      const deletePromises = Array.from(selectedIitjeeIds).map(id => deleteMCQQuestion(id));
      await Promise.all(deletePromises);
      
      toast({
        title: 'सफलता',
        description: `${selectedIitjeeIds.size} IIT-JEE प्रश्न सफलतापूर्वक हटाए गए`,
      });
      setSelectedIitjeeIds(new Set());
      loadIitjeeQuestions();
    } catch (error) {
      console.error('Error bulk deleting IIT-JEE:', error);
      toast({
        title: 'त्रुटि',
        description: 'IIT-JEE प्रश्न हटाने में विफल',
        variant: 'destructive',
      });
    } finally {
      setBulkDeletingIitjee(false);
    }
  };

  // 3D Structures functions
  const load3DStructures = async () => {
    setThreeDLoading(true);
    try {
      const data = await getThreeDStructures();
      // Admin sees ALL 3D structures, no filtering
      setThreeDStructures(data);
      setFiltered3DStructures(data);
    } catch (error) {
      console.error('Error loading 3D structures:', error);
      toast({
        title: 'त्रुटि',
        description: '3D संरचनाएं लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setThreeDLoading(false);
    }
  };

  const filter3DStructures = () => {
    let filtered = [...threeDStructures];

    if (threeDSearchQuery) {
      filtered = filtered.filter(item =>
        item.title.toLowerCase().includes(threeDSearchQuery.toLowerCase()) ||
        item.subject?.toLowerCase().includes(threeDSearchQuery.toLowerCase()) ||
        item.chapter?.toLowerCase().includes(threeDSearchQuery.toLowerCase())
      );
    }

    if (threeDSelectedClass !== 'all') {
      filtered = filtered.filter(item => item.class === parseInt(threeDSelectedClass));
    }

    setFiltered3DStructures(filtered);
  };

  const confirmDeleteThreeD = async () => {
    if (!threeDToDelete) return;

    setDeletingThreeD(true);
    try {
      await deleteThreeDStructure(threeDToDelete.id);
      toast({
        title: 'सफलता',
        description: '3D संरचना सफलतापूर्वक हटाई गई',
      });
      setThreeDToDelete(null);
      load3DStructures();
    } catch (error) {
      console.error('Error deleting 3D structure:', error);
      toast({
        title: 'त्रुटि',
        description: '3D संरचना हटाने में विफल',
        variant: 'destructive',
      });
    } finally {
      setDeletingThreeD(false);
    }
  };

  const handleEdit3DStructure = async (updatedData: Partial<ThreeDStructure>) => {
    if (!threeDToEdit) return;

    setEditingThreeD(true);
    try {
      await updateThreeDStructure(threeDToEdit.id, updatedData);
      toast({
        title: 'सफलता',
        description: '3D संरचना सफलतापूर्वक अपडेट की गई',
      });
      setThreeDToEdit(null);
      load3DStructures();
    } catch (error) {
      console.error('Error updating 3D structure:', error);
      toast({
        title: 'त्रुटि',
        description: '3D संरचना अपडेट करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setEditingThreeD(false);
    }
  };

  // External Notes functions
  const loadExternalNotes = async () => {
    setExternalLoading(true);
    try {
      const data = await getExternalNotes();
      // Admin sees ALL external notes, no filtering
      setExternalNotes(data);
      setFilteredExternalNotes(data);
    } catch (error) {
      console.error('Error loading external notes:', error);
      toast({
        title: 'त्रुटि',
        description: 'बाहरी नोट्स लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setExternalLoading(false);
    }
  };

  const filterExternalNotes = () => {
    let filtered = [...externalNotes];

    if (externalSearchQuery) {
      filtered = filtered.filter(item =>
        item.title.toLowerCase().includes(externalSearchQuery.toLowerCase()) ||
        item.subject?.toLowerCase().includes(externalSearchQuery.toLowerCase()) ||
        item.chapter?.toLowerCase().includes(externalSearchQuery.toLowerCase()) ||
        item.source?.toLowerCase().includes(externalSearchQuery.toLowerCase())
      );
    }

    if (externalSelectedClass !== 'all') {
      filtered = filtered.filter(item => item.class === parseInt(externalSelectedClass));
    }

    setFilteredExternalNotes(filtered);
  };

  const confirmDeleteExternal = async () => {
    if (!externalToDelete) return;

    setDeletingExternal(true);
    try {
      await deleteExternalNote(externalToDelete.id);
      toast({
        title: 'सफलता',
        description: 'बाहरी नोट्स सफलतापूर्वक हटाए गए',
      });
      setExternalToDelete(null);
      loadExternalNotes();
    } catch (error) {
      console.error('Error deleting external note:', error);
      toast({
        title: 'त्रुटि',
        description: 'बाहरी नोट्स हटाने में विफल',
        variant: 'destructive',
      });
    } finally {
      setDeletingExternal(false);
    }
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.includes('pdf')) return <FileText className="h-6 w-6 text-red-500" />;
    if (fileType.includes('image')) return <Image className="h-6 w-6 text-blue-500" />;
    return <File className="h-6 w-6 text-muted-foreground" />;
  };

  const getCategoryLabel = (category: string) => {
    const cat = CATEGORIES.find((c) => c.id === category);
    return cat?.name || category;
  };

  return (
    <div className="container mx-auto p-4 xl:p-6 max-w-7xl">
      <Card className="glass-card">
        <CardHeader className="border-b border-border/50">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/admin')}
              className="shrink-0"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <CardTitle className="text-xl xl:text-2xl">सामग्री प्रबंधन</CardTitle>
              <CardDescription className="mt-1">
                सभी अपलोड की गई सामग्री, MCQ और IIT-JEE प्रश्नों को प्रबंधित करें
              </CardDescription>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-4 xl:p-6">
          <Tabs defaultValue="content" className="w-full">
            <TabsList className="grid w-full grid-cols-5 mb-6">
              <TabsTrigger value="content" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                <span className="hidden sm:inline">सामग्री फ़ाइलें</span>
                <Badge variant="secondary" className="ml-1">{contents.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="3d" className="flex items-center gap-2">
                <Package className="h-4 w-4" />
                <span className="hidden sm:inline">3D संरचनाएं</span>
                <span className="sm:hidden">3D</span>
                <Badge variant="secondary" className="ml-1">{threeDStructures.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="external" className="flex items-center gap-2">
                <Paperclip className="h-4 w-4" />
                <span className="hidden sm:inline">बाहरी नोट्स</span>
                <span className="sm:hidden">नोट्स</span>
                <Badge variant="secondary" className="ml-1">{externalNotes.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="mcq" className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4" />
                <span className="hidden sm:inline">MCQ प्रश्न</span>
                <Badge variant="secondary" className="ml-1">{mcqQuestions.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="iitjee" className="flex items-center gap-2">
                <ClipboardList className="h-4 w-4" />
                <span className="hidden sm:inline">IIT-JEE</span>
                <Badge variant="secondary" className="ml-1">{iitjeeQuestions.length}</Badge>
              </TabsTrigger>
            </TabsList>

            {/* Content Tab */}
            <TabsContent value="content" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">सामग्री फ़ाइलें (PDF, Images, etc.)</h3>
                <Button onClick={() => navigate('/admin/upload')} size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  नई सामग्री जोड़ें
                </Button>
              </div>

              {/* Filters */}
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                <div className="md:col-span-2 xl:col-span-1 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="शीर्षक, विषय या अध्याय खोजें..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 h-11"
                  />
                </div>

                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="श्रेणी चुनें" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">
                      <div className="flex items-center gap-2">
                        <LayoutGrid className="h-4 w-4" />
                        <span>सभी श्रेणियां</span>
                      </div>
                    </SelectItem>
                    {CATEGORIES.filter(cat => cat.id !== 'mcq_tests' && cat.id !== 'iit_jee_questions' && cat.id !== '3d_structures' && cat.id !== 'external_notes').map((cat) => (
                      <SelectItem key={cat.id} value={cat.id}>
                        <div className="flex items-center gap-2">
                          <DynamicIcon name={cat.icon} className="h-4 w-4" />
                          <span>{cat.name}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="कक्षा चुनें" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">
                      <div className="flex items-center gap-2">
                        <LayoutGrid className="h-4 w-4" />
                        <span>सभी कक्षाएं</span>
                      </div>
                    </SelectItem>
                    {CLASSES.map((cls) => (
                      <SelectItem key={cls} value={String(cls)}>
                        कक्षा {cls}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Content List */}
              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : filteredContents.length === 0 ? (
                <div className="text-center py-12">
                  <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">कोई सामग्री नहीं मिली</h3>
                  <p className="text-sm text-muted-foreground">
                    {searchQuery || selectedCategory !== 'all' || selectedClass !== 'all'
                      ? 'फ़िल्टर बदलकर पुनः प्रयास करें'
                      : 'अभी तक कोई सामग्री अपलोड नहीं की गई है'}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredContents.map((content) => (
                    <Card 
                      key={content.id} 
                      className="hover:shadow-md transition-shadow"
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex items-start gap-4 flex-1">
                            <div className="shrink-0 w-12 h-12 rounded-lg bg-muted flex items-center justify-center">
                              {getFileIcon(content.file_type)}
                            </div>
                            <div className="flex-1 min-w-0">
                              <h4 className="font-semibold text-base mb-1 truncate">{content.title}</h4>
                              <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
                                <Badge variant="outline">कक्षा {content.class}</Badge>
                                <Badge variant="outline">{content.subject}</Badge>
                                {content.chapter && <Badge variant="outline">{content.chapter}</Badge>}
                                <Badge variant="secondary" className="gap-1.5 px-2 py-0.5">
                                  {(() => {
                                    const cat = CATEGORIES.find((c) => c.id === content.category);
                                    return (
                                      <>
                                        {cat && <DynamicIcon name={cat.icon} className="h-3 w-3" />}
                                        <span>{cat?.name || content.category}</span>
                                      </>
                                    );
                                  })()}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleViewContent(content)}
                              title="देखें"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEditContent(content)}
                              title="संपादित करें"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="destructive"
                              size="icon"
                              onClick={() => setContentToDelete(content)}
                              title="हटाएं"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* 3D Structures Tab */}
            <TabsContent value="3d" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">3D संरचनाएं</h3>
                <Button onClick={() => navigate('/admin/3d-structures-upload')} size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  नई 3D संरचना जोड़ें
                </Button>
              </div>

              {/* Filters */}
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="शीर्षक खोजें..."
                    value={threeDSearchQuery}
                    onChange={(e) => setThreeDSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={threeDSelectedClass} onValueChange={setThreeDSelectedClass}>
                  <SelectTrigger>
                    <SelectValue placeholder="कक्षा चुनें" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">सभी कक्षाएं</SelectItem>
                    {CLASSES.map((cls) => (
                      <SelectItem key={cls} value={cls.toString()}>
                        कक्षा {cls}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* 3D Structures List */}
              {threeDLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : filtered3DStructures.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center text-muted-foreground">
                    कोई 3D संरचना नहीं मिली
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-4">
                  {filtered3DStructures.map((structure) => (
                    <Card key={structure.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 min-w-0">
                            <h4 className="font-semibold truncate">{structure.title}</h4>
                            <div className="flex flex-wrap gap-2 mt-2">
                              <Badge variant="secondary">कक्षा {structure.class}</Badge>
                              <Badge variant="outline">{structure.subject}</Badge>
                              {structure.chapter && <Badge variant="outline">{structure.chapter}</Badge>}
                              <Badge variant="outline">{structure.file_type}</Badge>
                            </div>
                            {structure.description && (
                              <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                                {structure.description}
                              </p>
                            )}
                          </div>
                          <div className="flex gap-2 shrink-0">
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => setThreeDToView(structure)}
                              title="देखें"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => setThreeDToEdit(structure)}
                              title="संपादित करें"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="destructive"
                              size="icon"
                              onClick={() => setThreeDToDelete(structure)}
                              title="हटाएं"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* External Notes Tab */}
            <TabsContent value="external" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">बाहरी नोट्स</h3>
                <Button onClick={() => navigate('/admin/external-notes-upload')} size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  नए बाहरी नोट्स जोड़ें
                </Button>
              </div>

              {/* Filters */}
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="शीर्षक खोजें..."
                    value={externalSearchQuery}
                    onChange={(e) => setExternalSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={externalSelectedClass} onValueChange={setExternalSelectedClass}>
                  <SelectTrigger>
                    <SelectValue placeholder="कक्षा चुनें" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">सभी कक्षाएं</SelectItem>
                    {CLASSES.map((cls) => (
                      <SelectItem key={cls} value={cls.toString()}>
                        कक्षा {cls}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* External Notes List */}
              {externalLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : filteredExternalNotes.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center text-muted-foreground">
                    कोई बाहरी नोट्स नहीं मिले
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-4">
                  {filteredExternalNotes.map((note) => (
                    <Card key={note.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 min-w-0">
                            <h4 className="font-semibold truncate">{note.title}</h4>
                            <div className="flex flex-wrap gap-2 mt-2">
                              <Badge variant="secondary">कक्षा {note.class}</Badge>
                              <Badge variant="outline">{note.subject}</Badge>
                              {note.chapter && <Badge variant="outline">{note.chapter}</Badge>}
                              {note.source && <Badge variant="outline">{note.source}</Badge>}
                              <Badge variant="outline">{note.file_type}</Badge>
                            </div>
                            {note.description && (
                              <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                                {note.description}
                              </p>
                            )}
                          </div>
                          <div className="flex gap-2 shrink-0">
                            <Button
                              variant="destructive"
                              size="icon"
                              onClick={() => setExternalToDelete(note)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* MCQ Tab */}
            <TabsContent value="mcq" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">MCQ प्रश्न</h3>
                <div className="flex gap-2">
                  {selectedMcqIds.size > 0 && (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={handleBulkDeleteMcq}
                      disabled={bulkDeletingMcq}
                    >
                      {bulkDeletingMcq ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <Trash2 className="h-4 w-4 mr-2" />
                      )}
                      चयनित हटाएं ({selectedMcqIds.size})
                    </Button>
                  )}
                  <Button onClick={() => navigate('/admin/mcq-upload')} size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    नया MCQ जोड़ें
                  </Button>
                </div>
              </div>

              {/* Filters */}
              <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">
                <div className="xl:col-span-2 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="प्रश्न, विषय या अध्याय खोजें..."
                    value={mcqSearchQuery}
                    onChange={(e) => setMcqSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>

                <Select value={mcqSelectedClass} onValueChange={setMcqSelectedClass}>
                  <SelectTrigger>
                    <SelectValue placeholder="कक्षा चुनें" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">सभी कक्षाएं</SelectItem>
                    {CLASSES.map((cls) => (
                      <SelectItem key={cls} value={String(cls)}>
                        कक्षा {cls}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* MCQ List */}
              {mcqLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : filteredMcqQuestions.length === 0 ? (
                <div className="text-center py-12">
                  <CheckCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">कोई MCQ प्रश्न नहीं मिला</h3>
                  <p className="text-sm text-muted-foreground">
                    {mcqSearchQuery || mcqSelectedClass !== 'all'
                      ? 'फ़िल्टर बदलकर पुनः प्रयास करें'
                      : 'अभी तक कोई MCQ प्रश्न अपलोड नहीं किया गया है'}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredMcqQuestions.map((question) => (
                    <Card key={question.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          {/* Radio Button for Selection */}
                          <div className="flex items-center pt-1">
                            <input
                              type="checkbox"
                              checked={selectedMcqIds.has(question.id)}
                              onChange={() => toggleMcqSelection(question.id)}
                              className="w-5 h-5 rounded-full border-2 border-primary cursor-pointer accent-primary"
                              style={{
                                appearance: 'none',
                                WebkitAppearance: 'none',
                                borderRadius: '50%',
                                position: 'relative',
                              }}
                              onClick={(e) => {
                                const target = e.target as HTMLInputElement;
                                if (target.checked) {
                                  target.style.backgroundColor = 'hsl(var(--primary))';
                                  target.style.border = '2px solid hsl(var(--primary))';
                                } else {
                                  target.style.backgroundColor = 'transparent';
                                  target.style.border = '2px solid hsl(var(--primary))';
                                }
                              }}
                            />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-base mb-2 line-clamp-2">{question.question}</p>
                            <div className="flex flex-wrap gap-2 text-sm">
                              <Badge variant="outline">कक्षा {question.class}</Badge>
                              <Badge variant="outline">{question.subject}</Badge>
                              {question.chapter && <Badge variant="outline">{question.chapter}</Badge>}
                              <Badge variant="secondary">सही उत्तर: {question.correct_answer}</Badge>
                            </div>
                          </div>
                          <div className="flex gap-2 shrink-0">
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => handleEditMcq(question)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="destructive"
                              size="icon"
                              onClick={() => setMcqToDelete(question)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* IIT-JEE Tab */}
            <TabsContent value="iitjee" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">IIT-JEE प्रश्न</h3>
                <div className="flex gap-2">
                  {selectedIitjeeIds.size > 0 && (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={handleBulkDeleteIitjee}
                      disabled={bulkDeletingIitjee}
                    >
                      {bulkDeletingIitjee ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <Trash2 className="h-4 w-4 mr-2" />
                      )}
                      चयनित हटाएं ({selectedIitjeeIds.size})
                    </Button>
                  )}
                  <Button onClick={() => navigate('/admin/iitjee-upload')} size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    नया IIT-JEE प्रश्न जोड़ें
                  </Button>
                </div>
              </div>

              {/* Filters */}
              <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">
                <div className="xl:col-span-2 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="प्रश्न, विषय या अध्याय खोजें..."
                    value={iitjeeSearchQuery}
                    onChange={(e) => setIitjeeSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>

                <Select value={iitjeeSelectedClass} onValueChange={setIitjeeSelectedClass}>
                  <SelectTrigger>
                    <SelectValue placeholder="कक्षा चुनें" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">सभी कक्षाएं</SelectItem>
                    {CLASSES.map((cls) => (
                      <SelectItem key={cls} value={String(cls)}>
                        कक्षा {cls}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* IIT-JEE List */}
              {iitjeeLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : filteredIitjeeQuestions.length === 0 ? (
                <div className="text-center py-12">
                  <ClipboardList className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">कोई IIT-JEE प्रश्न नहीं मिला</h3>
                  <p className="text-sm text-muted-foreground">
                    {iitjeeSearchQuery || iitjeeSelectedClass !== 'all'
                      ? 'फ़िल्टर बदलकर पुनः प्रयास करें'
                      : 'अभी तक कोई IIT-JEE प्रश्न अपलोड नहीं किया गया है'}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredIitjeeQuestions.map((question) => (
                    <Card key={question.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          {/* Radio Button for Selection */}
                          <div className="flex items-center pt-1">
                            <input
                              type="checkbox"
                              checked={selectedIitjeeIds.has(question.id)}
                              onChange={() => toggleIitjeeSelection(question.id)}
                              className="w-5 h-5 rounded-full border-2 border-primary cursor-pointer accent-primary"
                              style={{
                                appearance: 'none',
                                WebkitAppearance: 'none',
                                borderRadius: '50%',
                                position: 'relative',
                              }}
                              onClick={(e) => {
                                const target = e.target as HTMLInputElement;
                                if (target.checked) {
                                  target.style.backgroundColor = 'hsl(var(--primary))';
                                  target.style.border = '2px solid hsl(var(--primary))';
                                } else {
                                  target.style.backgroundColor = 'transparent';
                                  target.style.border = '2px solid hsl(var(--primary))';
                                }
                              }}
                            />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-base mb-2 line-clamp-2">{question.question}</p>
                            <div className="flex flex-wrap gap-2 text-sm">
                              <Badge variant="outline">कक्षा {question.class}</Badge>
                              <Badge variant="outline">{question.subject}</Badge>
                              {question.chapter && <Badge variant="outline">{question.chapter}</Badge>}
                              <Badge variant="secondary">सही उत्तर: {question.correct_answer}</Badge>
                            </div>
                          </div>
                          <div className="flex gap-2 shrink-0">
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => handleEditIitjee(question)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="destructive"
                              size="icon"
                              onClick={() => setIitjeeToDelete(question)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Delete Content Dialog */}
      <AlertDialog open={!!contentToDelete} onOpenChange={() => setContentToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>सामग्री हटाएं?</AlertDialogTitle>
            <AlertDialogDescription>
              क्या आप वाकई "{contentToDelete?.title}" को हटाना चाहते हैं? यह क्रिया पूर्ववत नहीं की जा सकती।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>रद्द करें</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteContent}
              disabled={deleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  हटाया जा रहा है...
                </>
              ) : (
                'हटाएं'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete MCQ Dialog */}
      <AlertDialog open={!!mcqToDelete} onOpenChange={() => setMcqToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>MCQ प्रश्न हटाएं?</AlertDialogTitle>
            <AlertDialogDescription>
              क्या आप वाकई इस MCQ प्रश्न को हटाना चाहते हैं? यह क्रिया पूर्ववत नहीं की जा सकती।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deletingMcq}>रद्द करें</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteMcq}
              disabled={deletingMcq}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deletingMcq ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  हटाया जा रहा है...
                </>
              ) : (
                'हटाएं'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete IIT-JEE Dialog */}
      <AlertDialog open={!!iitjeeToDelete} onOpenChange={() => setIitjeeToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>IIT-JEE प्रश्न हटाएं?</AlertDialogTitle>
            <AlertDialogDescription>
              क्या आप वाकई इस IIT-JEE प्रश्न को हटाना चाहते हैं? यह क्रिया पूर्ववत नहीं की जा सकती।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deletingIitjee}>रद्द करें</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteIitjee}
              disabled={deletingIitjee}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deletingIitjee ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  हटाया जा रहा है...
                </>
              ) : (
                'हटाएं'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Edit MCQ Dialog */}
      <Dialog open={!!mcqToEdit} onOpenChange={() => setMcqToEdit(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>MCQ प्रश्न संपादित करें</DialogTitle>
            <DialogDescription>
              प्रश्न और विकल्पों को अपडेट करें
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-question">प्रश्न</Label>
              <Textarea
                id="edit-question"
                value={editForm.question || ''}
                onChange={(e) => setEditForm({ ...editForm, question: e.target.value })}
                rows={3}
                placeholder="प्रश्न दर्ज करें"
              />
            </div>
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-option-a">विकल्प A</Label>
                <Input
                  id="edit-option-a"
                  value={editForm.option_a || ''}
                  onChange={(e) => setEditForm({ ...editForm, option_a: e.target.value })}
                  placeholder="विकल्प A"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-option-b">विकल्प B</Label>
                <Input
                  id="edit-option-b"
                  value={editForm.option_b || ''}
                  onChange={(e) => setEditForm({ ...editForm, option_b: e.target.value })}
                  placeholder="विकल्प B"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-option-c">विकल्प C</Label>
                <Input
                  id="edit-option-c"
                  value={editForm.option_c || ''}
                  onChange={(e) => setEditForm({ ...editForm, option_c: e.target.value })}
                  placeholder="विकल्प C"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-option-d">विकल्प D</Label>
                <Input
                  id="edit-option-d"
                  value={editForm.option_d || ''}
                  onChange={(e) => setEditForm({ ...editForm, option_d: e.target.value })}
                  placeholder="विकल्प D"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-correct-answer">सही उत्तर</Label>
              <Select
                value={editForm.correct_answer || ''}
                onValueChange={(value: 'A' | 'B' | 'C' | 'D') => setEditForm({ ...editForm, correct_answer: value })}
              >
                <SelectTrigger id="edit-correct-answer">
                  <SelectValue placeholder="सही उत्तर चुनें" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A">A</SelectItem>
                  <SelectItem value="B">B</SelectItem>
                  <SelectItem value="C">C</SelectItem>
                  <SelectItem value="D">D</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setMcqToEdit(null)} disabled={editingMcq}>
              रद्द करें
            </Button>
            <Button onClick={handleSaveEditMcq} disabled={editingMcq}>
              {editingMcq ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  सहेजा जा रहा है...
                </>
              ) : (
                'सहेजें'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit IIT-JEE Dialog */}
      <Dialog open={!!iitjeeToEdit} onOpenChange={() => setIitjeeToEdit(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>IIT-JEE प्रश्न संपादित करें</DialogTitle>
            <DialogDescription>
              प्रश्न और विकल्पों को अपडेट करें
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-iitjee-question">प्रश्न</Label>
              <Textarea
                id="edit-iitjee-question"
                value={iitjeeEditForm.question || ''}
                onChange={(e) => setIitjeeEditForm({ ...iitjeeEditForm, question: e.target.value })}
                rows={3}
                placeholder="प्रश्न दर्ज करें"
              />
            </div>
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-iitjee-option-a">विकल्प A</Label>
                <Input
                  id="edit-iitjee-option-a"
                  value={iitjeeEditForm.option_a || ''}
                  onChange={(e) => setIitjeeEditForm({ ...iitjeeEditForm, option_a: e.target.value })}
                  placeholder="विकल्प A"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-iitjee-option-b">विकल्प B</Label>
                <Input
                  id="edit-iitjee-option-b"
                  value={iitjeeEditForm.option_b || ''}
                  onChange={(e) => setIitjeeEditForm({ ...iitjeeEditForm, option_b: e.target.value })}
                  placeholder="विकल्प B"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-iitjee-option-c">विकल्प C</Label>
                <Input
                  id="edit-iitjee-option-c"
                  value={iitjeeEditForm.option_c || ''}
                  onChange={(e) => setIitjeeEditForm({ ...iitjeeEditForm, option_c: e.target.value })}
                  placeholder="विकल्प C"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-iitjee-option-d">विकल्प D</Label>
                <Input
                  id="edit-iitjee-option-d"
                  value={iitjeeEditForm.option_d || ''}
                  onChange={(e) => setIitjeeEditForm({ ...iitjeeEditForm, option_d: e.target.value })}
                  placeholder="विकल्प D"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-iitjee-correct-answer">सही उत्तर</Label>
              <Select
                value={iitjeeEditForm.correct_answer || ''}
                onValueChange={(value: 'A' | 'B' | 'C' | 'D') => setIitjeeEditForm({ ...iitjeeEditForm, correct_answer: value })}
              >
                <SelectTrigger id="edit-iitjee-correct-answer">
                  <SelectValue placeholder="सही उत्तर चुनें" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A">A</SelectItem>
                  <SelectItem value="B">B</SelectItem>
                  <SelectItem value="C">C</SelectItem>
                  <SelectItem value="D">D</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIitjeeToEdit(null)} disabled={editingIitjee}>
              रद्द करें
            </Button>
            <Button onClick={handleSaveEditIitjee} disabled={editingIitjee}>
              {editingIitjee ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  सहेजा जा रहा है...
                </>
              ) : (
                'सहेजें'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Content Dialog */}
      <Dialog open={!!contentToEdit} onOpenChange={() => setContentToEdit(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>सामग्री संपादित करें</DialogTitle>
            <DialogDescription>
              सामग्री की जानकारी अपडेट करें
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-title">शीर्षक *</Label>
              <Input
                id="edit-title"
                value={contentEditForm.title || ''}
                onChange={(e) => setContentEditForm({ ...contentEditForm, title: e.target.value })}
                placeholder="सामग्री का शीर्षक"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="edit-class">कक्षा *</Label>
              <Select
                value={contentEditForm.class?.toString() || ''}
                onValueChange={(value) => setContentEditForm({ ...contentEditForm, class: parseInt(value) })}
              >
                <SelectTrigger id="edit-class">
                  <SelectValue placeholder="कक्षा चुनें" />
                </SelectTrigger>
                <SelectContent>
                  {CLASSES.map((cls) => (
                    <SelectItem key={cls} value={cls.toString()}>
                      {cls}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-subject">विषय *</Label>
              <Select
                value={contentEditForm.subject || ''}
                onValueChange={(value) => setContentEditForm({ ...contentEditForm, subject: value })}
              >
                <SelectTrigger id="edit-subject">
                  <SelectValue placeholder="विषय चुनें" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-chapter">अध्याय</Label>
              <Input
                id="edit-chapter"
                value={contentEditForm.chapter || ''}
                onChange={(e) => setContentEditForm({ ...contentEditForm, chapter: e.target.value })}
                placeholder="अध्याय का नाम (वैकल्पिक)"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-description">विवरण</Label>
              <Textarea
                id="edit-description"
                value={contentEditForm.description || ''}
                onChange={(e) => setContentEditForm({ ...contentEditForm, description: e.target.value })}
                rows={3}
                placeholder="सामग्री का विवरण (वैकल्पिक)"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="edit-filename">फ़ाइल नाम</Label>
              <Input
                id="edit-filename"
                value={contentEditForm.original_filename || ''}
                onChange={(e) => setContentEditForm({ ...contentEditForm, original_filename: e.target.value })}
                placeholder="फ़ाइल का नाम"
              />
              <p className="text-xs text-muted-foreground">
                यह नाम डाउनलोड करते समय उपयोग किया जाएगा
              </p>
            </div>
            
            {contentToEdit && (
              <div className="p-4 bg-muted rounded-lg space-y-2">
                <p className="text-sm font-medium">फ़ाइल जानकारी:</p>
                <div className="text-xs text-muted-foreground space-y-1">
                  <p>प्रकार: {contentToEdit.file_type}</p>
                  {contentToEdit.file_size && (
                    <p>आकार: {(contentToEdit.file_size / 1024 / 1024).toFixed(2)} MB</p>
                  )}
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setContentToEdit(null)} disabled={editingContent}>
              रद्द करें
            </Button>
            <Button onClick={handleSaveContentEdit} disabled={editingContent || !contentEditForm.title || !contentEditForm.class || !contentEditForm.subject}>
              {editingContent ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  सहेजा जा रहा है...
                </>
              ) : (
                'सहेजें'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Content Dialog - PDF */}
      {viewingContent && viewingContent.file_type.includes('pdf') && (
        <Dialog open={viewerOpen} onOpenChange={setViewerOpen}>
          <DialogContent className="max-w-6xl max-h-[95vh] p-0">
            <PDFViewer url={viewingContent.file_url} title={viewingContent.title} />
          </DialogContent>
        </Dialog>
      )}

      {/* View Content - Image */}
      {viewingContent && viewingContent.file_type.includes('image') && (
        <ImageViewer
          src={viewingContent.file_url}
          alt={viewingContent.title}
          open={imageViewerOpen}
          onClose={() => {
            setImageViewerOpen(false);
            setViewingContent(null);
          }}
        />
      )}

      {/* View Content Dialog - Other Files */}
      {viewingContent && !viewingContent.file_type.includes('pdf') && !viewingContent.file_type.includes('image') && (
        <Dialog open={viewerOpen} onOpenChange={setViewerOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{viewingContent.title}</DialogTitle>
              <DialogDescription>
                {viewingContent.subject} - {viewingContent.chapter}
              </DialogDescription>
            </DialogHeader>
            <div className="text-center py-8">
              <File className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-sm text-muted-foreground">
                इस फ़ाइल प्रकार का पूर्वावलोकन उपलब्ध नहीं है
              </p>
              <Button
                className="mt-4"
                onClick={() => window.open(viewingContent.file_url, '_blank')}
              >
                फ़ाइल खोलें
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* 3D Structure Delete Dialog */}
      <AlertDialog open={!!threeDToDelete} onOpenChange={() => setThreeDToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>क्या आप निश्चित हैं?</AlertDialogTitle>
            <AlertDialogDescription>
              यह 3D संरचना स्थायी रूप से हटा दी जाएगी। इस क्रिया को पूर्ववत नहीं किया जा सकता।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>रद्द करें</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDeleteThreeD}
              disabled={deletingThreeD}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deletingThreeD ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  हटाया जा रहा है...
                </>
              ) : (
                'हटाएं'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* External Note Delete Dialog */}
      <AlertDialog open={!!externalToDelete} onOpenChange={() => setExternalToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>क्या आप निश्चित हैं?</AlertDialogTitle>
            <AlertDialogDescription>
              यह बाहरी नोट्स स्थायी रूप से हटा दिए जाएंगे। इस क्रिया को पूर्ववत नहीं किया जा सकता।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>रद्द करें</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDeleteExternal}
              disabled={deletingExternal}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deletingExternal ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  हटाया जा रहा है...
                </>
              ) : (
                'हटाएं'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* 3D Structure View Dialog */}
      <Dialog open={!!threeDToView} onOpenChange={() => setThreeDToView(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>{threeDToView?.title}</DialogTitle>
            <DialogDescription>
              3D संरचना विवरण
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-semibold">कक्षा</Label>
                <p className="text-sm text-muted-foreground">कक्षा {threeDToView?.class}</p>
              </div>
              <div>
                <Label className="text-sm font-semibold">विषय</Label>
                <p className="text-sm text-muted-foreground">{threeDToView?.subject}</p>
              </div>
              <div>
                <Label className="text-sm font-semibold">अध्याय</Label>
                <p className="text-sm text-muted-foreground">{threeDToView?.chapter || 'N/A'}</p>
              </div>
              <div>
                <Label className="text-sm font-semibold">फ़ाइल प्रकार</Label>
                <p className="text-sm text-muted-foreground">{threeDToView?.file_type}</p>
              </div>
            </div>
            {threeDToView?.description && (
              <div>
                <Label className="text-sm font-semibold">विवरण</Label>
                <p className="text-sm text-muted-foreground">{threeDToView.description}</p>
              </div>
            )}
            {threeDToView?.thumbnail_url && (
              <div>
                <Label className="text-sm font-semibold">थंबनेल</Label>
                <img 
                  src={threeDToView.thumbnail_url} 
                  alt={threeDToView.title}
                  className="w-full max-h-48 object-contain rounded-md border mt-2"
                />
              </div>
            )}
            <div className="flex gap-2">
              <Button
                onClick={() => window.open(threeDToView?.file_url, '_blank')}
                className="flex-1"
              >
                <Eye className="h-4 w-4 mr-2" />
                फ़ाइल खोलें
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setThreeDToEdit(threeDToView);
                  setThreeDToView(null);
                }}
                className="flex-1"
              >
                <Edit className="h-4 w-4 mr-2" />
                संपादित करें
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* 3D Structure Edit Dialog */}
      <Dialog open={!!threeDToEdit} onOpenChange={() => setThreeDToEdit(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>3D संरचना संपादित करें</DialogTitle>
            <DialogDescription>
              3D संरचना की जानकारी अपडेट करें
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="edit-title">शीर्षक *</Label>
              <Input
                id="edit-title"
                value={threeDToEdit?.title || ''}
                onChange={(e) => setThreeDToEdit(threeDToEdit ? { ...threeDToEdit, title: e.target.value } : null)}
                placeholder="शीर्षक दर्ज करें"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-class">कक्षा *</Label>
                <Select
                  value={threeDToEdit?.class?.toString() || ''}
                  onValueChange={(value) => setThreeDToEdit(threeDToEdit ? { ...threeDToEdit, class: parseInt(value) } : null)}
                >
                  <SelectTrigger id="edit-class">
                    <SelectValue placeholder="कक्षा चुनें" />
                  </SelectTrigger>
                  <SelectContent>
                    {CLASSES.map((cls) => (
                      <SelectItem key={cls} value={cls.toString()}>
                        कक्षा {cls}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="edit-subject">विषय *</Label>
                <Input
                  id="edit-subject"
                  value={threeDToEdit?.subject || ''}
                  onChange={(e) => setThreeDToEdit(threeDToEdit ? { ...threeDToEdit, subject: e.target.value } : null)}
                  placeholder="विषय दर्ज करें"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="edit-chapter">अध्याय</Label>
              <Input
                id="edit-chapter"
                value={threeDToEdit?.chapter || ''}
                onChange={(e) => setThreeDToEdit(threeDToEdit ? { ...threeDToEdit, chapter: e.target.value } : null)}
                placeholder="अध्याय दर्ज करें"
              />
            </div>
            <div>
              <Label htmlFor="edit-description">विवरण</Label>
              <Textarea
                id="edit-description"
                value={threeDToEdit?.description || ''}
                onChange={(e) => setThreeDToEdit(threeDToEdit ? { ...threeDToEdit, description: e.target.value } : null)}
                placeholder="विवरण दर्ज करें"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setThreeDToEdit(null)}>
              रद्द करें
            </Button>
            <Button
              onClick={() => handleEdit3DStructure({
                title: threeDToEdit?.title,
                class: threeDToEdit?.class,
                subject: threeDToEdit?.subject,
                chapter: threeDToEdit?.chapter || undefined,
                description: threeDToEdit?.description || undefined,
              })}
              disabled={editingThreeD || !threeDToEdit?.title || !threeDToEdit?.class || !threeDToEdit?.subject}
            >
              {editingThreeD ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  सहेजा जा रहा है...
                </>
              ) : (
                'सहेजें'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
