import * as React from 'react';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/db/supabase';
import { MessageSquare, User, Mail, Calendar, Trash2 } from 'lucide-react';
import { formatDate } from '@/lib/constants';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

export default function AdminUserFeedbackPage() {
  const { toast } = useToast();
  const [feedbacks, setFeedbacks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFeedbacks();
  }, []);

  const loadFeedbacks = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('feedback')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setFeedbacks(data || []);
    } catch (error) {
      console.error('Error loading feedback:', error);
      toast({
        title: 'त्रुटि',
        description: 'फीडबैक लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('feedback')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      setFeedbacks(feedbacks.filter(f => f.id !== id));
      toast({
        title: 'सफलता',
        description: 'फीडबैक हटाया गया',
      });
    } catch (error) {
      console.error('Error deleting feedback:', error);
      toast({
        title: 'त्रुटि',
        description: 'फीडबैक हटाने में विफल',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="container mx-auto p-4 xl:p-6 max-w-6xl">
      <div className="mb-6">
        <h1 className="text-2xl xl:text-3xl font-bold flex items-center gap-2">
          <MessageSquare className="h-7 w-7 text-primary" />
          उपयोगकर्ता फीडबैक (About Page)
        </h1>
        <p className="text-muted-foreground mt-1">
          वेबसाइट के 'About' पेज से आए सभी फीडबैक यहाँ देखें
        </p>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-3/4 bg-muted" />
                <Skeleton className="h-4 w-1/2 bg-muted" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20 w-full bg-muted" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : feedbacks.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <MessageSquare className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold">कोई फीडबैक नहीं</h3>
            <p className="text-muted-foreground text-center">
              अभी तक कोई उपयोगकर्ता फीडबैक नहीं आया है
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {feedbacks.map((feedback) => (
            <Card key={feedback.id}>
              <CardHeader>
                <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-2">
                  <div className="flex-1">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <User className="h-4 w-4" />
                      {feedback.name}
                    </CardTitle>
                    <CardDescription className="flex flex-col gap-1 mt-1">
                      <span className="flex items-center gap-1">
                        <Mail className="h-3 w-3" />
                        {feedback.email}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {formatDate(feedback.created_at)}
                      </span>
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button size="icon" variant="destructive" className="h-8 w-8">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>क्या आप निश्चित हैं?</AlertDialogTitle>
                          <AlertDialogDescription>
                            यह फीडबैक स्थायी रूप से हटा दिया जाएगा।
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>रद्द करें</AlertDialogCancel>
                          <AlertDialogAction onClick={() => handleDelete(feedback.id)}>
                            हटाएं
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="bg-muted/30 p-4 rounded-lg">
                  <p className="text-sm whitespace-pre-wrap">{feedback.message}</p>
                </div>
                
                {feedback.user_profile && (
                  <div className="mt-4 pt-4 border-t border-border">
                    <h4 className="text-xs font-bold text-muted-foreground uppercase mb-2">उपयोगकर्ता विवरण:</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                      <div>
                        <span className="font-semibold">कक्षा:</span> {feedback.user_profile.student_class || 'N/A'}
                      </div>
                      <div>
                        <span className="font-semibold">स्कूल:</span> {feedback.user_profile.school_name || 'N/A'}
                      </div>
                      <div>
                        <span className="font-semibold">शहर:</span> {feedback.user_profile.city || 'N/A'}
                      </div>
                      <div>
                        <span className="font-semibold">पिनकोड:</span> {feedback.user_profile.pincode || 'N/A'}
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
