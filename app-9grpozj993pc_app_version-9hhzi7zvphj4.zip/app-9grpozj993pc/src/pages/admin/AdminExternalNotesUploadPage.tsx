import * as React from 'react';
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Upload, X, FileText } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { createExternalNote } from '@/db/api';
import { Progress } from '@/components/ui/progress';

interface FileWithProgress {
  file: File;
  progress: number;
  status: 'pending' | 'uploading' | 'success' | 'error';
  url?: string;
}

export default function AdminExternalNotesUploadPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [files, setFiles] = useState<FileWithProgress[]>([]);
  const [studentClass, setStudentClass] = useState('');
  const [subject, setSubject] = useState('');
  const [chapter, setChapter] = useState('');
  const [source, setSource] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [uploading, setUploading] = useState(false);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    
    // Validate file types (only PDFs)
    const invalidFiles = selectedFiles.filter(file => file.type !== 'application/pdf');
    if (invalidFiles.length > 0) {
      toast({
        title: 'त्रुटि',
        description: 'केवल PDF फ़ाइलें अपलोड करें',
        variant: 'destructive',
      });
      return;
    }
    
    const newFiles: FileWithProgress[] = selectedFiles.map(file => ({
      file,
      progress: 0,
      status: 'pending' as const,
    }));
    
    setFiles(prev => [...prev, ...newFiles]);
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const uploadFile = async (fileWithProgress: FileWithProgress, index: number): Promise<string> => {
    const { file } = fileWithProgress;
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
    const filePath = `external_notes/${fileName}`;

    // Update progress
    const progressInterval = setInterval(() => {
      setFiles(prev => prev.map((f, i) => 
        i === index && f.progress < 90
          ? { ...f, progress: f.progress + 10, status: 'uploading' as const }
          : f
      ));
    }, 200);

    try {
      const bucketName = 'app-9grpozj993pc_content_files';
      
      const { error: uploadError } = await supabase.storage
        .from(bucketName)
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false,
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from(bucketName)
        .getPublicUrl(filePath);

      clearInterval(progressInterval);
      setFiles(prev => prev.map((f, i) => 
        i === index
          ? { ...f, progress: 100, status: 'success' as const, url: publicUrl }
          : f
      ));

      return publicUrl;
    } catch (error) {
      clearInterval(progressInterval);
      setFiles(prev => prev.map((f, i) => 
        i === index
          ? { ...f, status: 'error' as const }
          : f
      ));
      throw error;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!studentClass || !subject || !chapter || !source || !title || files.length === 0) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया सभी आवश्यक फ़ील्ड भरें और फ़ाइल चुनें',
        variant: 'destructive',
      });
      return;
    }

    if (!user) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया लॉगिन करें',
        variant: 'destructive',
      });
      return;
    }

    setUploading(true);

    try {
      // Upload all files
      const uploadPromises = files.map((fileWithProgress, index) => 
        uploadFile(fileWithProgress, index)
      );
      
      const fileUrls = await Promise.all(uploadPromises);

      // Create database entries for each file
      for (let i = 0; i < fileUrls.length; i++) {
        const fileUrl = fileUrls[i];
        const file = files[i].file;
        
        await createExternalNote({
          class: parseInt(studentClass),
          subject,
          chapter,
          source,
          title: files.length > 1 ? `${title} - Part ${i + 1}` : title,
          description: description || null,
          file_url: fileUrl,
          file_type: file.type,
          uploaded_by: user.id,
        });
      }

      toast({
        title: 'सफलता',
        description: `${files.length} बाहरी नोट्स अपलोड किए गए`,
      });

      // Reset form
      setFiles([]);
      setStudentClass('');
      setSubject('');
      setChapter('');
      setSource('');
      setTitle('');
      setDescription('');
    } catch (error: any) {
      console.error('Upload error:', error);
      toast({
        title: 'अपलोड विफल',
        description: error.message || 'कुछ गलत हो गया',
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="container mx-auto p-4 max-w-4xl">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">बाहरी नोट्स अपलोड करें</CardTitle>
          <CardDescription>
            PW, RS Sir आदि के PDF नोट्स अपलोड करें
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Class */}
              <div className="space-y-2">
                <Label htmlFor="class">कक्षा *</Label>
                <Select value={studentClass} onValueChange={setStudentClass} disabled={uploading}>
                  <SelectTrigger>
                    <SelectValue placeholder="कक्षा चुनें" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="8">कक्षा 8</SelectItem>
                    <SelectItem value="9">कक्षा 9</SelectItem>
                    <SelectItem value="10">कक्षा 10</SelectItem>
                    <SelectItem value="11">कक्षा 11</SelectItem>
                    <SelectItem value="12">कक्षा 12</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Source */}
              <div className="space-y-2">
                <Label htmlFor="source">स्रोत *</Label>
                <Select value={source} onValueChange={setSource} disabled={uploading}>
                  <SelectTrigger>
                    <SelectValue placeholder="स्रोत चुनें" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PW">Physics Wallah (PW)</SelectItem>
                    <SelectItem value="RS Sir">RS Sir</SelectItem>
                    <SelectItem value="Unacademy">Unacademy</SelectItem>
                    <SelectItem value="Vedantu">Vedantu</SelectItem>
                    <SelectItem value="Disha Online">Disha Online</SelectItem>
                    <SelectItem value="Target Board">Target Board</SelectItem>
                    <SelectItem value="Other">अन्य</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Subject */}
              <div className="space-y-2">
                <Label htmlFor="subject">विषय *</Label>
                <Input
                  id="subject"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="जैसे: भौतिकी, रसायन विज्ञान"
                  disabled={uploading}
                  required
                />
              </div>

              {/* Chapter */}
              <div className="space-y-2">
                <Label htmlFor="chapter">अध्याय *</Label>
                <Input
                  id="chapter"
                  value={chapter}
                  onChange={(e) => setChapter(e.target.value)}
                  placeholder="अध्याय का नाम"
                  disabled={uploading}
                  required
                />
              </div>

              {/* Title */}
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="title">शीर्षक *</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="नोट्स का शीर्षक"
                  disabled={uploading}
                  required
                />
              </div>

              {/* Description */}
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="description">विवरण</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="नोट्स के बारे में विवरण (वैकल्पिक)"
                  disabled={uploading}
                  rows={3}
                />
              </div>
            </div>

            {/* File Upload */}
            <div className="space-y-4">
              <Label>PDF फ़ाइलें अपलोड करें *</Label>
              <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-colors">
                <input
                  type="file"
                  id="file-upload"
                  multiple
                  accept="application/pdf"
                  onChange={handleFileSelect}
                  disabled={uploading}
                  className="hidden"
                />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground mb-2">
                    PDF फ़ाइलें चुनने के लिए क्लिक करें या यहां खींचें
                  </p>
                  <p className="text-xs text-muted-foreground">
                    केवल PDF फ़ाइलें (.pdf)
                  </p>
                </label>
              </div>

              {/* File List */}
              {files.length > 0 && (
                <div className="space-y-2">
                  {files.map((fileWithProgress, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg"
                    >
                      <FileText className="h-8 w-8 text-primary shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">
                          {fileWithProgress.file.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {(fileWithProgress.file.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                        {fileWithProgress.status === 'uploading' && (
                          <Progress value={fileWithProgress.progress} className="mt-2" />
                        )}
                        {fileWithProgress.status === 'success' && (
                          <p className="text-xs text-green-600 mt-1">✓ अपलोड पूर्ण</p>
                        )}
                        {fileWithProgress.status === 'error' && (
                          <p className="text-xs text-destructive mt-1">✗ अपलोड विफल</p>
                        )}
                      </div>
                      {!uploading && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removeFile(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <Button
              type="submit"
              className="w-full"
              disabled={uploading || files.length === 0}
            >
              {uploading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  अपलोड हो रहा है...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  अपलोड करें
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
