import * as React from 'react';
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Navigate } from 'react-router-dom';
import { Upload, Loader2, Download, Trash2, CheckCircle, XCircle, Smartphone } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { getAllAPKFiles, createAPKFile, deleteAPKFile, deleteAPKFileFromStorage, updateAPKFile, uploadFile } from '@/db/api';
import type { APKFile } from '@/types/types';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';

export default function AdminAPKManagementPage() {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [apkFiles, setApkFiles] = useState<APKFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedAPK, setSelectedAPK] = useState<APKFile | null>(null);

  // Form state
  const [versionName, setVersionName] = useState('');
  const [versionCode, setVersionCode] = useState('');
  const [releaseNotes, setReleaseNotes] = useState('');
  const [apkFile, setApkFile] = useState<File | null>(null);

  useEffect(() => {
    loadAPKFiles();
  }, []);

  const loadAPKFiles = async () => {
    try {
      setLoading(true);
      const data = await getAllAPKFiles();
      setApkFiles(data as APKFile[]);
    } catch (error) {
      console.error('Error loading APK files:', error);
      toast({
        title: 'त्रुटि',
        description: 'APK फाइलें लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.name.endsWith('.apk')) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया एक वैध APK फ़ाइल चुनें',
        variant: 'destructive',
      });
      return;
    }

    // Validate file size (max 100MB)
    if (file.size > 100 * 1024 * 1024) {
      toast({
        title: 'त्रुटि',
        description: 'APK फ़ाइल का आकार 100MB से कम होना चाहिए',
        variant: 'destructive',
      });
      return;
    }

    setApkFile(file);
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!versionName || !versionCode || !apkFile) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया सभी आवश्यक फ़ील्ड भरें',
        variant: 'destructive',
      });
      return;
    }

    const versionCodeNum = parseInt(versionCode);
    if (isNaN(versionCodeNum) || versionCodeNum <= 0) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया एक वैध वर्जन कोड दर्ज करें',
        variant: 'destructive',
      });
      return;
    }

    setUploading(true);
    try {
      // Upload APK file to storage using robust helper
      const fileName = `pm_roit_v${versionName.replace(/\./g, '_')}_${Date.now()}.apk`;
      const filePath = `apk/${fileName}`;

      console.log('Uploading APK via helper:', filePath);

      // This helper handles file renaming and public URL retrieval
      const publicUrl = await uploadFile('apk-files', filePath, apkFile);

      console.log('Upload Success, Public URL:', publicUrl);

      // Create database record
      await createAPKFile({
        version_name: versionName,
        version_code: versionCodeNum,
        file_name: fileName,
        file_path: filePath,
        file_size: apkFile.size,
        download_url: publicUrl,
        release_notes: releaseNotes || undefined,
        uploaded_by: profile?.id || '',
      });

      toast({
        title: 'सफलता',
        description: 'APK फ़ाइल सफलतापूर्वक अपलोड हो गई',
      });

      // Reset form
      setVersionName('');
      setVersionCode('');
      setReleaseNotes('');
      setApkFile(null);
      
      // Reset file input
      const fileInput = document.getElementById('apk-file-input') as HTMLInputElement;
      if (fileInput) fileInput.value = '';

      // Reload list
      loadAPKFiles();
    } catch (error: any) {
      console.error('Error uploading APK:', error);
      toast({
        title: 'त्रुटि',
        description: error.message || 'APK अपलोड करने में विफल। कृपया अपनी अनुमति (Permission) और इंटरनेट की जांच करें।',
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async () => {
    if (!selectedAPK) return;

    try {
      // Delete from storage
      await deleteAPKFileFromStorage(selectedAPK.file_path);

      // Delete from database
      await deleteAPKFile(selectedAPK.id);

      toast({
        title: 'सफलता',
        description: 'APK फ़ाइल सफलतापूर्वक हटा दी गई',
      });

      setDeleteDialogOpen(false);
      setSelectedAPK(null);
      loadAPKFiles();
    } catch (error) {
      console.error('Error deleting APK:', error);
      toast({
        title: 'त्रुटि',
        description: 'APK हटाने में विफल',
        variant: 'destructive',
      });
    }
  };

  const handleToggleActive = async (apk: APKFile) => {
    try {
      await updateAPKFile(apk.id, { is_active: !apk.is_active });
      
      toast({
        title: 'सफलता',
        description: apk.is_active ? 'APK निष्क्रिय कर दिया गया' : 'APK सक्रिय कर दिया गया',
      });

      loadAPKFiles();
    } catch (error) {
      console.error('Error toggling APK status:', error);
      toast({
        title: 'त्रुटि',
        description: 'स्थिति बदलने में विफल',
        variant: 'destructive',
      });
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(2)} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  // Redirect if not admin
  if (profile?.role !== 'admin') {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <div className="container mx-auto p-4 xl:p-6 max-w-6xl space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
          <Smartphone className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl xl:text-3xl font-bold gradient-text">APK प्रबंधन</h1>
          <p className="text-sm text-muted-foreground">ऐप APK फाइलें अपलोड और प्रबंधित करें</p>
        </div>
      </div>

      {/* Upload Form */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            नया APK अपलोड करें
          </CardTitle>
          <CardDescription>
            नया ऐप वर्जन अपलोड करें जिसे यूजर्स डाउनलोड कर सकें
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleUpload} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="version-name">वर्जन नाम *</Label>
                <Input
                  id="version-name"
                  placeholder="उदाहरण: 1.0.0"
                  value={versionName}
                  onChange={(e) => setVersionName(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="version-code">वर्जन कोड *</Label>
                <Input
                  id="version-code"
                  type="number"
                  placeholder="उदाहरण: 1"
                  value={versionCode}
                  onChange={(e) => setVersionCode(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="release-notes">रिलीज नोट्स (वैकल्पिक)</Label>
              <Textarea
                id="release-notes"
                placeholder="इस वर्जन में क्या नया है..."
                value={releaseNotes}
                onChange={(e) => setReleaseNotes(e.target.value)}
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="apk-file-input">APK फ़ाइल * (अधिकतम 100MB)</Label>
              <Input
                id="apk-file-input"
                type="file"
                accept=".apk"
                onChange={handleFileSelect}
                required
              />
              {apkFile && (
                <p className="text-sm text-muted-foreground">
                  चयनित: {apkFile.name} ({formatFileSize(apkFile.size)})
                </p>
              )}
            </div>

            <Button type="submit" disabled={uploading} className="w-full md:w-auto">
              {uploading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  अपलोड हो रहा है...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  APK अपलोड करें
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* APK Files List */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle>अपलोड की गई APK फाइलें</CardTitle>
          <CardDescription>
            सभी अपलोड की गई APK फाइलों की सूची
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : apkFiles.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Smartphone className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>कोई APK फ़ाइल अपलोड नहीं की गई</p>
            </div>
          ) : (
            <div className="space-y-4">
              {apkFiles.map((apk) => (
                <div
                  key={apk.id}
                  className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-lg border bg-card"
                >
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold">वर्जन {apk.version_name}</h3>
                      <Badge variant={apk.is_active ? 'default' : 'secondary'}>
                        {apk.is_active ? (
                          <>
                            <CheckCircle className="w-3 h-3 mr-1" />
                            सक्रिय
                          </>
                        ) : (
                          <>
                            <XCircle className="w-3 h-3 mr-1" />
                            निष्क्रिय
                          </>
                        )}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        कोड: {apk.version_code}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {apk.file_name} • {formatFileSize(apk.file_size)}
                    </p>
                    {apk.release_notes && (
                      <p className="text-sm text-muted-foreground mt-2">
                        {apk.release_notes}
                      </p>
                    )}
                    <p className="text-xs text-muted-foreground">
                      अपलोड: {new Date(apk.created_at).toLocaleDateString('hi-IN')}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(apk.download_url, '_blank')}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      डाउनलोड
                    </Button>
                    <Button
                      variant={apk.is_active ? 'secondary' : 'default'}
                      size="sm"
                      onClick={() => handleToggleActive(apk)}
                    >
                      {apk.is_active ? 'निष्क्रिय करें' : 'सक्रिय करें'}
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        setSelectedAPK(apk);
                        setDeleteDialogOpen(true);
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>क्या आप निश्चित हैं?</AlertDialogTitle>
            <AlertDialogDescription>
              यह APK फ़ाइल स्थायी रूप से हटा दी जाएगी। यह क्रिया पूर्ववत नहीं की जा सकती।
              {selectedAPK && (
                <div className="mt-2 p-2 bg-muted rounded text-sm">
                  <strong>वर्जन:</strong> {selectedAPK.version_name} (कोड: {selectedAPK.version_code})
                </div>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>रद्द करें</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              हटाएं
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
