import * as React from 'react';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/db/supabase';
import { ArrowLeft, Save, Loader2, Settings, Plus, Trash2, User, Upload, Image as ImageIcon } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import imageCompression from 'browser-image-compression';

interface FAQ {
  question: string;
  answer: string;
}

interface FounderInfo {
  name: string;
  title: string;
  image_url: string;
  message: string;
}

interface AboutSettings {
  app_name: string;
  app_description: string;
  contact_email: string;
  contact_phone: string;
  whatsapp: string;
  youtube_url: string;
  instagram_url: string;
  facebook_url?: string;
  twitter_url?: string;
  founder?: FounderInfo;
  mission?: string;
  vision?: string;
  faqs?: FAQ[];
}

export default function AdminAboutSettingsPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [settings, setSettings] = useState<AboutSettings>({
    app_name: 'PM - Roit Study Hub',
    app_description: 'कक्षा 8-12 के छात्रों के लिए संपूर्ण अध्ययन सामग्री',
    contact_email: 'support@pmroit.com',
    contact_phone: '+91 9876543210',
    whatsapp: '+91 9876543210',
    youtube_url: 'https://youtube.com/@pmroit',
    instagram_url: 'https://instagram.com/pmroit',
    facebook_url: 'https://facebook.com/pmroit',
    twitter_url: 'https://twitter.com/pmroit',
    founder: {
      name: '',
      title: '',
      image_url: '',
      message: '',
    },
    mission: '',
    vision: '',
    faqs: [],
  });

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('admin_settings')
        .select('setting_value')
        .eq('setting_key', 'about_page')
        .single();

      if (error) throw error;
      if (data) {
        setSettings(data.setting_value as AboutSettings);
      }
    } catch (error) {
      console.error('Error loading settings:', error);
      toast({
        title: 'त्रुटि',
        description: 'सेटिंग्स लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('admin_settings')
        .update({
          setting_value: settings,
          updated_at: new Date().toISOString(),
        })
        .eq('setting_key', 'about_page');

      if (error) throw error;

      toast({
        title: 'सफलता',
        description: 'सेटिंग्स सफलतापूर्वक अपडेट की गई',
      });
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: 'त्रुटि',
        description: 'सेटिंग्स सहेजने में विफल',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const updateField = (field: keyof AboutSettings, value: string) => {
    setSettings(prev => ({ ...prev, [field]: value }));
  };

  const updateFounderField = (field: keyof FounderInfo, value: string) => {
    setSettings(prev => ({
      ...prev,
      founder: {
        ...prev.founder!,
        [field]: value,
      },
    }));
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast({
        title: 'अमान्य फ़ाइल',
        description: 'कृपया केवल इमेज फ़ाइल अपलोड करें',
        variant: 'destructive',
      });
      return;
    }

    setUploading(true);
    try {
      let fileToUpload = file;
      
      // Auto-compression if > 1MB
      if (file.size > 1024 * 1024) {
        toast({
          title: 'कंप्रेशन',
          description: 'इमेज बड़ी है, इसे छोटा किया जा रहा है...',
        });
        
        // Simple canvas compression
        const bitmap = await createImageBitmap(file);
        const canvas = document.createElement('canvas');
        let width = bitmap.width;
        let height = bitmap.height;
        
        // Max 1080p
        const maxDim = 1080;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = (height / width) * maxDim;
            width = maxDim;
          } else {
            width = (width / height) * maxDim;
            height = maxDim;
          }
        }
        
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(bitmap, 0, 0, width, height);
        
        const blob = await new Promise<Blob>((resolve) => {
          canvas.toBlob((b) => resolve(b!), 'image/webp', 0.8);
        });
        
        fileToUpload = new File([blob], `founder_${Date.now()}.webp`, { type: 'image/webp' });
        
        toast({
          title: 'कंप्रेशन सफल',
          description: `नया साइज़: ${(fileToUpload.size / 1024 / 1024).toFixed(2)} MB`,
        });
      }

      const fileName = `founder_${Date.now()}_${fileToUpload.name.replace(/[^a-zA-Z0-9.]/g, '')}`;
      const filePath = `about/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('app-9grpozj993pc_app_assets')
        .upload(filePath, fileToUpload);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('app-9grpozj993pc_app_assets')
        .getPublicUrl(filePath);

      updateFounderField('image_url', publicUrl);
      
      toast({
        title: 'सफलता',
        description: 'फोटो अपलोड हो गई',
      });
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: 'त्रुटि',
        description: 'फोटो अपलोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
    }
  };

  const addFAQ = () => {
    setSettings(prev => ({
      ...prev,
      faqs: [...(prev.faqs || []), { question: '', answer: '' }],
    }));
  };

  const updateFAQ = (index: number, field: 'question' | 'answer', value: string) => {
    setSettings(prev => ({
      ...prev,
      faqs: prev.faqs?.map((faq, i) => 
        i === index ? { ...faq, [field]: value } : faq
      ) || [],
    }));
  };

  const removeFAQ = (index: number) => {
    setSettings(prev => ({
      ...prev,
      faqs: prev.faqs?.filter((_, i) => i !== index) || [],
    }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 xl:p-6 max-w-4xl">
      <Card className="glass-card">
        <CardHeader className="border-b border-border/50">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/admin')}
              className="shrink-0"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <CardTitle className="text-xl xl:text-2xl flex items-center gap-2">
                <Settings className="h-6 w-6" />
                About Page Settings
              </CardTitle>
              <CardDescription className="mt-1">
                About पेज की जानकारी और संपर्क विवरण संपादित करें
              </CardDescription>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-4 xl:p-6 space-y-6">
          {/* App Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">ऐप जानकारी</h3>
            
            <div className="space-y-2">
              <Label htmlFor="app_name">ऐप का नाम</Label>
              <Input
                id="app_name"
                value={settings.app_name}
                onChange={(e) => updateField('app_name', e.target.value)}
                placeholder="PM - Roit Study Hub"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="app_description">ऐप विवरण</Label>
              <Textarea
                id="app_description"
                value={settings.app_description}
                onChange={(e) => updateField('app_description', e.target.value)}
                placeholder="कक्षा 8-12 के छात्रों के लिए संपूर्ण अध्ययन सामग्री"
                className="min-h-[80px]"
              />
            </div>
          </div>

          {/* Contact Details */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">संपर्क विवरण</h3>
            
            <div className="space-y-2">
              <Label htmlFor="contact_email">ईमेल</Label>
              <Input
                id="contact_email"
                type="email"
                value={settings.contact_email}
                onChange={(e) => updateField('contact_email', e.target.value)}
                placeholder="support@pmroit.com"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contact_phone">फ़ोन नंबर</Label>
              <Input
                id="contact_phone"
                value={settings.contact_phone}
                onChange={(e) => updateField('contact_phone', e.target.value)}
                placeholder="+91 9876543210"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="whatsapp">व्हाट्सएप नंबर</Label>
              <Input
                id="whatsapp"
                value={settings.whatsapp}
                onChange={(e) => updateField('whatsapp', e.target.value)}
                placeholder="+91 9876543210"
              />
            </div>
          </div>

          {/* Social Media Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">सोशल मीडिया लिंक</h3>
            
            <div className="space-y-2">
              <Label htmlFor="youtube_url">YouTube URL</Label>
              <Input
                id="youtube_url"
                value={settings.youtube_url}
                onChange={(e) => updateField('youtube_url', e.target.value)}
                placeholder="https://youtube.com/@pmroit"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="instagram_url">Instagram URL</Label>
              <Input
                id="instagram_url"
                value={settings.instagram_url}
                onChange={(e) => updateField('instagram_url', e.target.value)}
                placeholder="https://instagram.com/pmroit"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="facebook_url">Facebook URL (वैकल्पिक)</Label>
              <Input
                id="facebook_url"
                value={settings.facebook_url || ''}
                onChange={(e) => updateField('facebook_url', e.target.value)}
                placeholder="https://facebook.com/pmroit"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="twitter_url">Twitter URL (वैकल्पिक)</Label>
              <Input
                id="twitter_url"
                value={settings.twitter_url || ''}
                onChange={(e) => updateField('twitter_url', e.target.value)}
                placeholder="https://twitter.com/pmroit"
              />
            </div>
          </div>

          <Separator className="my-6" />

          {/* Founder Information */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <User className="h-5 w-5" />
              <h3 className="text-lg font-semibold">संस्थापक जानकारी</h3>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="founder_name">संस्थापक का नाम</Label>
              <Input
                id="founder_name"
                value={settings.founder?.name || ''}
                onChange={(e) => updateFounderField('name', e.target.value)}
                placeholder="उदा: Nizam"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="founder_title">पद/उपाधि</Label>
              <Input
                id="founder_title"
                value={settings.founder?.title || ''}
                onChange={(e) => updateFounderField('title', e.target.value)}
                placeholder="उदा: Founder of PM Roit"
              />
            </div>

            <div className="space-y-4">
              <Label>संस्थापक की फोटो</Label>
              <div className="flex flex-col items-center gap-4 p-4 border-2 border-dashed border-border rounded-xl bg-muted/30">
                {settings.founder?.image_url ? (
                  <div className="relative group">
                    <img
                      src={settings.founder.image_url}
                      alt="Founder Preview"
                      className="h-32 w-32 rounded-full object-cover border-4 border-primary/20 shadow-lg"
                    />
                    <div className="absolute inset-0 bg-black/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-white hover:text-white"
                        onClick={() => fileInputRef.current?.click()}
                        disabled={uploading}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        बदलें
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div 
                    className="h-32 w-32 rounded-full bg-muted flex flex-col items-center justify-center cursor-pointer hover:bg-muted/80 transition-colors"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <ImageIcon className="h-10 w-10 text-muted-foreground mb-2" />
                    <span className="text-xs text-muted-foreground font-medium">फोटो जोड़ें</span>
                  </div>
                )}
                
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageUpload}
                  accept="image/*"
                  className="hidden"
                />
                
                <div className="text-center">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploading}
                    className="h-9"
                  >
                    {uploading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        अपलोड हो रहा है...
                      </>
                    ) : (
                      <>
                        <Upload className="mr-2 h-4 w-4" />
                        {settings.founder?.image_url ? 'फोटो बदलें' : 'फोटो अपलोड करें'}
                      </>
                    )}
                  </Button>
                  <p className="text-[10px] text-muted-foreground mt-2">
                    अधिकतम साइज़: 1MB (बड़ी फोटो खुद छोटी हो जाएगी)
                  </p>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="founder_image">फोटो URL (वैकल्पिक)</Label>
                <Input
                  id="founder_image"
                  value={settings.founder?.image_url || ''}
                  onChange={(e) => updateFounderField('image_url', e.target.value)}
                  placeholder="https://example.com/founder-photo.jpg"
                />
                <p className="text-[10px] text-muted-foreground">
                  ऊपर फोटो अपलोड करें या यहां सीधा URL पेस्ट करें।
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="founder_message">संदेश</Label>
              <Textarea
                id="founder_message"
                value={settings.founder?.message || ''}
                onChange={(e) => updateFounderField('message', e.target.value)}
                placeholder="संस्थापक का संदेश यहां लिखें..."
                className="min-h-[120px]"
              />
            </div>
          </div>

          <Separator className="my-6" />

          {/* Mission & Vision */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">मिशन और विजन</h3>
            
            <div className="space-y-2">
              <Label htmlFor="mission">मिशन</Label>
              <Textarea
                id="mission"
                value={settings.mission || ''}
                onChange={(e) => updateField('mission', e.target.value)}
                placeholder="संगठन का मिशन यहां लिखें..."
                className="min-h-[100px]"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="vision">विजन</Label>
              <Textarea
                id="vision"
                value={settings.vision || ''}
                onChange={(e) => updateField('vision', e.target.value)}
                placeholder="संगठन का विजन यहां लिखें..."
                className="min-h-[100px]"
              />
            </div>
          </div>

          <Separator className="my-6" />

          {/* FAQs */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">अक्सर पूछे जाने वाले प्रश्न (FAQs)</h3>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addFAQ}
              >
                <Plus className="mr-2 h-4 w-4" />
                FAQ जोड़ें
              </Button>
            </div>

            {settings.faqs && settings.faqs.length > 0 ? (
              <div className="space-y-4">
                {settings.faqs.map((faq, index) => (
                  <Card key={index} className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label className="text-sm font-medium">FAQ #{index + 1}</Label>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removeFAQ(index)}
                          className="h-8 w-8 text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor={`faq_question_${index}`}>प्रश्न</Label>
                        <Input
                          id={`faq_question_${index}`}
                          value={faq.question}
                          onChange={(e) => updateFAQ(index, 'question', e.target.value)}
                          placeholder="प्रश्न यहां लिखें..."
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor={`faq_answer_${index}`}>उत्तर</Label>
                        <Textarea
                          id={`faq_answer_${index}`}
                          value={faq.answer}
                          onChange={(e) => updateFAQ(index, 'answer', e.target.value)}
                          placeholder="उत्तर यहां लिखें..."
                          className="min-h-[80px]"
                        />
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">
                कोई FAQ नहीं। ऊपर बटन से FAQ जोड़ें।
              </p>
            )}
          </div>

          {/* Save Button */}
          <div className="flex justify-end pt-4 border-t border-border/50">
            <Button
              onClick={handleSave}
              disabled={saving}
              className="bg-gradient-to-r from-primary to-secondary"
            >
              {saving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  सहेजा जा रहा है...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  सेटिंग्स सहेजें
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
