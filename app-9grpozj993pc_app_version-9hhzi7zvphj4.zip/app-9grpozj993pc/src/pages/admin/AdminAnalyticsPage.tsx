import * as React from 'react';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { getContentAnalytics, getUserActivityStats } from '@/db/api';
import { BarChart3, TrendingUp, Users, Eye, Download } from 'lucide-react';
import { getCategoryInfo } from '@/lib/constants';

interface ContentAnalytics {
  views: Array<{
    content_id: string;
    content: Array<{
      title: string;
      category: string;
    }>;
  }>;
  downloads: Array<{
    content_id: string;
    content: Array<{
      title: string;
      category: string;
    }>;
  }>;
}

interface UserStats {
  id: string;
  full_name: string;
  email: string;
  student_class: number | null;
  created_at: string;
}

export default function AdminAnalyticsPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [analytics, setAnalytics] = useState<ContentAnalytics | null>(null);
  const [userStats, setUserStats] = useState<UserStats[]>([]);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    setLoading(true);
    try {
      const [analyticsData, usersData] = await Promise.all([
        getContentAnalytics(),
        getUserActivityStats(),
      ]);
      setAnalytics(analyticsData as ContentAnalytics);
      setUserStats(usersData as UserStats[]);
    } catch (error) {
      console.error('Error loading analytics:', error);
      toast({
        title: 'त्रुटि',
        description: 'Analytics लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  // Calculate top content
  const getTopContent = (data: Array<{ content_id: string; content: any }>, limit = 10) => {
    const counts = data.reduce((acc, item) => {
      const id = item.content_id;
      acc[id] = (acc[id] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(counts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, limit)
      .map(([contentId, count]) => {
        const item = data.find(d => d.content_id === contentId);
        const contentArray = item?.content;
        const contentItem = Array.isArray(contentArray) && contentArray.length > 0 ? contentArray[0] : null;
        return {
          contentId,
          count,
          content: contentItem,
        };
      });
  };

  const topViewed = analytics ? getTopContent(analytics.views) : [];
  const topDownloaded = analytics ? getTopContent(analytics.downloads) : [];

  // User stats
  const totalUsers = userStats.length;
  const usersThisMonth = userStats.filter(u => {
    const created = new Date(u.created_at);
    const now = new Date();
    return created.getMonth() === now.getMonth() && created.getFullYear() === now.getFullYear();
  }).length;

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center animate-float">
            <BarChart3 className="h-8 w-8 text-white" />
          </div>
        </div>
        <h1 className="text-3xl font-bold gradient-text">Analytics Dashboard</h1>
        <p className="text-muted-foreground">
          ऐप की performance और user activity देखें
        </p>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardDescription className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              कुल Users
            </CardDescription>
            <CardTitle className="text-3xl">{totalUsers}</CardTitle>
          </CardHeader>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardDescription className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              इस महीने नए
            </CardDescription>
            <CardTitle className="text-3xl">{usersThisMonth}</CardTitle>
          </CardHeader>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardDescription className="flex items-center gap-2">
              <Eye className="h-4 w-4" />
              कुल Views
            </CardDescription>
            <CardTitle className="text-3xl">
              {analytics?.views.length || 0}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardDescription className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              कुल Downloads
            </CardDescription>
            <CardTitle className="text-3xl">
              {analytics?.downloads.length || 0}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Top Viewed Content */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" />
              सबसे ज्यादा देखी गई सामग्री
            </CardTitle>
            <CardDescription>Top 10 most viewed content</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Skeleton key={i} className="h-16 w-full bg-muted" />
                ))}
              </div>
            ) : topViewed.length > 0 ? (
              <div className="space-y-3">
                {topViewed.map((item, index) => {
                  const categoryInfo = getCategoryInfo(item.content?.category);
                  return (
                    <div
                      key={item.contentId}
                      className="flex items-center gap-3 p-3 rounded-lg bg-muted/30"
                    >
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold text-sm">
                        {index + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">
                          {item.content?.title || 'Unknown'}
                        </p>
                        <Badge variant="outline" className="mt-1">
                          {categoryInfo?.name || item.content?.category}
                        </Badge>
                      </div>
                      <Badge variant="secondary">{item.count} views</Badge>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">
                कोई data नहीं
              </p>
            )}
          </CardContent>
        </Card>

        {/* Top Downloaded Content */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="h-5 w-5" />
              सबसे ज्यादा डाउनलोड की गई सामग्री
            </CardTitle>
            <CardDescription>Top 10 most downloaded content</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Skeleton key={i} className="h-16 w-full bg-muted" />
                ))}
              </div>
            ) : topDownloaded.length > 0 ? (
              <div className="space-y-3">
                {topDownloaded.map((item, index) => {
                  const categoryInfo = getCategoryInfo(item.content?.category);
                  return (
                    <div
                      key={item.contentId}
                      className="flex items-center gap-3 p-3 rounded-lg bg-muted/30"
                    >
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold text-sm">
                        {index + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">
                          {item.content?.title || 'Unknown'}
                        </p>
                        <Badge variant="outline" className="mt-1">
                          {categoryInfo?.name || item.content?.category}
                        </Badge>
                      </div>
                      <Badge variant="secondary">{item.count} downloads</Badge>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">
                कोई data नहीं
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* User Distribution by Class */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle>कक्षा के अनुसार Users</CardTitle>
          <CardDescription>User distribution by class</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-32 w-full bg-muted" />
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-4">
              {[8, 9, 10, 11, 12].map((cls) => {
                const count = userStats.filter(u => u.student_class === cls).length;
                return (
                  <div key={cls} className="text-center p-4 rounded-lg bg-muted/30">
                    <p className="text-2xl font-bold">{count}</p>
                    <p className="text-sm text-muted-foreground">कक्षा {cls}</p>
                  </div>
                );
              })}
              <div className="text-center p-4 rounded-lg bg-muted/30">
                <p className="text-2xl font-bold">
                  {userStats.filter(u => !u.student_class).length}
                </p>
                <p className="text-sm text-muted-foreground">अन्य</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
