import * as React from 'react';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { getAllPremiumFeatures, updatePremiumFeature, getAllProfiles, updateUserPremiumStatus } from '@/db/api';
import { Loader2, Crown, Users, CheckCircle, XCircle, Calendar } from 'lucide-react';
import type { PremiumFeature, Profile } from '@/types/types';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function AdminPremiumFeaturesPage() {
  const { toast } = useToast();
  const [features, setFeatures] = useState<PremiumFeature[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState<string | null>(null);
  const [userDialogOpen, setUserDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<Profile | null>(null);
  const [premiumDuration, setPremiumDuration] = useState<string>('30');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [featuresData, usersData] = await Promise.all([
        getAllPremiumFeatures(),
        getAllProfiles(),
      ]);
      setFeatures(featuresData);
      setUsers(usersData);
    } catch (error) {
      console.error('Error loading data:', error);
      toast({
        title: 'त्रुटि',
        description: 'डेटा लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleFeatureToggle = async (feature: PremiumFeature, field: 'is_enabled' | 'is_premium') => {
    try {
      setUpdating(feature.id);
      const updates = { [field]: !feature[field] };
      await updatePremiumFeature(feature.id, updates);
      
      setFeatures(prev => prev.map(f => 
        f.id === feature.id ? { ...f, ...updates } : f
      ));
      
      toast({
        title: 'सफलता',
        description: 'फीचर अपडेट किया गया',
      });
    } catch (error) {
      console.error('Error updating feature:', error);
      toast({
        title: 'त्रुटि',
        description: 'फीचर अपडेट करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setUpdating(null);
    }
  };

  const handleUserPremiumUpdate = async () => {
    if (!selectedUser) return;
    
    try {
      setUpdating(selectedUser.id);
      const isPremium = !selectedUser.is_premium;
      let expiresAt: string | null = null;
      
      if (isPremium && premiumDuration !== 'lifetime') {
        const days = parseInt(premiumDuration);
        const expiry = new Date();
        expiry.setDate(expiry.getDate() + days);
        expiresAt = expiry.toISOString();
      }
      
      await updateUserPremiumStatus(selectedUser.id, isPremium, expiresAt);
      
      setUsers(prev => prev.map(u => 
        u.id === selectedUser.id 
          ? { ...u, is_premium: isPremium, premium_expires_at: expiresAt } 
          : u
      ));
      
      toast({
        title: 'सफलता',
        description: `${selectedUser.full_name || selectedUser.email} का प्रीमियम स्टेटस अपडेट किया गया`,
      });
      
      setUserDialogOpen(false);
      setSelectedUser(null);
    } catch (error) {
      console.error('Error updating user premium:', error);
      toast({
        title: 'त्रुटि',
        description: 'प्रीमियम स्टेटस अपडेट करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setUpdating(null);
    }
  };

  const premiumUsers = users.filter(u => u.is_premium);
  const regularUsers = users.filter(u => !u.is_premium);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 xl:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4">
        <div>
          <h1 className="text-2xl xl:text-3xl font-bold">प्रीमियम फीचर प्रबंधन</h1>
          <p className="text-muted-foreground mt-1">
            प्रीमियम फीचर्स और यूजर्स को प्रबंधित करें
          </p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid gap-4 grid-cols-1 xl:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">कुल फीचर्स</CardTitle>
            <Crown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{features.length}</div>
            <p className="text-xs text-muted-foreground">
              {features.filter(f => f.is_premium).length} प्रीमियम
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">प्रीमियम यूजर्स</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{premiumUsers.length}</div>
            <p className="text-xs text-muted-foreground">
              कुल {users.length} में से
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">सक्रिय फीचर्स</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {features.filter(f => f.is_enabled).length}
            </div>
            <p className="text-xs text-muted-foreground">
              {features.length} में से
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Features Management */}
      <Card>
        <CardHeader>
          <CardTitle>फीचर्स कॉन्फ़िगरेशन</CardTitle>
          <CardDescription>
            प्रत्येक फीचर को सक्षम/अक्षम करें और प्रीमियम स्टेटस सेट करें। 
            <span className="block mt-1 text-primary font-medium">
              ✨ प्रीमियम यूजर्स को विशेष थीम मिलती है जिसमें सॉफ्ट ग्लो इफेक्ट और किंग आइकन शामिल है!
            </span>
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {features.map((feature) => (
            <div key={feature.id} className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 p-4 border rounded-lg">
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold">{feature.feature_name}</h3>
                  {feature.is_premium && (
                    <Badge variant="default" className="gap-1">
                      <Crown className="h-3 w-3" />
                      प्रीमियम
                    </Badge>
                  )}
                  {!feature.is_enabled && (
                    <Badge variant="secondary">
                      निष्क्रिय
                    </Badge>
                  )}
                </div>
                {feature.description && (
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                )}
                <p className="text-xs text-muted-foreground">
                  Key: <code className="bg-muted px-1 py-0.5 rounded">{feature.feature_key}</code>
                </p>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={feature.is_enabled}
                    onCheckedChange={() => handleFeatureToggle(feature, 'is_enabled')}
                    disabled={updating === feature.id}
                  />
                  <Label className="text-sm">सक्षम</Label>
                </div>
                
                <Separator orientation="vertical" className="h-8" />
                
                <div className="flex items-center gap-2">
                  <Switch
                    checked={feature.is_premium}
                    onCheckedChange={() => handleFeatureToggle(feature, 'is_premium')}
                    disabled={updating === feature.id}
                  />
                  <Label className="text-sm">प्रीमियम</Label>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Users Management */}
      <div className="grid gap-6 grid-cols-1 xl:grid-cols-2">
        {/* Premium Users */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Crown className="h-5 w-5 text-primary" />
              प्रीमियम यूजर्स
            </CardTitle>
            <CardDescription>
              {premiumUsers.length} प्रीमियम यूजर्स
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2 max-h-[400px] overflow-y-auto">
            {premiumUsers.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                कोई प्रीमियम यूजर नहीं
              </p>
            ) : (
              premiumUsers.map((user) => (
                <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{user.full_name || user.email}</p>
                    <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                    {user.premium_expires_at && (
                      <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                        <Calendar className="h-3 w-3" />
                        समाप्ति: {new Date(user.premium_expires_at).toLocaleDateString('hi-IN')}
                      </p>
                    )}
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setSelectedUser(user);
                      setUserDialogOpen(true);
                    }}
                  >
                    प्रबंधित करें
                  </Button>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* Regular Users */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              नियमित यूजर्स
            </CardTitle>
            <CardDescription>
              {regularUsers.length} नियमित यूजर्स
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2 max-h-[400px] overflow-y-auto">
            {regularUsers.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                कोई नियमित यूजर नहीं
              </p>
            ) : (
              regularUsers.map((user) => (
                <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{user.full_name || user.email}</p>
                    <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setSelectedUser(user);
                      setUserDialogOpen(true);
                    }}
                  >
                    प्रबंधित करें
                  </Button>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* User Premium Dialog */}
      <Dialog open={userDialogOpen} onOpenChange={setUserDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>प्रीमियम स्टेटस प्रबंधित करें</DialogTitle>
            <DialogDescription>
              {selectedUser?.full_name || selectedUser?.email} के लिए प्रीमियम एक्सेस प्रबंधित करें
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <p className="font-medium">वर्तमान स्टेटस</p>
                <p className="text-sm text-muted-foreground">
                  {selectedUser?.is_premium ? 'प्रीमियम' : 'नियमित'}
                </p>
              </div>
              {selectedUser?.is_premium ? (
                <CheckCircle className="h-5 w-5 text-primary" />
              ) : (
                <XCircle className="h-5 w-5 text-muted-foreground" />
              )}
            </div>

            {!selectedUser?.is_premium && (
              <div className="space-y-2">
                <Label>प्रीमियम अवधि</Label>
                <Select value={premiumDuration} onValueChange={setPremiumDuration}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">7 दिन</SelectItem>
                    <SelectItem value="30">30 दिन</SelectItem>
                    <SelectItem value="90">90 दिन</SelectItem>
                    <SelectItem value="180">180 दिन</SelectItem>
                    <SelectItem value="365">1 वर्ष</SelectItem>
                    <SelectItem value="lifetime">आजीवन</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setUserDialogOpen(false)}>
              रद्द करें
            </Button>
            <Button onClick={handleUserPremiumUpdate} disabled={updating === selectedUser?.id}>
              {updating === selectedUser?.id && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {selectedUser?.is_premium ? 'प्रीमियम हटाएं' : 'प्रीमियम दें'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
