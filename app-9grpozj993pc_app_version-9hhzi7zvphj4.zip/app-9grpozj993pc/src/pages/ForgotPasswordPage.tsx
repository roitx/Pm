import * as React from 'react';
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PasswordInput } from '@/components/ui/PasswordInput';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Loader2, CheckCircle } from 'lucide-react';
import { BookLogo } from '@/components/ui/BookLogo';
import { ManualDateSelector } from '@/components/ui/ManualDateSelector';
import { recoverPasswordByIdentifier } from '@/db/api';
import { supabase } from '@/db/supabase';

export default function ForgotPasswordPage() {
  const [identifier, setIdentifier] = useState('');
  const [pincode, setPincode] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [verified, setVerified] = useState(false);
  const [userId, setUserId] = useState('');
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!identifier || !pincode || !dateOfBirth) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया सभी फ़ील्ड भरें',
        variant: 'destructive',
      });
      return;
    }

    // Validate pincode
    if (!/^[0-9]{6}$/.test(pincode)) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया 6 अंकों का वैध पिनकोड दर्ज करें',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    try {
      console.log('Verifying user:', { identifier, pincode, dateOfBirth });
      
      // Verify user details - now supports email, phone, or username
      const profile = await recoverPasswordByIdentifier(identifier, pincode, dateOfBirth);
      
      console.log('Verification result:', profile);
      
      if (!profile) {
        toast({
          title: 'सत्यापन विफल',
          description: '⚠️ यूज़रनेम/ईमेल/फ़ोन, पिनकोड या जन्म तिथि गलत है।\n\n💡 कृपया ध्यान दें:\n• यूज़रनेम, ईमेल या फ़ोन नंबर वही होना चाहिए जो साइन अप के समय दिया था\n• पिनकोड 6 अंकों का होना चाहिए\n• जन्म तिथि वही होनी चाहिए जो प्रोफाइल में सेव है\n\n📝 अगर आपको अपनी जानकारी याद नहीं है, तो कृपया एडमिन से संपर्क करें',
          variant: 'destructive',
        });
        return;
      }

      setUserId(profile.id);
      setVerified(true);
      
      toast({
        title: '✅ सत्यापन सफल',
        description: `स्वागत है ${profile.full_name}! अब आप नया पासवर्ड सेट कर सकते हैं`,
      });
      
    } catch (error: any) {
      console.error('Password recovery error:', error);
      toast({
        title: 'सत्यापन में समस्या',
        description: '⚠️ सत्यापन में समस्या हुई।\n\n💡 कृपया जांचें:\n• आपका इंटरनेट कनेक्शन ठीक है\n• आपने सही जानकारी दर्ज की है\n• आपका अकाउंट एक्टिव है\n\nअगर समस्या बनी रहे, तो एडमिन से संपर्क करें',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newPassword || !confirmPassword) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया दोनों पासवर्ड फ़ील्ड भरें',
        variant: 'destructive',
      });
      return;
    }

    if (newPassword.length < 6) {
      toast({
        title: 'त्रुटि',
        description: 'पासवर्ड कम से कम 6 अक्षरों का होना चाहिए',
        variant: 'destructive',
      });
      return;
    }

    if (newPassword !== confirmPassword) {
      toast({
        title: 'त्रुटि',
        description: 'पासवर्ड मेल नहीं खाते',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    try {
      console.log('Resetting password for user:', userId);
      
      // Call edge function to reset password
      const { data, error } = await supabase.functions.invoke('reset-password', {
        body: {
          userId: userId,
          newPassword: newPassword,
        },
      });

      console.log('Password reset response:', { data, error });

      if (error) {
        console.error('Password reset error:', error);
        let errorMsg = 'पासवर्ड बदलने में समस्या हुई';
        
        try {
          if (error?.context?.text) {
            const errorText = await error.context.text();
            console.error('Error context:', errorText);
            errorMsg = errorText;
          } else if (error?.message) {
            errorMsg = error.message;
          }
        } catch (e) {
          console.error('Error reading error message:', e);
        }
        
        throw new Error(errorMsg);
      }

      toast({
        title: '✅ सफलता',
        description: data?.message || 'आपका पासवर्ड सफलतापूर्वक बदल दिया गया है',
      });

      // Redirect to login page
      setTimeout(() => {
        navigate('/login');
      }, 1500);
      
    } catch (error: any) {
      console.error('Password reset error:', error);
      toast({
        title: 'त्रुटि',
        description: '⚠️ पासवर्ड बदलने में समस्या हुई।\n\n💡 कृपया पुनः प्रयास करें।',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/20 via-secondary/20 to-accent/20 p-4">
      <Card className="w-full max-w-md glass-card animate-fade-in">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-4 animate-float">
            <BookLogo size={60} />
          </div>
          <CardTitle className="text-2xl font-bold gradient-text">पासवर्ड भूल गए?</CardTitle>
          <CardDescription className="text-base">
            {!verified ? 'अपना यूज़रनेम/ईमेल/फ़ोन, पिनकोड और जन्म तिथि दर्ज करें' : 'नया पासवर्ड सेट करें'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!verified ? (
            <form onSubmit={handleVerify} className="space-y-4">
              {/* Identifier (Username/Email/Phone) */}
              <div className="space-y-2">
                <Label htmlFor="identifier">यूज़रनेम / ईमेल / फ़ोन नंबर *</Label>
                <Input
                  id="identifier"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="यूज़रनेम, ईमेल या फ़ोन नंबर दर्ज करें"
                  required
                  disabled={loading}
                />
                <p className="text-xs text-muted-foreground">
                  💡 आप अपना यूज़रनेम, ईमेल या फ़ोन नंबर में से कोई भी एक दर्ज कर सकते हैं
                </p>
              </div>

              {/* Pincode */}
              <div className="space-y-2">
                <Label htmlFor="pincode">पिनकोड *</Label>
                <Input
                  id="pincode"
                  type="text"
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value)}
                  placeholder="123456"
                  maxLength={6}
                  required
                  disabled={loading}
                />
              </div>

              {/* Date of Birth */}
              <ManualDateSelector
                value={dateOfBirth}
                onChange={setDateOfBirth}
                label="जन्म तिथि"
                required
                disabled={loading}
              />

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-primary to-secondary"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    सत्यापित कर रहे हैं...
                  </>
                ) : (
                  'सत्यापित करें'
                )}
              </Button>
            </form>
          ) : (
            <form onSubmit={handleResetPassword} className="space-y-4">
              <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800 mb-4">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <p className="text-sm text-green-700 dark:text-green-300">
                  सत्यापन सफल! अब नया पासवर्ड सेट करें
                </p>
              </div>

              {/* New Password */}
              <div className="space-y-2">
                <Label htmlFor="newPassword">नया पासवर्ड *</Label>
                <PasswordInput
                  id="newPassword"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="कम से कम 6 अक्षर"
                  required
                  disabled={loading}
                />
              </div>

              {/* Confirm Password */}
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">पासवर्ड की पुष्टि करें *</Label>
                <PasswordInput
                  id="confirmPassword"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="पासवर्ड दोबारा दर्ज करें"
                  required
                  disabled={loading}
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-primary to-secondary"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    पासवर्ड बदल रहे हैं...
                  </>
                ) : (
                  'पासवर्ड बदलें'
                )}
              </Button>
            </form>
          )}

          <div className="mt-6 text-center space-y-2">
            <p className="text-sm text-muted-foreground">
              याद आ गया?{' '}
              <Link to="/login" className="text-primary hover:underline font-medium">
                लॉगिन करें
              </Link>
            </p>
            <p className="text-sm text-muted-foreground">
              नया खाता बनाएं?{' '}
              <Link to="/signup" className="text-primary hover:underline font-medium">
                साइन अप करें
              </Link>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

