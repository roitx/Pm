import * as React from 'react';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { createDoubt, getUserDoubts } from '@/db/api';
import { useAuth } from '@/contexts/AuthContext';
import { HelpCircle, Send, CheckCircle, Clock, MessageSquare } from 'lucide-react';
import { formatDate, CLASSES } from '@/lib/constants';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

interface Doubt {
  id: string;
  title: string;
  description: string;
  subject: string | null;
  class: number | null;
  status: 'pending' | 'answered' | 'closed';
  answer: string | null;
  answered_at: string | null;
  created_at: string;
}

export default function DoubtsPage() {
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const [doubts, setDoubts] = useState<Doubt[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);

  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [subject, setSubject] = useState('');
  const [selectedClass, setSelectedClass] = useState<number | null>(null);

  useEffect(() => {
    if (user) {
      loadDoubts();
    }
  }, [user]);

  const loadDoubts = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const data = await getUserDoubts(user.id);
      setDoubts(data as Doubt[]);
    } catch (error) {
      console.error('Error loading doubts:', error);
      toast({
        title: 'त्रुटि',
        description: 'प्रश्न लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user || !title.trim() || !description.trim()) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया सभी आवश्यक फ़ील्ड भरें',
        variant: 'destructive',
      });
      return;
    }

    setSubmitting(true);
    try {
      await createDoubt({
        user_id: user.id,
        title: title.trim(),
        description: description.trim(),
        subject: subject || undefined,
        class: selectedClass || undefined,
      });

      toast({
        title: 'सफलता',
        description: 'आपका प्रश्न सबमिट हो गया है',
      });

      // Reset form
      setTitle('');
      setDescription('');
      setSubject('');
      setSelectedClass(null);
      setDialogOpen(false);

      // Reload doubts
      loadDoubts();
    } catch (error) {
      console.error('Error submitting doubt:', error);
      toast({
        title: 'त्रुटि',
        description: 'प्रश्न सबमिट करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'answered':
        return <Badge variant="default" className="bg-green-500"><CheckCircle className="h-3 w-3 mr-1" />उत्तर दिया गया</Badge>;
      case 'pending':
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />प्रतीक्षारत</Badge>;
      case 'closed':
        return <Badge variant="outline">बंद</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="text-center flex-1">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center animate-float">
              <HelpCircle className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold gradient-text">मेरे प्रश्न</h1>
          <p className="text-muted-foreground">
            अपने doubts पूछें और जवाब पाएं
          </p>
        </div>
        
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg">
              <Send className="h-4 w-4 mr-2" />
              नया प्रश्न पूछें
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>नया प्रश्न पूछें</DialogTitle>
              <DialogDescription>
                अपना doubt विस्तार से लिखें। हमारे teachers जल्द ही जवाब देंगे।
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">प्रश्न का शीर्षक *</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="संक्षेप में अपना प्रश्न लिखें"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">विस्तृत विवरण *</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="अपने प्रश्न को विस्तार से समझाएं..."
                  rows={5}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="subject">विषय (वैकल्पिक)</Label>
                  <Input
                    id="subject"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="जैसे: Physics, Math"
                  />
                </div>

                <div className="space-y-2">
                  <Label>कक्षा (वैकल्पिक)</Label>
                  <Select
                    value={selectedClass?.toString() || ''}
                    onValueChange={(value) => setSelectedClass(Number(value))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="कक्षा चुनें" />
                    </SelectTrigger>
                    <SelectContent>
                      {CLASSES.map((cls) => (
                        <SelectItem key={cls} value={cls.toString()}>
                          कक्षा {cls}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  रद्द करें
                </Button>
                <Button type="submit" disabled={submitting}>
                  {submitting ? 'सबमिट हो रहा है...' : 'प्रश्न सबमिट करें'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Doubts List */}
      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="glass-card">
              <CardHeader>
                <Skeleton className="h-6 w-3/4 bg-muted" />
                <Skeleton className="h-4 w-1/2 bg-muted" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20 w-full bg-muted" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : doubts.length > 0 ? (
        <div className="space-y-4">
          {doubts.map((doubt) => (
            <Card key={doubt.id} className="glass-card">
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <CardTitle className="text-xl mb-2">{doubt.title}</CardTitle>
                    <div className="flex flex-wrap gap-2">
                      {getStatusBadge(doubt.status)}
                      {doubt.subject && (
                        <Badge variant="outline">{doubt.subject}</Badge>
                      )}
                      {doubt.class && (
                        <Badge variant="outline">कक्षा {doubt.class}</Badge>
                      )}
                    </div>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {formatDate(doubt.created_at)}
                  </span>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">प्रश्न:</h4>
                  <p className="text-muted-foreground whitespace-pre-wrap">
                    {doubt.description}
                  </p>
                </div>

                {doubt.answer && (
                  <div className="border-t pt-4">
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <MessageSquare className="h-4 w-4" />
                      उत्तर:
                    </h4>
                    <p className="text-muted-foreground whitespace-pre-wrap bg-muted/30 p-4 rounded-lg">
                      {doubt.answer}
                    </p>
                    {doubt.answered_at && (
                      <p className="text-xs text-muted-foreground mt-2">
                        उत्तर दिया गया: {formatDate(doubt.answered_at)}
                      </p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="glass-card">
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <HelpCircle className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">कोई प्रश्न नहीं</h3>
            <p className="text-muted-foreground mb-6">
              अपने doubts पूछें और teachers से मदद पाएं
            </p>
            <Button onClick={() => setDialogOpen(true)}>
              <Send className="h-4 w-4 mr-2" />
              पहला प्रश्न पूछें
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
