import * as React from 'react';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { useTheme } from 'next-themes';
import { useLanguage } from '@/contexts/LanguageContext';
import { useToast } from '@/hooks/use-toast';
import { 
  ArrowLeft, 
  Moon, 
  Sun, 
  Globe, 
  Bell, 
  Volume2, 
  Download,
  Smartphone,
  Wifi,
  Database,
  Info,
  RefreshCw
} from 'lucide-react';

export default function SettingsPage() {
  const navigate = useNavigate();
  const { theme, setTheme } = useTheme();
  const { language, setLanguage, t } = useLanguage();
  const { toast } = useToast();

  // Settings state
  const [notifications, setNotifications] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [clearing, setClearing] = useState(false);

  // Load settings from localStorage
  useEffect(() => {
    const savedNotifications = localStorage.getItem('notifications-enabled') !== 'false';
    const savedSound = localStorage.getItem('sound-enabled') !== 'false';

    setNotifications(savedNotifications);
    setSoundEnabled(savedSound);
  }, []);

  // Save settings to localStorage
  const saveSetting = (key: string, value: string | boolean) => {
    localStorage.setItem(key, String(value));
    toast({
      title: 'सेटिंग सहेजी गई',
      description: 'आपकी सेटिंग सफलतापूर्वक अपडेट हो गई है',
    });
  };

  const handleThemeChange = (checked: boolean) => {
    setTheme(checked ? 'dark' : 'light');
    toast({
      title: checked ? t('darkModeEnabled') : t('lightModeEnabled'),
      description: checked ? t('darkModeEnabledDesc') : t('lightModeEnabledDesc'),
    });
  };

  const handleLanguageChange = (value: 'hi' | 'en') => {
    setLanguage(value);
    toast({
      title: t('languageChanged'),
      description: t('languageChangedDesc'),
    });
  };

  const handleNotificationsChange = (checked: boolean) => {
    setNotifications(checked);
    saveSetting('notifications-enabled', checked);
  };

  const handleSoundChange = (checked: boolean) => {
    setSoundEnabled(checked);
    saveSetting('sound-enabled', checked);
  };




  const clearCache = async () => {
    setClearing(true);
    try {
      // Clear service worker caches
      if ('caches' in window) {
        const cacheNames = await caches.keys();
        await Promise.all(
          cacheNames.map((cacheName) => caches.delete(cacheName))
        );
      }
      
      // Clear localStorage (except important settings)
      const importantKeys = ['app-language', 'theme', 'auth-token'];
      const allKeys = Object.keys(localStorage);
      allKeys.forEach((key) => {
        if (!importantKeys.includes(key)) {
          localStorage.removeItem(key);
        }
      });
      
      toast({
        title: t('cacheCleared'),
        description: t('cacheClearedDesc'),
      });
      
      // Reload page after 2 seconds
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    } catch (error) {
      console.error('Error clearing cache:', error);
      toast({
        title: language === 'hi' ? 'त्रुटि' : 'Error',
        description: language === 'hi' ? 'कैश साफ़ करने में विफल' : 'Failed to clear cache',
        variant: 'destructive',
      });
    } finally {
      setClearing(false);
    }
  };

  return (
    <div className="container mx-auto p-4 xl:p-6 max-w-4xl">
      <Card className="glass-card">
        <CardHeader className="border-b border-border/50">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(-1)}
              className="shrink-0"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <CardTitle className="text-xl xl:text-2xl">{t('settingsTitle')}</CardTitle>
              <CardDescription className="mt-1">
                {t('settingsDescription')}
              </CardDescription>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-4 xl:p-6 space-y-6">
          {/* Appearance Settings */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Sun className="h-5 w-5 text-primary" />
              <h3 className="text-lg font-semibold">{t('appearance')}</h3>
            </div>
            <Separator />
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="dark-mode" className="text-base">{t('darkMode')}</Label>
                <p className="text-sm text-muted-foreground">
                  {t('darkModeDesc')}
                </p>
              </div>
              <Switch
                id="dark-mode"
                checked={theme === 'dark'}
                onCheckedChange={handleThemeChange}
              />
            </div>
          </div>

          {/* Language Settings */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-primary" />
              <h3 className="text-lg font-semibold">{t('language')}</h3>
            </div>
            <Separator />
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="language" className="text-base">{t('appLanguage')}</Label>
                <p className="text-sm text-muted-foreground">
                  {t('languageDesc')}
                </p>
              </div>
              <Select value={language} onValueChange={handleLanguageChange}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hi">हिंदी</SelectItem>
                  <SelectItem value="en">English</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Notification Settings */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Bell className="h-5 w-5 text-primary" />
              <h3 className="text-lg font-semibold">{t('notificationsTitle')}</h3>
            </div>
            <Separator />
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="notifications" className="text-base">{t('pushNotifications')}</Label>
                <p className="text-sm text-muted-foreground">
                  {t('pushNotificationsDesc')}
                </p>
              </div>
              <Switch
                id="notifications"
                checked={notifications}
                onCheckedChange={handleNotificationsChange}
              />
            </div>
          </div>

          {/* Sound Settings */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Volume2 className="h-5 w-5 text-primary" />
              <h3 className="text-lg font-semibold">{t('sound')}</h3>
            </div>
            <Separator />
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="sound" className="text-base">{t('soundEffects')}</Label>
                <p className="text-sm text-muted-foreground">
                  {t('soundEffectsDesc')}
                </p>
              </div>
              <Switch
                id="sound"
                checked={soundEnabled}
                onCheckedChange={handleSoundChange}
              />
            </div>
          </div>



          {/* App Info & Actions */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Info className="h-5 w-5 text-primary" />
              <h3 className="text-lg font-semibold">{t('appInfo')}</h3>
            </div>
            <Separator />
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">{t('version')}</span>
                <span className="text-sm font-medium">1.0.0</span>
              </div>
              
              <Button
                variant="outline"
                className="w-full"
                onClick={clearCache}
                disabled={clearing}
              >
                {clearing ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    {language === 'hi' ? 'साफ़ हो रहा है...' : 'Clearing...'}
                  </>
                ) : (
                  <>
                    <Database className="h-4 w-4 mr-2" />
                    {t('clearCache')}
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
