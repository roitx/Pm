import * as React from 'react';
import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PasswordInput } from '@/components/ui/PasswordInput';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Upload, User } from 'lucide-react';
import { BookLogo } from '@/components/ui/BookLogo';
import { ManualDateSelector } from '@/components/ui/ManualDateSelector';
import { ImageCropDialog } from '@/components/ui/ImageCropDialog';
import { supabase } from '@/db/supabase';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

export default function SignupPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [studentClass, setStudentClass] = useState('');
  const [schoolName, setSchoolName] = useState('');
  const [city, setCity] = useState('');
  const [pincode, setPincode] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [profileImage, setProfileImage] = useState<File | null>(null);
  const [profileImagePreview, setProfileImagePreview] = useState<string>('');
  const [cropDialogOpen, setCropDialogOpen] = useState(false);
  const [imageToCrop, setImageToCrop] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [usernameError, setUsernameError] = useState('');
  const { signUpWithUsername } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file size (max 1MB)
    if (file.size > 1024 * 1024) {
      toast({
        title: 'त्रुटि',
        description: 'छवि का आकार 1MB से कम होना चाहिए',
        variant: 'destructive',
      });
      return;
    }

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया एक वैध छवि फ़ाइल चुनें',
        variant: 'destructive',
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setImageToCrop(reader.result as string);
      setCropDialogOpen(true);
    };
    reader.readAsDataURL(file);
  };

  const validateUsername = (value: string) => {
    setUsername(value);
    
    // यूज़रनेम में underscore या number होना चाहिए
    const hasUnderscore = value.includes('_');
    const hasNumber = /\d/.test(value);
    
    if (value && !hasUnderscore && !hasNumber) {
      setUsernameError('unavailable - यूज़रनेम में _ या संख्या होनी चाहिए');
    } else if (value && !/^[a-zA-Z0-9_]+$/.test(value)) {
      setUsernameError('केवल अक्षर, संख्या और _ का उपयोग करें');
    } else {
      setUsernameError('');
    }
  };

  const handleCropComplete = (croppedBlob: Blob) => {
    const file = new File([croppedBlob], 'profile.jpg', { type: 'image/jpeg' });
    setProfileImage(file);
    setProfileImagePreview(URL.createObjectURL(croppedBlob));
  };

  const uploadProfileImage = async (userId: string): Promise<string | null> => {
    if (!profileImage) return null;

    try {
      const fileExt = 'jpg';
      const fileName = `${userId}_${Date.now()}.${fileExt}`;
      const filePath = `profile_photos/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('profile-photos')
        .upload(filePath, profileImage, {
          cacheControl: '3600',
          upsert: false,
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('profile-photos')
        .getPublicUrl(filePath);

      return publicUrl;
    } catch (error) {
      console.error('Error uploading image:', error);
      return null;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!username || !password || !confirmPassword || !fullName || !phone) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया सभी आवश्यक फ़ील्ड भरें (यूज़रनेम, पासवर्ड, नाम, फ़ोन नंबर)',
        variant: 'destructive',
      });
      return;
    }

    // Validate username (must have underscore OR number)
    const hasUnderscore = username.includes('_');
    const hasNumber = /\d/.test(username);
    
    if (!hasUnderscore && !hasNumber) {
      toast({
        title: 'त्रुटि',
        description: 'यूज़रनेम में _ (underscore) या संख्या होनी चाहिए',
        variant: 'destructive',
      });
      return;
    }

    // Validate username (only letters, numbers, and underscore)
    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      toast({
        title: 'त्रुटि',
        description: 'यूज़रनेम में केवल अक्षर, संख्या और _ का उपयोग करें',
        variant: 'destructive',
      });
      return;
    }

    if (password.length < 6) {
      toast({
        title: 'त्रुटि',
        description: 'पासवर्ड कम से कम 6 अक्षरों का होना चाहिए',
        variant: 'destructive',
      });
      return;
    }

    if (password !== confirmPassword) {
      toast({
        title: 'त्रुटि',
        description: 'पासवर्ड मेल नहीं खाते',
        variant: 'destructive',
      });
      return;
    }

    // Validate that either email OR phone is provided (for password recovery)
    if (!email && !phone) {
      toast({
        title: 'त्रुटि',
        description: 'फ़ोन नंबर अनिवार्य है',
        variant: 'destructive',
      });
      return;
    }

    // Validate email (if provided)
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया वैध ईमेल पता दर्ज करें',
        variant: 'destructive',
      });
      return;
    }

    // Validate phone (required)
    if (!phone || !/^[0-9]{10}$/.test(phone)) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया 10 अंकों का वैध फ़ोन नंबर दर्ज करें',
        variant: 'destructive',
      });
      return;
    }

    // Validate pincode (required for password recovery)
    if (!pincode) {
      toast({
        title: 'त्रुटि',
        description: 'पिनकोड अनिवार्य है (पासवर्ड रिकवरी के लिए आवश्यक)',
        variant: 'destructive',
      });
      return;
    }
    
    if (!/^[0-9]{6}$/.test(pincode)) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया 6 अंकों का वैध पिनकोड दर्ज करें',
        variant: 'destructive',
      });
      return;
    }

    // Validate date of birth (required for password recovery)
    if (!dateOfBirth) {
      toast({
        title: 'त्रुटि',
        description: 'जन्म तिथि अनिवार्य है (पासवर्ड रिकवरी के लिए आवश्यक)',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    try {
      // Step 1: Create account with username-based email for authentication
      // Real email (if provided) will be stored separately in user_email field
      const authEmail = `${username}@miaoda.com`;
      const result = await signUpWithUsername(username, password, authEmail);
      
      if (result.error) {
        // Check for specific error types
        if (result.error.message.includes('already registered') || result.error.message.includes('already exists')) {
          throw new Error('यह यूज़रनेम पहले से मौजूद है। कृपया दूसरा यूज़रनेम चुनें।');
        }
        throw result.error;
      }

      if (!result.user) {
        throw new Error('उपयोगकर्ता नहीं बना। कृपया पुनः प्रयास करें।');
      }

      const currentUser = result.user;

      // Step 2: Wait for profile to be created by trigger (max 5 seconds)
      let profileExists = false;
      let attempts = 0;
      const maxAttempts = 10;
      
      while (!profileExists && attempts < maxAttempts) {
        attempts++;
        
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('id')
          .eq('id', currentUser.id)
          .maybeSingle();
        
        if (profileError) {
          console.error('Profile check error:', profileError);
        }
        
        if (profile) {
          profileExists = true;
          break;
        }
        
        // Wait 500ms before next attempt
        await new Promise(resolve => setTimeout(resolve, 500));
      }

      // If profile doesn't exist after waiting, try to create it manually
      if (!profileExists) {
        console.log('Profile not found, creating manually...');
        
        const { data: createResult, error: createError } = await supabase.rpc(
          'create_profile_if_missing',
          { 
            user_id: currentUser.id, 
            user_email: authEmail
          }
        );

        if (createError) {
          console.error('Manual profile creation error:', createError);
          throw new Error(`प्रोफाइल बनाने में त्रुटि: ${createError.message}`);
        }

        if (!createResult) {
          throw new Error('प्रोफाइल बनाने में त्रुटि। कृपया पुनः प्रयास करें।');
        }

        // Wait a bit more for the profile to be available
        await new Promise(resolve => setTimeout(resolve, 500));
      }

      // Step 3: Upload profile image (if provided)
      let profilePhotoUrl: string | null = null;
      if (profileImage) {
        profilePhotoUrl = await uploadProfileImage(currentUser.id);
      }

      // Step 4: Update profile with all details
      const { error: updateError } = await supabase
        .from('profiles')
        .update({
          full_name: fullName,
          email: authEmail, // Authentication email (username@miaoda.com)
          user_email: email || null, // User's real email (optional)
          phone: phone, // Phone is now required
          student_class: studentClass || null,
          school_name: schoolName || null,
          city: city || null,
          pincode: pincode || null,
          date_of_birth: dateOfBirth || null,
          profile_photo_url: profilePhotoUrl,
          updated_at: new Date().toISOString(),
        })
        .eq('id', currentUser.id);

      if (updateError) {
        console.error('Profile update error:', updateError);
        throw new Error(`प्रोफाइल अपडेट करने में त्रुटि: ${updateError.message}`);
      }

      toast({
        title: 'सफलता',
        description: 'खाता बनाया गया! लॉगिन हो रहा है...',
      });

      // Auto login after signup
      setTimeout(() => {
        navigate('/dashboard', { replace: true });
      }, 1000);
    } catch (error: any) {
      console.error('Signup process error:', error);
      
      // Show detailed error message
      const errorMessage = error.message || 'कुछ गलत हो गया। कृपया पुनः प्रयास करें।';
      
      toast({
        title: 'साइन अप विफल',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/20 via-secondary/20 to-accent/20 p-4">
      <Card className="w-full max-w-2xl glass-card animate-fade-in my-8">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-4 animate-float">
            <BookLogo size={80} />
          </div>
          <CardTitle className="text-3xl font-bold gradient-text">PM - Roit</CardTitle>
          <CardDescription className="text-base">
            नया खाता बनाएं - सभी विवरण भरें
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Profile Image Upload */}
            <div className="flex flex-col items-center space-y-3 pb-4 border-b border-border/50">
              <Avatar className="h-24 w-24">
                {profileImagePreview ? (
                  <AvatarImage src={profileImagePreview} alt="Profile" />
                ) : (
                  <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white text-2xl">
                    <User className="h-12 w-12" />
                  </AvatarFallback>
                )}
              </Avatar>
              <Label htmlFor="profile-image" className="cursor-pointer">
                <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary/10 hover:bg-primary/20 transition-colors">
                  <Upload className="h-4 w-4" />
                  <span className="text-sm font-medium">
                    {profileImagePreview ? 'छवि बदलें' : 'प्रोफ़ाइल फ़ोटो अपलोड करें'}
                  </span>
                </div>
              </Label>
              <input
                id="profile-image"
                type="file"
                accept="image/*"
                onChange={handleImageSelect}
                className="hidden"
              />
              <p className="text-xs text-muted-foreground">वैकल्पिक - अधिकतम 1MB</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Username */}
              <div className="space-y-2">
                <Label htmlFor="username">यूज़रनेम *</Label>
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => validateUsername(e.target.value)}
                  placeholder="user_123 या user123"
                  required
                />
                {usernameError && (
                  <p className="text-xs text-destructive">{usernameError}</p>
                )}
                {!usernameError && username && (
                  <p className="text-xs text-green-600">✓ उपलब्ध</p>
                )}
              </div>

              {/* Full Name */}
              <div className="space-y-2">
                <Label htmlFor="fullName">पूरा नाम *</Label>
                <Input
                  id="fullName"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="आपका पूरा नाम"
                  required
                />
              </div>

              {/* Password */}
              <div className="space-y-2">
                <Label htmlFor="password">पासवर्ड *</Label>
                <PasswordInput
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••"
                  required
                />
              </div>

              {/* Confirm Password */}
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">पासवर्ड की पुष्टि करें *</Label>
                <PasswordInput
                  id="confirmPassword"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••"
                  required
                />
              </div>

              {/* Phone */}
              <div className="space-y-2">
                <Label htmlFor="phone">फ़ोन नंबर *</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="9876543210"
                  maxLength={10}
                  required
                />
                <p className="text-xs text-muted-foreground">
                  ⚠️ अनिवार्य - पासवर्ड रिकवरी और लॉगिन के लिए आवश्यक
                </p>
              </div>

              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email">ईमेल (वैकल्पिक)</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="example@email.com"
                />
                <p className="text-xs text-muted-foreground">
                  पासवर्ड रिकवरी के लिए ईमेल या फ़ोन में से कम से कम एक आवश्यक है
                </p>
              </div>

              {/* Class */}
              <div className="space-y-2">
                <Label htmlFor="class">कक्षा</Label>
                <Select value={studentClass} onValueChange={setStudentClass}>
                  <SelectTrigger>
                    <SelectValue placeholder="कक्षा चुनें" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="8">कक्षा 8</SelectItem>
                    <SelectItem value="9">कक्षा 9</SelectItem>
                    <SelectItem value="10">कक्षा 10</SelectItem>
                    <SelectItem value="11">कक्षा 11</SelectItem>
                    <SelectItem value="12">कक्षा 12</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* School Name */}
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="schoolName">स्कूल का नाम</Label>
                <Input
                  id="schoolName"
                  value={schoolName}
                  onChange={(e) => setSchoolName(e.target.value)}
                  placeholder="आपके स्कूल का नाम"
                />
              </div>

              {/* City */}
              <div className="space-y-2">
                <Label htmlFor="city">शहर</Label>
                <Input
                  id="city"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="आपका शहर"
                />
              </div>

              {/* Pincode */}
              <div className="space-y-2">
                <Label htmlFor="pincode">पिनकोड *</Label>
                <Input
                  id="pincode"
                  type="text"
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value)}
                  placeholder="123456"
                  maxLength={6}
                  required
                />
              </div>

              {/* Date of Birth */}
              <ManualDateSelector
                value={dateOfBirth}
                onChange={setDateOfBirth}
                label="जन्म तिथि *"
                required
              />
            </div>

            {/* Password Recovery Notice */}
            <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
              <p className="text-sm text-amber-800 dark:text-amber-200 flex items-start gap-2">
                <span className="text-lg">⚠️</span>
                <span>
                  <strong>महत्वपूर्ण:</strong> पिनकोड और जन्म तिथि अनिवार्य हैं क्योंकि यदि आप अपना पासवर्ड भूल जाते हैं, तो इन्हीं विवरणों से आप अपना पासवर्ड पुनः प्राप्त कर सकेंगे।
                </span>
              </p>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-primary to-secondary"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  खाता बनाया जा रहा है...
                </>
              ) : (
                'खाता बनाएं'
              )}
            </Button>

            <p className="text-center text-sm text-muted-foreground">
              पहले से खाता है?{' '}
              <Link to="/login" className="text-primary hover:underline font-medium">
                लॉगिन करें
              </Link>
            </p>
          </form>
        </CardContent>
      </Card>

      {/* Image Crop Dialog */}
      <ImageCropDialog
        open={cropDialogOpen}
        onOpenChange={setCropDialogOpen}
        imageSrc={imageToCrop}
        onCropComplete={handleCropComplete}
        aspectRatio={1}
      />
    </div>
  );
}
