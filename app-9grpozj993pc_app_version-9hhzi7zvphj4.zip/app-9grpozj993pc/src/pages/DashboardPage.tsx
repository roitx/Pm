import * as React from 'react';
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CATEGORIES } from '@/lib/constants';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { motion } from 'framer-motion';
import { BookOpen, Brain, FileText, Clock, GraduationCap, Zap, Sparkles, CheckCircle, Trophy, Box, ExternalLink, Download } from 'lucide-react';
import { DynamicIcon } from '@/components/ui/DynamicIcon';
import { BackgroundAnimation } from '@/components/ui/BackgroundAnimation';
import { getLatestMotivation } from '@/db/api';

export default function DashboardPage() {
  const { profile, user } = useAuth();
  const { t } = useLanguage();
  const [showGreeting, setShowGreeting] = useState(false);
  const [motivation, setMotivation] = useState('सफलता का रहस्य है - कभी हार न मानना। हर दिन एक नया अवसर है सीखने और बढ़ने का।');

  // Helper function to get translated category name
  const getCategoryName = (categoryId: string): string => {
    const categoryKeyMap: Record<string, keyof typeof import('@/lib/translations').translations.hi> = {
      'notes': 'notes',
      'pyq': 'pyq',
      'important_questions': 'importantQuestions',
      'reference_books': 'referenceBooks',
      'mind_maps': 'mindMaps',
      'formulas': 'formulas',
      'mcq_tests': 'mcqTests',
      'iit_jee_questions': 'iitjeeQuestions',
    };
    
    const key = categoryKeyMap[categoryId];
    return key ? t(key) : categoryId;
  };

  useEffect(() => {
    // Check if greeting should be shown (once per day)
    const lastGreetingDate = localStorage.getItem('lastGreetingDate');
    const today = new Date().toDateString();
    
    if (lastGreetingDate !== today) {
      setShowGreeting(true);
      localStorage.setItem('lastGreetingDate', today);
    }

    // Fetch latest motivation
    loadMotivation();

    // Poll for new motivation every 30 seconds
    const interval = setInterval(loadMotivation, 30000);

    return () => clearInterval(interval);
  }, []);

  const loadMotivation = async () => {
    try {
      const latestMotivation = await getLatestMotivation();
      setMotivation(latestMotivation);
    } catch (error) {
      console.error('Error loading motivation:', error);
    }
  };

  return (
    <div className="relative">
      {/* Background Animation */}
      <BackgroundAnimation />
      
      <div className="container mx-auto p-4 xl:p-6 space-y-6 xl:space-y-8">
      {/* Welcome Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="glass-card p-6 xl:p-8 rounded-2xl"
      >
        <div className="text-center xl:text-left">
          <h1 className="text-3xl xl:text-4xl font-bold gradient-text mb-2">
            {t('welcomeGreeting')}, {profile?.full_name || t('student')}! 👋
          </h1>
          <p className="text-base xl:text-lg text-muted-foreground">
            {t('whatToLearnToday')}
          </p>
        </div>
      </motion.div>

      {/* Study Materials Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <h2 className="text-xl xl:text-2xl font-bold mb-4 flex items-center gap-2">
          <BookOpen className="h-5 w-5 xl:h-6 xl:w-6" />
          {t('studyMaterials')}
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 xl:gap-4">
          {CATEGORIES.filter(cat => cat.id !== '3d_structures' && cat.id !== 'external_notes').map((category, index) => (
            <motion.div
              key={category.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
            >
              <Link to={`/content/${category.id}`}>
                <Card className="glass-card hover:shadow-hover transition-all duration-300 hover:-translate-y-1 cursor-pointer group h-full">
                  <CardContent className="p-4 xl:p-5">
                    <div className={`w-12 h-12 xl:w-14 xl:h-14 rounded-xl bg-gradient-to-br ${category.color} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300`}>
                      <DynamicIcon name={category.icon} className="h-6 w-6 xl:h-7 xl:w-7 text-white" />
                    </div>
                    <h3 className="font-semibold text-sm xl:text-base mb-1 group-hover:text-primary transition-colors">
                      {getCategoryName(category.id)}
                    </h3>
                    <p className="text-xs text-muted-foreground line-clamp-2">
                      {category.description}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Additional Content Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <h2 className="text-xl xl:text-2xl font-bold mb-4 flex items-center gap-2">
          <Sparkles className="h-5 w-5 xl:h-6 xl:w-6 text-primary" />
          अतिरिक्त सामग्री
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 xl:gap-4">
          {CATEGORIES.filter(cat => cat.id === '3d_structures' || cat.id === 'external_notes').map((category, index) => (
            <motion.div
              key={category.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
            >
              <Link to={`/${category.id === '3d_structures' ? '3d-structures' : 'external-notes'}`}>
                <Card className="glass-card hover:shadow-hover transition-all duration-300 hover:-translate-y-1 cursor-pointer group h-full">
                  <CardContent className="p-4 xl:p-5">
                    <div className={`w-12 h-12 xl:w-14 xl:h-14 rounded-xl bg-gradient-to-br ${category.color} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300`}>
                      <DynamicIcon name={category.icon} className="h-6 w-6 xl:h-7 xl:w-7 text-white" />
                    </div>
                    <h3 className="font-semibold text-sm xl:text-base mb-1 group-hover:text-primary transition-colors">
                      {getCategoryName(category.id)}
                    </h3>
                    <p className="text-xs text-muted-foreground line-clamp-2">
                      {category.description}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <h2 className="text-xl xl:text-2xl font-bold mb-4 flex items-center gap-2">
          <Zap className="h-5 w-5 xl:h-6 xl:w-6 text-primary" />
          त्वरित कार्य
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 xl:gap-4">
          <Link to="/ai-helper">
            <Card className="glass-card hover:shadow-hover transition-all duration-300 hover:-translate-y-1 cursor-pointer group bg-gradient-to-br from-blue-500/10 to-blue-600/5">
              <CardContent className="p-4 xl:p-5 text-center">
                <Brain className="h-10 w-10 xl:h-12 xl:w-12 mx-auto mb-2 text-blue-500 group-hover:scale-110 transition-transform" />
                <p className="font-semibold text-sm xl:text-base">AI सहायक</p>
              </CardContent>
            </Card>
          </Link>
          <Link to="/content/mcq_tests">
            <Card className="glass-card hover:shadow-hover transition-all duration-300 hover:-translate-y-1 cursor-pointer group bg-gradient-to-br from-green-500/10 to-green-600/5">
              <CardContent className="p-4 xl:p-5 text-center">
                <CheckCircle className="h-10 w-10 xl:h-12 xl:w-12 mx-auto mb-2 text-green-500 group-hover:scale-110 transition-transform" />
                <p className="font-semibold text-sm xl:text-base">MCQ टेस्ट</p>
              </CardContent>
            </Card>
          </Link>
          <Link to="/recently-viewed">
            <Card className="glass-card hover:shadow-hover transition-all duration-300 hover:-translate-y-1 cursor-pointer group bg-gradient-to-br from-purple-500/10 to-purple-600/5">
              <CardContent className="p-4 xl:p-5 text-center">
                <Clock className="h-10 w-10 xl:h-12 xl:w-12 mx-auto mb-2 text-purple-500 group-hover:scale-110 transition-transform" />
                <p className="font-semibold text-sm xl:text-base">हाल में देखे गए</p>
              </CardContent>
            </Card>
          </Link>
          <Link to="/leaderboard">
            <Card className="glass-card hover:shadow-hover transition-all duration-300 hover:-translate-y-1 cursor-pointer group bg-gradient-to-br from-orange-500/10 to-orange-600/5">
              <CardContent className="p-4 xl:p-5 text-center">
                <GraduationCap className="h-10 w-10 xl:h-12 xl:w-12 mx-auto mb-2 text-orange-500 group-hover:scale-110 transition-transform" />
                <p className="font-semibold text-sm xl:text-base">लीडरबोर्ड</p>
              </CardContent>
            </Card>
          </Link>
        </div>
      </motion.div>
    </div>
    </div>
  );
}
