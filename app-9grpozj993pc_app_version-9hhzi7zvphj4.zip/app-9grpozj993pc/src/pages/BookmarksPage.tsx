import * as React from 'react';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { getUserBookmarks, removeBookmark } from '@/db/api';
import { useAuth } from '@/contexts/AuthContext';
import { Bookmark, Eye, Download, Trash2, BookmarkCheck } from 'lucide-react';
import { formatDate, getCategoryInfo } from '@/lib/constants';
import type { Content } from '@/types/types';

interface BookmarkItem {
  id: string;
  content: Content;
  created_at: string;
}

export default function BookmarksPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadBookmarks();
    }
  }, [user]);

  const loadBookmarks = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const data = await getUserBookmarks(user.id);
      setBookmarks(data as BookmarkItem[]);
    } catch (error) {
      console.error('Error loading bookmarks:', error);
      toast({
        title: 'त्रुटि',
        description: 'बुकमार्क लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveBookmark = async (contentId: string) => {
    if (!user) return;

    try {
      await removeBookmark(user.id, contentId);
      setBookmarks(prev => prev.filter(b => b.content.id !== contentId));
      toast({
        title: 'सफलता',
        description: 'बुकमार्क हटा दिया गया',
      });
    } catch (error) {
      console.error('Error removing bookmark:', error);
      toast({
        title: 'त्रुटि',
        description: 'बुकमार्क हटाने में विफल',
        variant: 'destructive',
      });
    }
  };

  const handleViewContent = (contentId: string) => {
    navigate(`/content/view/${contentId}`);
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-3xl animate-float">
            <BookmarkCheck className="h-8 w-8 text-white" />
          </div>
        </div>
        <h1 className="text-3xl font-bold gradient-text">मेरे बुकमार्क्स</h1>
        <p className="text-muted-foreground">
          आपकी पसंदीदा सामग्री यहाँ सहेजी गई है
        </p>
      </div>

      {/* Bookmarks List */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i} className="glass-card">
              <CardHeader>
                <Skeleton className="h-6 w-3/4 bg-muted" />
                <Skeleton className="h-4 w-1/2 bg-muted" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20 w-full bg-muted" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : bookmarks.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {bookmarks.map((bookmark) => {
            const categoryInfo = getCategoryInfo(bookmark.content.category);
            return (
              <Card key={bookmark.id} className="glass-card hover:shadow-hover transition-all">
                <CardHeader>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <CardTitle className="text-lg line-clamp-2">
                        {bookmark.content.title}
                      </CardTitle>
                      <CardDescription className="mt-2">
                        <Badge variant="secondary" className="mr-2">
                          {categoryInfo?.name}
                        </Badge>
                        {bookmark.content.class && (
                          <Badge variant="outline">
                            कक्षा {bookmark.content.class}
                          </Badge>
                        )}
                      </CardDescription>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleRemoveBookmark(bookmark.content.id)}
                      className="shrink-0"
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {bookmark.content.description && (
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {bookmark.content.description}
                    </p>
                  )}
                  
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Bookmark className="h-3 w-3" />
                    <span>सहेजा गया: {formatDate(bookmark.created_at)}</span>
                  </div>

                  <Button
                    onClick={() => handleViewContent(bookmark.content.id)}
                    className="w-full"
                    variant="default"
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    देखें
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card className="glass-card">
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <Bookmark className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">कोई बुकमार्क नहीं</h3>
            <p className="text-muted-foreground mb-6">
              अपनी पसंदीदा सामग्री को बुकमार्क करें और यहाँ आसानी से एक्सेस करें
            </p>
            <Button onClick={() => navigate('/dashboard')}>
              सामग्री ब्राउज़ करें
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
