import * as React from 'react';
import AdminUploaderChatPage from '@/pages/admin/AdminUploaderChatPage';

// Uploader chat page is the same as admin chat page
// The component handles role-based logic internally
export default function UploaderChatPage() {
  return <AdminUploaderChatPage />;
}
