import * as React from 'react';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { createUploaderFeedback, getUploaderFeedback } from '@/db/api';
import { MessageSquare, Send, CheckCircle2, Clock, MessageCircle } from 'lucide-react';
import { formatDate } from '@/lib/constants';
import type { UploaderFeedback } from '@/types/types';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

export default function UploaderFeedbackPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [feedbacks, setFeedbacks] = useState<UploaderFeedback[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (user) {
      loadFeedbacks();
    }
  }, [user]);

  const loadFeedbacks = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const data = await getUploaderFeedback(user.id);
      setFeedbacks(data);
    } catch (error) {
      console.error('Error loading feedbacks:', error);
      toast({
        title: 'त्रुटि',
        description: 'फीडबैक लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user || !subject.trim() || !message.trim()) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया सभी फ़ील्ड भरें',
        variant: 'destructive',
      });
      return;
    }

    setSubmitting(true);
    try {
      await createUploaderFeedback(user.id, subject.trim(), message.trim());
      
      toast({
        title: 'सफलता',
        description: 'फीडबैक सफलतापूर्वक भेजा गया। एडमिन जल्द ही जवाब देंगे।',
      });
      
      // Reset form
      setSubject('');
      setMessage('');
      setDialogOpen(false);
      
      // Reload feedbacks
      loadFeedbacks();
    } catch (error) {
      console.error('Error submitting feedback:', error);
      toast({
        title: 'त्रुटि',
        description: 'फीडबैक भेजने में विफल',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="gap-1"><Clock className="h-3 w-3" />प्रतीक्षारत</Badge>;
      case 'replied':
        return <Badge variant="default" className="gap-1"><MessageCircle className="h-3 w-3" />जवाब मिला</Badge>;
      case 'resolved':
        return <Badge variant="secondary" className="gap-1"><CheckCircle2 className="h-3 w-3" />हल हो गया</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="container mx-auto p-4 xl:p-6 max-w-6xl">
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 mb-6">
        <div>
          <h1 className="text-2xl xl:text-3xl font-bold flex items-center gap-2">
            <MessageSquare className="h-7 w-7 text-primary" />
            मेरा फीडबैक
          </h1>
          <p className="text-muted-foreground mt-1">
            एडमिन को अपनी समस्याएं और सुझाव भेजें
          </p>
        </div>
        
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg" className="gap-2">
              <Send className="h-4 w-4" />
              नया फीडबैक भेजें
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>नया फीडबैक भेजें</DialogTitle>
              <DialogDescription>
                अपनी समस्या या सुझाव एडमिन को भेजें। वे जल्द ही जवाब देंगे।
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="subject" className="text-sm font-medium">
                  विषय *
                </label>
                <Input
                  id="subject"
                  placeholder="फीडबैक का विषय लिखें"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  required
                  maxLength={200}
                />
              </div>
              
              <div className="space-y-2">
                <label htmlFor="message" className="text-sm font-medium">
                  संदेश *
                </label>
                <Textarea
                  id="message"
                  placeholder="अपनी समस्या या सुझाव विस्तार से लिखें..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  required
                  rows={6}
                  maxLength={2000}
                />
                <p className="text-xs text-muted-foreground text-right">
                  {message.length}/2000
                </p>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setDialogOpen(false)}
                  disabled={submitting}
                >
                  रद्द करें
                </Button>
                <Button type="submit" disabled={submitting} className="gap-2">
                  {submitting ? (
                    <>
                      <span className="animate-spin">⏳</span>
                      भेजा जा रहा है...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" />
                      भेजें
                    </>
                  )}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-3/4 bg-muted" />
                <Skeleton className="h-4 w-1/2 bg-muted" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20 w-full bg-muted" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : feedbacks.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <MessageSquare className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">कोई फीडबैक नहीं</h3>
            <p className="text-muted-foreground text-center mb-4">
              आपने अभी तक कोई फीडबैक नहीं भेजा है
            </p>
            <Button onClick={() => setDialogOpen(true)} className="gap-2">
              <Send className="h-4 w-4" />
              पहला फीडबैक भेजें
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {feedbacks.map((feedback) => (
            <Card key={feedback.id}>
              <CardHeader>
                <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-2">
                  <CardTitle className="text-lg">{feedback.subject}</CardTitle>
                  {getStatusBadge(feedback.status)}
                </div>
                <CardDescription>
                  {formatDate(feedback.created_at)}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="text-sm font-semibold mb-2">आपका संदेश:</h4>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                    {feedback.message}
                  </p>
                </div>
                
                {feedback.admin_reply && (
                  <div className="border-t pt-4">
                    <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                      <MessageCircle className="h-4 w-4 text-primary" />
                      एडमिन का जवाब:
                    </h4>
                    <div className="bg-muted/50 p-3 rounded-lg">
                      <p className="text-sm whitespace-pre-wrap">
                        {feedback.admin_reply}
                      </p>
                      {feedback.replied_at && (
                        <p className="text-xs text-muted-foreground mt-2">
                          {formatDate(feedback.replied_at)}
                        </p>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
