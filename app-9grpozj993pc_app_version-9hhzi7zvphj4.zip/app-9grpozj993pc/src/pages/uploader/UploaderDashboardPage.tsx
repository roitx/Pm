import * as React from 'react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import { 
  Upload, 
  FileText, 
  ClipboardList, 
  BarChart3, 
  Settings,
  BookOpen,
  FileQuestion,
  Brain,
  TrendingUp,
  MessageSquare
} from 'lucide-react';

export default function UploaderDashboardPage() {
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const [stats, setStats] = useState({
    totalContent: 0,
    totalMCQ: 0,
    totalIITJEE: 0,
    recentUploads: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadStats();
    }
  }, [user]);

  const loadStats = async () => {
    if (!user) return;

    setLoading(true);
    try {
      // Get content count uploaded by this user
      const { count: contentCount } = await supabase
        .from('content')
        .select('*', { count: 'exact', head: true })
        .eq('uploaded_by', user.id);

      // Get MCQ count created by this user
      const { count: mcqCount } = await supabase
        .from('mcq_questions')
        .select('*', { count: 'exact', head: true })
        .eq('created_by', user.id)
        .neq('category', 'iit_jee_questions');

      // Get IIT-JEE count created by this user
      const { count: iitjeeCount } = await supabase
        .from('mcq_questions')
        .select('*', { count: 'exact', head: true })
        .eq('created_by', user.id)
        .eq('category', 'iit_jee_questions');

      // Get recent uploads (last 7 days)
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      
      const { count: recentCount } = await supabase
        .from('content')
        .select('*', { count: 'exact', head: true })
        .eq('uploaded_by', user.id)
        .gte('created_at', sevenDaysAgo.toISOString());

      setStats({
        totalContent: contentCount || 0,
        totalMCQ: mcqCount || 0,
        totalIITJEE: iitjeeCount || 0,
        recentUploads: recentCount || 0,
      });
    } catch (error) {
      console.error('Error loading stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const quickActions = [
    {
      title: 'सामग्री अपलोड करें',
      description: 'नोट्स, PYQ, किताबें अपलोड करें',
      icon: Upload,
      path: '/uploader/upload',
      color: 'text-blue-500',
    },
    {
      title: 'MCQ अपलोड करें',
      description: 'MCQ प्रश्न जोड़ें',
      icon: ClipboardList,
      path: '/uploader/mcq-upload',
      color: 'text-green-500',
    },
    {
      title: 'IIT-JEE अपलोड करें',
      description: 'IIT-JEE प्रश्न जोड़ें',
      icon: Brain,
      path: '/uploader/iitjee-upload',
      color: 'text-purple-500',
    },
    {
      title: 'सामग्री प्रबंधन',
      description: 'अपनी सामग्री देखें और संपादित करें',
      icon: FileText,
      path: '/uploader/content-management',
      color: 'text-orange-500',
    },
    {
      title: 'फीडबैक भेजें',
      description: 'एडमिन को अपनी समस्याएं और सुझाव भेजें',
      icon: MessageSquare,
      path: '/uploader/feedback',
      color: 'text-green-500',
    },
  ];

  return (
    <div className="container mx-auto p-4 xl:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4">
        <div>
          <h1 className="text-2xl xl:text-3xl font-bold">अपलोडर डैशबोर्ड</h1>
          <p className="text-muted-foreground mt-1">
            स्वागत है, {profile?.full_name || 'अपलोडर'}!
          </p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">कुल सामग्री</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-8 w-20 bg-muted" />
            ) : (
              <div className="text-2xl font-bold">{stats.totalContent}</div>
            )}
            <p className="text-xs text-muted-foreground mt-1">
              आपके द्वारा अपलोड की गई
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">MCQ प्रश्न</CardTitle>
            <ClipboardList className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-8 w-20 bg-muted" />
            ) : (
              <div className="text-2xl font-bold">{stats.totalMCQ}</div>
            )}
            <p className="text-xs text-muted-foreground mt-1">
              आपके द्वारा बनाए गए
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">IIT-JEE प्रश्न</CardTitle>
            <Brain className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-8 w-20 bg-muted" />
            ) : (
              <div className="text-2xl font-bold">{stats.totalIITJEE}</div>
            )}
            <p className="text-xs text-muted-foreground mt-1">
              आपके द्वारा बनाए गए
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">हाल के अपलोड</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-8 w-20 bg-muted" />
            ) : (
              <div className="text-2xl font-bold">{stats.recentUploads}</div>
            )}
            <p className="text-xs text-muted-foreground mt-1">
              पिछले 7 दिनों में
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-xl font-semibold mb-4">त्वरित कार्य</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {quickActions.map((action) => (
            <Card
              key={action.path}
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => navigate(action.path)}
            >
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg bg-muted ${action.color}`}>
                    <action.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-base">{action.title}</CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>{action.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Info Card */}
      <Card className="bg-muted/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            अपलोडर जानकारी
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p>✅ आप सामग्री अपलोड कर सकते हैं (PDF, Images, etc.)</p>
          <p>✅ आप MCQ और IIT-JEE प्रश्न जोड़ सकते हैं</p>
          <p>✅ आप अपनी अपलोड की गई सामग्री को संपादित कर सकते हैं</p>
          <p>✅ आप अपनी सामग्री को हटा सकते हैं</p>
          <p>⚠️ आप अन्य अपलोडर्स की सामग्री को संपादित नहीं कर सकते</p>
          <p>⚠️ केवल एडमिन सभी सामग्री को प्रबंधित कर सकते हैं</p>
        </CardContent>
      </Card>
    </div>
  );
}
