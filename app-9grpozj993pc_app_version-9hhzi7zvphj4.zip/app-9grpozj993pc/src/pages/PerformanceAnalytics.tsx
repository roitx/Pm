import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, TrendingUp, TrendingDown, Award, Target, BookOpen, Clock, Calendar, BarChart3 } from 'lucide-react';

export default function PerformanceAnalytics() {
  const navigate = useNavigate();

  // नमूना डेटा
  const overallStats = {
    totalTests: 42,
    averageScore: 87,
    studyHours: 124,
    rank: 15,
    totalStudents: 250,
  };

  const subjectPerformance = [
    { subject: 'गणित', score: 92, tests: 12, trend: 'up', improvement: '+5%', color: 'from-blue-500 to-cyan-500' },
    { subject: 'भौतिकी', score: 88, tests: 10, trend: 'up', improvement: '+3%', color: 'from-purple-500 to-pink-500' },
    { subject: 'रसायन विज्ञान', score: 85, tests: 11, trend: 'down', improvement: '-2%', color: 'from-green-500 to-emerald-500' },
    { subject: 'जीव विज्ञान', score: 83, tests: 9, trend: 'up', improvement: '+7%', color: 'from-orange-500 to-red-500' },
  ];

  const recentTests = [
    { id: 1, name: 'गणित - द्विघात समीकरण', date: '2026-01-10', score: 95, total: 100, time: '45 मिनट' },
    { id: 2, name: 'भौतिकी - गति के नियम', date: '2026-01-09', score: 88, total: 100, time: '50 मिनट' },
    { id: 3, name: 'रसायन विज्ञान - रासायनिक बंधन', date: '2026-01-08', score: 82, total: 100, time: '40 मिनट' },
    { id: 4, name: 'जीव विज्ञान - कोशिका विभाजन', date: '2026-01-07', score: 90, total: 100, time: '35 मिनट' },
    { id: 5, name: 'गणित - त्रिकोणमिति', date: '2026-01-06', score: 87, total: 100, time: '48 मिनट' },
  ];

  const strengths = [
    { topic: 'द्विघात समीकरण', accuracy: 95, color: 'text-green-500' },
    { topic: 'न्यूटन के नियम', accuracy: 92, color: 'text-green-500' },
    { topic: 'कोशिका विभाजन', accuracy: 90, color: 'text-green-500' },
  ];

  const weaknesses = [
    { topic: 'कार्बनिक रसायन', accuracy: 68, color: 'text-red-500' },
    { topic: 'विद्युत चुंबकत्व', accuracy: 72, color: 'text-orange-500' },
    { topic: 'आनुवंशिकी', accuracy: 75, color: 'text-yellow-500' },
  ];

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-500';
    if (score >= 75) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getScoreBadge = (score: number) => {
    if (score >= 90) return 'bg-green-500/10 text-green-500 border-green-500/20';
    if (score >= 75) return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
    return 'bg-red-500/10 text-red-500 border-red-500/20';
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/student')}
              className="shrink-0"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold gradient-text">प्रदर्शन विश्लेषण</h1>
              <p className="text-sm text-muted-foreground">अपनी प्रगति को ट्रैक करें</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Overall Stats */}
        <div className="grid grid-cols-2 xl:grid-cols-5 gap-4 mb-8">
          <Card className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border-blue-500/20">
            <CardContent className="p-4 xl:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">कुल टेस्ट</p>
                  <p className="text-2xl xl:text-3xl font-bold">{overallStats.totalTests}</p>
                </div>
                <BookOpen className="w-8 h-8 xl:w-10 xl:h-10 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/20">
            <CardContent className="p-4 xl:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">औसत स्कोर</p>
                  <p className="text-2xl xl:text-3xl font-bold">{overallStats.averageScore}%</p>
                </div>
                <Target className="w-8 h-8 xl:w-10 xl:h-10 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500/10 to-red-500/10 border-orange-500/20">
            <CardContent className="p-4 xl:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">अध्ययन समय</p>
                  <p className="text-2xl xl:text-3xl font-bold">{overallStats.studyHours}घं</p>
                </div>
                <Clock className="w-8 h-8 xl:w-10 xl:h-10 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/20">
            <CardContent className="p-4 xl:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">रैंक</p>
                  <p className="text-2xl xl:text-3xl font-bold">#{overallStats.rank}</p>
                </div>
                <Award className="w-8 h-8 xl:w-10 xl:h-10 text-purple-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-pink-500/10 to-rose-500/10 border-pink-500/20">
            <CardContent className="p-4 xl:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">कुल छात्र</p>
                  <p className="text-2xl xl:text-3xl font-bold">{overallStats.totalStudents}</p>
                </div>
                <BarChart3 className="w-8 h-8 xl:w-10 xl:h-10 text-pink-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Subject Performance */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              विषय-वार प्रदर्शन
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
              {subjectPerformance.map((subject) => (
                <Card key={subject.subject} className="overflow-hidden">
                  <div className={`h-2 bg-gradient-to-r ${subject.color}`} />
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-bold text-lg">{subject.subject}</h3>
                      <div className="flex items-center gap-2">
                        {subject.trend === 'up' ? (
                          <TrendingUp className="w-5 h-5 text-green-500" />
                        ) : (
                          <TrendingDown className="w-5 h-5 text-red-500" />
                        )}
                        <span className={subject.trend === 'up' ? 'text-green-500' : 'text-red-500'}>
                          {subject.improvement}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">औसत स्कोर</span>
                        <span className={`font-bold ${getScoreColor(subject.score)}`}>
                          {subject.score}%
                        </span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div
                          className={`h-2 rounded-full bg-gradient-to-r ${subject.color}`}
                          style={{ width: `${subject.score}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-sm text-muted-foreground">
                        <span>{subject.tests} टेस्ट पूर्ण</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mb-8">
          {/* Strengths */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-500">
                <TrendingUp className="w-5 h-5" />
                मजबूत विषय
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {strengths.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-green-500/5 border border-green-500/20">
                  <span className="font-medium">{item.topic}</span>
                  <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                    {item.accuracy}% सटीकता
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Weaknesses */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-orange-500">
                <Target className="w-5 h-5" />
                सुधार की आवश्यकता
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {weaknesses.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-orange-500/5 border border-orange-500/20">
                  <span className="font-medium">{item.topic}</span>
                  <Badge variant="outline" className="bg-orange-500/10 text-orange-500 border-orange-500/20">
                    {item.accuracy}% सटीकता
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Recent Tests */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              हाल के टेस्ट
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentTests.map((test) => (
                <Card key={test.id} className="hover:shadow-lg transition-shadow duration-300">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold mb-1 truncate">{test.name}</h3>
                        <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {test.date}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {test.time}
                          </span>
                        </div>
                      </div>
                      <Badge variant="outline" className={getScoreBadge((test.score / test.total) * 100)}>
                        {test.score}/{test.total}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
