import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Search, Play, Clock, BookOpen, Filter } from 'lucide-react';

export default function VideoLectures() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClass, setSelectedClass] = useState<string>('all');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');

  // नमूना वीडियो डेटा
  const videos = [
    {
      id: 1,
      title: 'द्विघात समीकरण - भाग 1',
      subject: 'गणित',
      class: '10',
      duration: '45:30',
      thumbnail: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=400&h=225&fit=crop',
      views: '1.2K',
      instructor: 'राज शर्मा',
      description: 'द्विघात समीकरण की मूल अवधारणाएं और हल करने की विधियां'
    },
    {
      id: 2,
      title: 'रासायनिक बंधन',
      subject: 'रसायन विज्ञान',
      class: '11',
      duration: '38:15',
      thumbnail: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=400&h=225&fit=crop',
      views: '856',
      instructor: 'प्रिया वर्मा',
      description: 'आयनिक और सहसंयोजक बंधन की विस्तृत व्याख्या'
    },
    {
      id: 3,
      title: 'न्यूटन के गति के नियम',
      subject: 'भौतिकी',
      class: '9',
      duration: '52:00',
      thumbnail: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&h=225&fit=crop',
      views: '2.1K',
      instructor: 'अमित कुमार',
      description: 'गति के तीनों नियमों का व्यावहारिक उदाहरणों के साथ विवरण'
    },
    {
      id: 4,
      title: 'कोशिका विभाजन - माइटोसिस',
      subject: 'जीव विज्ञान',
      class: '12',
      duration: '41:20',
      thumbnail: 'https://images.unsplash.com/photo-1576086213369-97a306d36557?w=400&h=225&fit=crop',
      views: '945',
      instructor: 'डॉ. सुनीता पटेल',
      description: 'माइटोसिस की प्रक्रिया और इसके विभिन्न चरण'
    },
    {
      id: 5,
      title: 'त्रिकोणमिति के सूत्र',
      subject: 'गणित',
      class: '11',
      duration: '35:45',
      thumbnail: 'https://images.unsplash.com/photo-1635372722656-389f87a941b7?w=400&h=225&fit=crop',
      views: '1.5K',
      instructor: 'राज शर्मा',
      description: 'सभी महत्वपूर्ण त्रिकोणमितीय सूत्र और उनके अनुप्रयोग'
    },
    {
      id: 6,
      title: 'विद्युत धारा और परिपथ',
      subject: 'भौतिकी',
      class: '10',
      duration: '48:30',
      thumbnail: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=225&fit=crop',
      views: '1.8K',
      instructor: 'अमित कुमार',
      description: 'विद्युत धारा, वोल्टेज और प्रतिरोध की अवधारणाएं'
    },
    {
      id: 7,
      title: 'कार्बनिक रसायन - परिचय',
      subject: 'रसायन विज्ञान',
      class: '12',
      duration: '55:10',
      thumbnail: 'https://images.unsplash.com/photo-1603126857599-f6e157fa2fe6?w=400&h=225&fit=crop',
      views: '1.1K',
      instructor: 'प्रिया वर्मा',
      description: 'कार्बनिक यौगिकों का वर्गीकरण और नामकरण'
    },
    {
      id: 8,
      title: 'पारिस्थितिकी तंत्र',
      subject: 'जीव विज्ञान',
      class: '11',
      duration: '43:25',
      thumbnail: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=400&h=225&fit=crop',
      views: '892',
      instructor: 'डॉ. सुनीता पटेल',
      description: 'पारिस्थितिकी तंत्र के घटक और ऊर्जा प्रवाह'
    },
  ];

  const classes = ['8', '9', '10', '11', '12'];
  const subjects = ['गणित', 'भौतिकी', 'रसायन विज्ञान', 'जीव विज्ञान'];

  // फ़िल्टर किए गए वीडियो
  const filteredVideos = videos.filter(video => {
    const matchesSearch = video.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         video.subject.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesClass = selectedClass === 'all' || video.class === selectedClass;
    const matchesSubject = selectedSubject === 'all' || video.subject === selectedSubject;
    return matchesSearch && matchesClass && matchesSubject;
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/student')}
              className="shrink-0"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold gradient-text">वीडियो लेक्चर</h1>
              <p className="text-sm text-muted-foreground">विडियो द्वारा सीखें</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="वीडियो खोजें..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12"
            />
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-medium">फ़िल्टर:</span>
            </div>

            {/* Class Filter */}
            <div className="flex flex-wrap gap-2">
              <Badge
                variant={selectedClass === 'all' ? 'default' : 'outline'}
                className="cursor-pointer"
                onClick={() => setSelectedClass('all')}
              >
                सभी कक्षाएं
              </Badge>
              {classes.map((cls) => (
                <Badge
                  key={cls}
                  variant={selectedClass === cls ? 'default' : 'outline'}
                  className="cursor-pointer"
                  onClick={() => setSelectedClass(cls)}
                >
                  कक्षा {cls}
                </Badge>
              ))}
            </div>

            {/* Subject Filter */}
            <div className="flex flex-wrap gap-2">
              <Badge
                variant={selectedSubject === 'all' ? 'default' : 'outline'}
                className="cursor-pointer"
                onClick={() => setSelectedSubject('all')}
              >
                सभी विषय
              </Badge>
              {subjects.map((subject) => (
                <Badge
                  key={subject}
                  variant={selectedSubject === subject ? 'default' : 'outline'}
                  className="cursor-pointer"
                  onClick={() => setSelectedSubject(subject)}
                >
                  {subject}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-muted-foreground">
            {filteredVideos.length} वीडियो मिले
          </p>
        </div>

        {/* Videos Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredVideos.map((video) => (
            <Card
              key={video.id}
              className="group cursor-pointer hover:shadow-xl transition-all duration-300 hover:scale-105 overflow-hidden"
            >
              {/* Thumbnail */}
              <div className="relative aspect-video overflow-hidden bg-muted">
                <img
                  src={video.thumbnail}
                  alt={video.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center">
                    <Play className="w-8 h-8 text-primary-foreground ml-1" />
                  </div>
                </div>
                <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-1 rounded">
                  <Clock className="w-3 h-3 inline mr-1" />
                  {video.duration}
                </div>
              </div>

              {/* Content */}
              <CardContent className="p-4">
                <div className="flex items-start gap-2 mb-2">
                  <Badge variant="secondary" className="text-xs">
                    कक्षा {video.class}
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {video.subject}
                  </Badge>
                </div>

                <h3 className="font-bold text-lg mb-2 line-clamp-2 group-hover:text-primary transition-colors">
                  {video.title}
                </h3>

                <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                  {video.description}
                </p>

                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <BookOpen className="w-4 h-4" />
                    {video.instructor}
                  </span>
                  <span>{video.views} बार देखा गया</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* No Results */}
        {filteredVideos.length === 0 && (
          <div className="text-center py-12">
            <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
              <Play className="w-12 h-12 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold mb-2">कोई वीडियो नहीं मिला</h3>
            <p className="text-muted-foreground">
              कृपया अपने खोज मानदंड बदलें और पुनः प्रयास करें
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
