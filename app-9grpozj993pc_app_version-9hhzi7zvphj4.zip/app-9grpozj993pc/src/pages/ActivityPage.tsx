import * as React from 'react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, Search, Eye, Clock, Calendar, FileText, Filter, Trash2 } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { formatDate } from '@/lib/constants';
import type { Content, TestResult } from '@/types/types';

interface Activity {
  id: string;
  type: 'mcq' | 'pdf' | 'content';
  title: string;
  subtitle?: string;
  timestamp: string;
  views?: number;
  score?: number;
  total_questions?: number;
  time_taken?: number;
}

export default function ActivityPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [activities, setActivities] = useState<Activity[]>([]);
  const [filteredActivities, setFilteredActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'mcq' | 'content'>('all');

  useEffect(() => {
    if (user) {
      loadActivities();
    }
  }, [user]);

  useEffect(() => {
    applyFilters();
  }, [activities, searchQuery, filterType]);

  const applyFilters = () => {
    let filtered = [...activities];

    // Filter by type
    if (filterType !== 'all') {
      filtered = filtered.filter(activity => activity.type === filterType);
    }

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(activity =>
        activity.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        activity.subtitle?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    setFilteredActivities(filtered);
  };

  const loadActivities = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const allActivities: Activity[] = [];

      // Load MCQ test results
      const { data: testResults, error: testError } = await supabase
        .from('mcq_test_results')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (!testError && testResults) {
        for (const result of testResults) {
          allActivities.push({
            id: result.id,
            type: 'mcq',
            title: result.test_name || 'Mix Test',
            subtitle: result.subject || 'Mix Test',
            timestamp: result.created_at,
            score: result.score,
            total_questions: result.total_questions,
            time_taken: result.time_taken,
          });
        }
      }

      // Load recently viewed content
      const { data: recentlyViewed, error: viewError } = await supabase
        .from('recently_viewed')
        .select(`
          id,
          viewed_at,
          content:content_id (
            id,
            title,
            subject,
            category,
            file_type
          )
        `)
        .eq('user_id', user.id)
        .order('viewed_at', { ascending: false })
        .limit(50);

      if (!viewError && recentlyViewed) {
        for (const view of recentlyViewed) {
          if (view.content) {
            const content = view.content as any;
            allActivities.push({
              id: view.id,
              type: content.file_type === 'application/pdf' ? 'pdf' : 'content',
              title: content.title || 'बिना शीर्षक',
              subtitle: content.subject || content.category,
              timestamp: view.viewed_at,
            });
          }
        }
      }

      // Load downloads
      const { data: downloads, error: downloadError } = await supabase
        .from('downloads')
        .select(`
          id,
          downloaded_at,
          content:content_id (
            id,
            title,
            subject,
            category,
            file_type
          )
        `)
        .eq('user_id', user.id)
        .order('downloaded_at', { ascending: false })
        .limit(50);

      if (!downloadError && downloads) {
        for (const download of downloads) {
          if (download.content) {
            const content = download.content as any;
            allActivities.push({
              id: download.id,
              type: 'pdf',
              title: `📥 ${content.title || 'बिना शीर्षक'}`,
              subtitle: `डाउनलोड किया गया - ${content.subject || content.category}`,
              timestamp: download.downloaded_at,
            });
          }
        }
      }

      // Sort all activities by timestamp
      allActivities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

      setActivities(allActivities);
      setFilteredActivities(allActivities);
    } catch (error) {
      console.error('Error loading activities:', error);
    } finally {
      setLoading(false);
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'mcq':
        return <FileText className="h-5 w-5" />;
      case 'pdf':
        return <FileText className="h-5 w-5" />;
      default:
        return <Eye className="h-5 w-5" />;
    }
  };

  const getActivityBadge = (type: string) => {
    switch (type) {
      case 'mcq':
        return <Badge className="bg-primary/10 text-primary border-primary/20">MCQ</Badge>;
      case 'pdf':
        return <Badge className="bg-green-500/10 text-green-500 border-green-500/20">PDF</Badge>;
      default:
        return <Badge className="bg-secondary/10 text-secondary border-secondary/20">सामग्री</Badge>;
    }
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const past = new Date(timestamp);
    const diffInSeconds = Math.floor((now.getTime() - past.getTime()) / 1000);

    if (diffInSeconds < 60) return 'अभी';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} मिनट पहले`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} घंटे पहले`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)} दिन पहले`;
    return formatDate(timestamp);
  };

  const formatTimeTaken = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')} min, ${secs.toString().padStart(2, '0')} sec`;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(-1)}
              className="shrink-0"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl font-bold gradient-text">गतिविधियाँ</h1>
              <p className="text-sm text-muted-foreground">आपकी हाल की गतिविधियाँ</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* Search and Filters */}
        <Card className="glass-card">
          <CardContent className="pt-6 space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="गतिविधि खोजें..."
                className="pl-10"
              />
            </div>

            <div className="flex gap-2 flex-wrap">
              <Button
                variant={filterType === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterType('all')}
              >
                सभी
              </Button>
              <Button
                variant={filterType === 'mcq' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterType('mcq')}
              >
                MCQ टेस्ट
              </Button>
              <Button
                variant={filterType === 'content' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterType('content')}
              >
                सामग्री
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Activities List */}
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <Card key={i} className="glass-card">
                <CardContent className="pt-6">
                  <div className="flex gap-4">
                    <Skeleton className="h-12 w-12 rounded-lg bg-muted" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-5 w-3/4 bg-muted" />
                      <Skeleton className="h-4 w-1/2 bg-muted" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredActivities.length === 0 ? (
          <Card className="glass-card">
            <CardContent className="pt-6">
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
                  <Clock className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold mb-2">कोई गतिविधि नहीं</h3>
                <p className="text-muted-foreground">
                  {searchQuery || filterType !== 'all'
                    ? 'इस फ़िल्टर के लिए कोई गतिविधि नहीं मिली'
                    : 'अभी तक कोई गतिविधि नहीं है'}
                </p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {filteredActivities.map((activity) => (
              <Card key={activity.id} className="glass-card hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex gap-4">
                    <div className="shrink-0">
                      <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white">
                        {getActivityIcon(activity.type)}
                      </div>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-base break-words">
                            {activity.title}
                          </h3>
                          {activity.subtitle && (
                            <p className="text-sm text-muted-foreground">
                              {activity.subtitle}
                            </p>
                          )}
                        </div>
                        {getActivityBadge(activity.type)}
                      </div>

                      <div className="flex items-center gap-4 text-xs text-muted-foreground flex-wrap">
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          <span>{formatTimeAgo(activity.timestamp)}</span>
                        </div>

                        {activity.type === 'mcq' && activity.score !== undefined && (
                          <>
                            <div className="flex items-center gap-1">
                              <span className="font-semibold">स्कोर:</span>
                              <span>{activity.score}/{activity.total_questions}</span>
                              <span className="text-primary">
                                ({Math.round((activity.score / (activity.total_questions || 1)) * 100)}%)
                              </span>
                            </div>
                            {activity.time_taken && (
                              <div className="flex items-center gap-1">
                                <span className="font-semibold">समय:</span>
                                <span>{formatTimeTaken(activity.time_taken)}</span>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
