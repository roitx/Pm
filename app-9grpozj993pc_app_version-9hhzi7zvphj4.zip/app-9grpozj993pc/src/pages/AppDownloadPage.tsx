import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Smartphone, Share2, CheckCircle, Chrome, Menu as MenuIcon, Download, Loader2 } from 'lucide-react';
import { BookLogo } from '@/components/ui/BookLogo';
import { getActiveAPKFile } from '@/db/api';
import type { APKFile } from '@/types/types';
import { useToast } from '@/hooks/use-toast';

export default function AppDownloadPage() {
  const [apkFile, setApkFile] = useState<APKFile | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadAPKFile();
  }, []);

  const loadAPKFile = async () => {
    try {
      const data = await getActiveAPKFile();
      setApkFile(data);
    } catch (error) {
      console.error('Error loading APK file:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleShareApp = async () => {
    const appUrl = window.location.origin;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'PM - Roit Study Hub',
          text: 'कक्षा 8-12 के लिए संपूर्ण अध्ययन सामग्री - PM Roit ऐप डाउनलोड करें!',
          url: appUrl,
        });
      } catch (err) {
        console.log('Share cancelled');
      }
    } else {
      // Fallback: Copy link to clipboard
      navigator.clipboard.writeText(appUrl);
      alert('लिंक कॉपी हो गया! अब आप इसे किसी को भी भेज सकते हैं।');
    }
  };

  const handleDownloadAPK = () => {
    if (apkFile) {
      window.open(apkFile.download_url, '_blank');
      toast({
        title: 'डाउनलोड शुरू हो गया',
        description: 'APK फ़ाइल डाउनलोड हो रही है...',
      });
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(2)} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="container max-w-4xl mx-auto p-4 xl:p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex justify-center">
          <BookLogo size={120} />
        </div>
        <h1 className="text-3xl xl:text-4xl font-bold gradient-text">PM - Roit</h1>
        <p className="text-lg text-muted-foreground">Personal Manager - Rohit</p>
        <p className="text-muted-foreground">कक्षा 8-12 के लिए संपूर्ण अध्ययन सामग्री</p>
      </div>

      {/* APK Download Card */}
      {!loading && apkFile && (
        <Card className="glass-card border-secondary/30 bg-gradient-to-br from-secondary/5 to-accent/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-secondary">
              <Download className="w-6 h-6" />
              APK फ़ाइल डाउनलोड करें
            </CardTitle>
            <CardDescription>
              सीधे APK फ़ाइल डाउनलोड करें और अपने Android फोन में इंस्टॉल करें
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-card rounded-lg border space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-lg">वर्जन {apkFile.version_name}</p>
                  <p className="text-sm text-muted-foreground">
                    फ़ाइल साइज: {formatFileSize(apkFile.file_size)}
                  </p>
                </div>
                <Button
                  onClick={handleDownloadAPK}
                  size="lg"
                  className="bg-gradient-to-r from-secondary to-accent hover:opacity-90"
                >
                  <Download className="w-5 h-5 mr-2" />
                  डाउनलोड करें
                </Button>
              </div>
              {apkFile.release_notes && (
                <div className="pt-3 border-t">
                  <p className="text-sm font-medium mb-1">इस वर्जन में नया:</p>
                  <p className="text-sm text-muted-foreground">{apkFile.release_notes}</p>
                </div>
              )}
            </div>

            {/* Installation Instructions for APK */}
            <div className="space-y-3 text-sm">
              <p className="font-semibold">APK इंस्टॉल करने के लिए:</p>
              <div className="space-y-2 pl-4">
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-secondary mt-0.5 shrink-0" />
                  <p>1. ऊपर दिए गए बटन से APK डाउनलोड करें</p>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-secondary mt-0.5 shrink-0" />
                  <p>2. डाउनलोड की गई फ़ाइल पर क्लिक करें</p>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-secondary mt-0.5 shrink-0" />
                  <p>3. "Unknown sources से इंस्टॉल करें" की अनुमति दें (अगर पूछे)</p>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-secondary mt-0.5 shrink-0" />
                  <p>4. "Install" बटन पर क्लिक करें</p>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-secondary mt-0.5 shrink-0" />
                  <p>5. इंस्टॉलेशन पूरा होने के बाद ऐप खोलें</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {loading && (
        <Card className="glass-card">
          <CardContent className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </CardContent>
        </Card>
      )}

      {/* PWA Installation Card */}
      <Card className="glass-card border-primary/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-primary">
            <Smartphone className="w-6 h-6" />
            ऐप इंस्टॉल करें (बिना APK के)
          </CardTitle>
          <CardDescription>
            अपने मोबाइल में PM - Roit ऐप इंस्टॉल करें - कोई APK डाउनलोड की जरूरत नहीं!
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Android Chrome Instructions */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Chrome className="w-5 h-5 text-primary" />
              Android (Chrome Browser) में इंस्टॉल करें:
            </h3>
            <div className="space-y-3 pl-7">
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium">1. Chrome में यह वेबसाइट खोलें</p>
                  <p className="text-sm text-muted-foreground">अगर दूसरे browser में हैं तो Chrome में खोलें</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium">2. ऊपर दाएं कोने में 3 dots (⋮) पर क्लिक करें</p>
                  <p className="text-sm text-muted-foreground">या नीचे "Install App" बटन दिखेगा</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium">3. "Add to Home screen" या "Install app" पर क्लिक करें</p>
                  <p className="text-sm text-muted-foreground">यह option menu में मिलेगा</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium">4. "Install" या "Add" बटन पर क्लिक करें</p>
                  <p className="text-sm text-muted-foreground">ऐप आपके होम स्क्रीन पर आ जाएगा</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium">5. होम स्क्रीन से PM - Roit ऐप खोलें</p>
                  <p className="text-sm text-muted-foreground">अब यह एक normal app की तरह काम करेगा</p>
                </div>
              </div>
            </div>
          </div>

          {/* iOS Safari Instructions */}
          <div className="space-y-4 pt-4 border-t">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-primary" />
              iPhone/iPad (Safari) में इंस्टॉल करें:
            </h3>
            <div className="space-y-3 pl-7">
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium">1. Safari browser में यह वेबसाइट खोलें</p>
                  <p className="text-sm text-muted-foreground">iPhone/iPad में Safari use करें</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium">2. नीचे Share button (□↑) पर tap करें</p>
                  <p className="text-sm text-muted-foreground">यह bottom bar में होता है</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium">3. "Add to Home Screen" option चुनें</p>
                  <p className="text-sm text-muted-foreground">नीचे scroll करके देखें</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium">4. "Add" बटन पर tap करें</p>
                  <p className="text-sm text-muted-foreground">ऐप होम स्क्रीन पर add हो जाएगा</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Share Button */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Share2 className="w-6 h-6" />
            दोस्तों को Refer करें
          </CardTitle>
          <CardDescription>
            अपने दोस्तों के साथ PM - Roit ऐप शेयर करें
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button
            onClick={handleShareApp}
            className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-lg py-6"
            size="lg"
          >
            <Share2 className="w-5 h-5 mr-2" />
            ऐप लिंक शेयर करें
          </Button>
          <p className="text-sm text-muted-foreground mt-3 text-center">
            लिंक शेयर करने के बाद, अपने दोस्तों को ऊपर दिए गए steps follow करने को कहें
          </p>
        </CardContent>
      </Card>

      {/* Features Card */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="w-6 h-6" />
            ऐप की विशेषताएं
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="font-medium">ऑफलाइन एक्सेस</p>
                <p className="text-sm text-muted-foreground">बिना इंटरनेट के भी पढ़ाई करें</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="font-medium">तेज़ लोडिंग</p>
                <p className="text-sm text-muted-foreground">Native app जैसी स्पीड</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="font-medium">कोई APK नहीं</p>
                <p className="text-sm text-muted-foreground">Direct browser से install करें</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="font-medium">होम स्क्रीन शॉर्टकट</p>
                <p className="text-sm text-muted-foreground">एक क्लिक में ऐप खोलें</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="font-medium">सभी कंटेंट एक जगह</p>
                <p className="text-sm text-muted-foreground">Notes, PYQ, MCQ सब कुछ</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="font-medium">AI सहायक</p>
                <p className="text-sm text-muted-foreground">24/7 डाउट सॉल्विंग</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Info Card */}
      <Card className="glass-card bg-primary/5 border-primary/20">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <Smartphone className="w-6 h-6 text-primary mt-0.5 shrink-0" />
            <div className="space-y-2">
              <p className="font-medium">नोट: यह एक Progressive Web App (PWA) है</p>
              <p className="text-sm text-muted-foreground">
                इसे install करने के लिए किसी APK की जरूरत नहीं है। बस अपने browser (Chrome/Safari) में खोलें और "Add to Home Screen" करें। यह बिल्कुल normal app की तरह काम करेगा!
              </p>
              <p className="text-sm text-muted-foreground font-medium mt-3">
                💡 Tip: अगर "Install" button नहीं दिख रहा, तो browser menu (⋮) में "Add to Home screen" option देखें।
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
