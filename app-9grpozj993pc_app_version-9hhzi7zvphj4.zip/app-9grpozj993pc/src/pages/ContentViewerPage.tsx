import * as React from 'react';
import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { getContentById, addRecentlyViewed, addDownload, addBookmark, removeBookmark, isBookmarked, checkFeatureAccess, trackFeatureUsage, getDailyUsageStats } from '@/db/api';
import { useAuth } from '@/contexts/AuthContext';
import { PDFViewer } from '@/components/ui/PDFViewer';
import { ImageViewer } from '@/components/ui/ImageViewer';
import { EmbeddedViewer } from '@/components/ui/EmbeddedViewer';
import { ArrowLeft, Download, Eye, BookOpen, Book, FileText, File, Bookmark, BookmarkCheck, Crown, Lock, Maximize2 } from 'lucide-react';
import { formatDate } from '@/lib/constants';
import type { Content } from '@/types/types';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function ContentViewerPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const [content, setContent] = useState<Content | null>(null);
  const [loading, setLoading] = useState(true);
  const [bookmarked, setBookmarked] = useState(false);
  const [checkingBookmark, setCheckingBookmark] = useState(false);
  const [downloadUsage, setDownloadUsage] = useState<{ count: number; limit: number } | null>(null);
  const [imageViewerOpen, setImageViewerOpen] = useState(false);

  useEffect(() => {
    if (id && user) {
      loadContent();
      loadDownloadUsage();
    }
  }, [id, user]);

  const loadDownloadUsage = async () => {
    if (!user) return;
    try {
      const usage = await getDailyUsageStats(user.id, 'unlimited_downloads');
      const isPremium = profile?.is_premium || false;
      setDownloadUsage({
        count: usage?.count || 0,
        limit: isPremium ? 999 : 20, // 20 for free users, unlimited for premium
      });
    } catch (error) {
      console.error('Error loading download usage:', error);
    }
  };

  const loadContent = async () => {
    if (!id || !user) return;

    setLoading(true);
    try {
      const data = await getContentById(id);
      if (data) {
        setContent(data);
        // Track view
        await addRecentlyViewed(user.id, id);
        // Check if bookmarked
        const bookmarkStatus = await isBookmarked(user.id, id);
        setBookmarked(bookmarkStatus);
      } else {
        toast({
          title: 'त्रुटि',
          description: 'सामग्री नहीं मिली',
          variant: 'destructive',
        });
        navigate('/dashboard');
      }
    } catch (error) {
      console.error('Error loading content:', error);
      toast({
        title: 'त्रुटि',
        description: 'सामग्री लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async () => {
    if (!content || !user) return;

    try {
      // Check download limit
      const hasAccess = await checkFeatureAccess(user.id, 'unlimited_downloads');
      
      if (!hasAccess) {
        toast({
          title: 'दैनिक सीमा पूर्ण',
          description: `आज की डाउनलोड सीमा पूर्ण। कल फिर प्रयास करें।`,
        });
        return;
      }

      // Track download
      await addDownload(user.id, content.id);
      await trackFeatureUsage(user.id, 'unlimited_downloads');

      // Download file
      const link = document.createElement('a');
      link.href = cleanUrl;
      link.download = content.title;
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Reload usage stats
      await loadDownloadUsage();

      toast({
        title: 'सफलता',
        description: 'डाउनलोड शुरू हो गया',
      });
    } catch (error) {
      console.error('Error downloading:', error);
      toast({
        title: 'त्रुटि',
        description: 'डाउनलोड करने में विफल',
        variant: 'destructive',
      });
    }
  };

  const handleToggleBookmark = async () => {
    if (!content || !user || checkingBookmark) return;

    setCheckingBookmark(true);
    try {
      if (bookmarked) {
        await removeBookmark(user.id, content.id);
        setBookmarked(false);
        toast({
          title: 'सफलता',
          description: 'बुकमार्क हटा दिया गया',
        });
      } else {
        await addBookmark(user.id, content.id);
        setBookmarked(true);
        toast({
          title: 'सफलता',
          description: 'बुकमार्क में जोड़ा गया',
        });
      }
    } catch (error) {
      console.error('Error toggling bookmark:', error);
      toast({
        title: 'त्रुटि',
        description: 'बुकमार्क अपडेट करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setCheckingBookmark(false);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto p-4 xl:p-6 space-y-4">
        <Skeleton className="h-12 w-full bg-muted" />
        <Skeleton className="h-[70vh] w-full bg-muted" />
      </div>
    );
  }

  if (!content) {
    return null;
  }

  const isPDF = 
    content.file_type === 'application/pdf' || 
    content.file_url.toLowerCase().includes('.pdf') || 
    content.file_url.includes('/storage/v1/object/public/'); 
    // Broadening to use PDFViewer for most storage objects if they aren't images
  
  const isImage = 
    content.file_type?.startsWith('image/') || 
    /\.(jpg|jpeg|png|gif|webp|svg)$/i.test(content.file_url.split('?')[0]) || 
    /\.(jpg|jpeg|png|gif|webp|svg)\?/i.test(content.file_url);

  // If it's a storage object and not an image, try PDF viewer as it's our most powerful viewer
  const isPDFLikely = isPDF || (content.file_url.includes('supabase.co') && !isImage);

  const isExternalLink = 
    content.file_type === 'link/external' || 
    (content.file_url.startsWith('http') && !isPDFLikely && !isImage);

  const getCleanUrl = (rawUrl: string) => {
    if (!rawUrl) return '';
    const trimmedUrl = rawUrl.trim();
    if (trimmedUrl.startsWith('http')) {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      if (trimmedUrl.includes('supabase.co') && supabaseUrl) {
        // If it already uses the correct domain, don't touch it
        if (trimmedUrl.startsWith(supabaseUrl)) return trimmedUrl;
        
        const urlParts = trimmedUrl.split('/storage/v1/object/public/');
        if (urlParts.length === 2) {
          // Rebuild with current project's domain
          return `${supabaseUrl}/storage/v1/object/public/${urlParts[1]}`;
        }
      }
      return trimmedUrl;
    }
    return trimmedUrl;
  };

  const cleanUrl = getCleanUrl(content.file_url);

  return (
    <div className={`${isPDF ? 'p-0 h-[100dvh] w-full fixed inset-0 z-[100] bg-background' : 'container mx-auto p-4 xl:p-6 space-y-4'}`}>
      {/* Download Usage Alert */}
      {downloadUsage && !profile?.is_premium && !isPDF && (
        <Alert className={downloadUsage.count >= downloadUsage.limit * 0.8 ? "border-destructive" : "border-primary"}>
          <Crown className="h-4 w-4" />
          <AlertTitle>दैनिक डाउनलोड सीमा</AlertTitle>
          <AlertDescription>
            आज {downloadUsage.count}/{downloadUsage.limit} डाउनलोड उपयोग किए गए।
            {downloadUsage.count >= downloadUsage.limit && " सीमा पूर्ण! कल फिर प्रयास करें या Premium में अपग्रेड करें।"}
          </AlertDescription>
        </Alert>
      )}

      {/* Header - Hide for PDF if showing integrated viewer */}
      {(!isPDF || !content) && (
        <Card className="glass-card">
          <CardHeader>
            <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4">
              <div className="flex items-start gap-3 min-w-0 flex-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => navigate(-1)}
                  className="shrink-0"
                >
                  <ArrowLeft className="h-5 w-5" />
                </Button>
                <div className="min-w-0 flex-1">
                  <CardTitle className="text-xl xl:text-2xl gradient-text break-words">
                    {content.title}
                  </CardTitle>
                  {content.description && (
                    <p className="text-sm text-muted-foreground mt-2 break-words">
                      {content.description}
                    </p>
                  )}
                  <div className="flex flex-wrap items-center gap-3 mt-3 text-xs text-muted-foreground">
                    <span><BookOpen className="inline h-4 w-4" /> कक्षा {content.class}</span>
                    <span>•</span>
                    <span><Book className="inline h-4 w-4" /> {content.subject}</span>
                    <span>•</span>
                    <span><FileText className="inline h-4 w-4" /> {content.chapter}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Eye className="h-3 w-3" />
                      {formatDate(content.created_at)}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={handleToggleBookmark}
                  variant="outline"
                  disabled={checkingBookmark}
                  className="w-full xl:w-auto"
                >
                  {bookmarked ? (
                    <>
                      <BookmarkCheck className="mr-2 h-4 w-4" />
                      बुकमार्क किया हुआ
                    </>
                  ) : (
                    <>
                      <Bookmark className="mr-2 h-4 w-4" />
                      बुकमार्क करें
                    </>
                  )}
                </Button>
                <Button
                  onClick={handleDownload}
                  disabled={downloadUsage ? downloadUsage.count >= downloadUsage.limit : false}
                  className="bg-gradient-to-r from-primary to-secondary hover:opacity-90 w-full xl:w-auto"
                >
                  {downloadUsage && downloadUsage.count >= downloadUsage.limit ? (
                    <>
                      <Lock className="mr-2 h-4 w-4" />
                      सीमा पूर्ण
                    </>
                  ) : (
                    <>
                      <Download className="mr-2 h-4 w-4" />
                      डाउनलोड करें
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardHeader>
        </Card>
      )}

      {/* Content Viewer */}
      {isPDFLikely ? (
        <PDFViewer 
          url={cleanUrl} 
          title={content.title}
          subtitle={`${content.subject} - ${content.chapter}`}
          onClose={() => navigate(-1)}
          onDownload={handleDownload}
        />
      ) : isImage ? (
        <div className="flex flex-col space-y-4">
          <Card className="glass-card overflow-hidden">
            <CardContent className="p-0">
              <div 
                className="bg-muted/10 flex items-center justify-center min-h-[50vh] xl:min-h-[70vh] p-2 md:p-4 relative group cursor-zoom-in"
                onClick={() => setImageViewerOpen(true)}
              >
                <img
                  src={cleanUrl}
                  alt={content.title}
                  className="max-w-full h-auto max-h-[85vh] object-contain rounded-md shadow-lg"
                />
                <Button
                  onClick={(e) => {
                    e.stopPropagation();
                    setImageViewerOpen(true);
                  }}
                  className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity bg-background/80 backdrop-blur-sm hover:bg-background"
                  size="sm"
                  variant="outline"
                >
                  <Maximize2 className="h-4 w-4 mr-2" />
                  बड़ा देखें
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <ImageViewer
            src={cleanUrl}
            alt={content.title}
            open={imageViewerOpen}
            onClose={() => setImageViewerOpen(false)}
          />
        </div>
      ) : isExternalLink ? (
        <EmbeddedViewer 
          url={cleanUrl} 
          title={content.title}
        />
      ) : (
        <Card className="glass-card">
          <CardContent className="flex flex-col items-center justify-center py-12 space-y-4">
            <div className="text-6xl"><File className="inline h-16 w-16" /></div>
            <h3 className="text-xl font-semibold">पूर्वावलोकन उपलब्ध नहीं</h3>
            <p className="text-muted-foreground text-center max-w-md">
              इस फाइल का पूर्वावलोकन नहीं दिखाया जा सकता। कृपया डाउनलोड करें।
            </p>
            <Button
              onClick={handleDownload}
              className="bg-gradient-to-r from-primary to-secondary"
            >
              <Download className="mr-2 h-4 w-4" />
              डाउनलोड करें
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
