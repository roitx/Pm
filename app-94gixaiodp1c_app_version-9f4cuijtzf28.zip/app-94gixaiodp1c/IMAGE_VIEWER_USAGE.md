# Image Viewer Component - Usage Guide

## Overview
ImageViewer component created for viewing images with zoom, rotate, and download features.

## Location
`/workspace/app-8vqzns7lohkx/src/components/ui/ImageViewer.tsx`

## Features
- ✅ Zoom In/Out (50% to 200%)
- ✅ Rotate (90-degree increments)
- ✅ Download image
- ✅ Close button
- ✅ Responsive design
- ✅ Smooth transitions

## How to Use

### Import
```tsx
import { ImageViewer } from '@/components/ui/ImageViewer';
```

### Basic Usage
```tsx
import { useState } from 'react';
import { ImageViewer } from '@/components/ui/ImageViewer';

function MyComponent() {
  const [viewerOpen, setViewerOpen] = useState(false);
  const [imageUrl, setImageUrl] = useState('');

  const handleImageClick = (url: string) => {
    setImageUrl(url);
    setViewerOpen(true);
  };

  return (
    <>
      <img 
        src="your-image-url.jpg" 
        alt="Click to view"
        onClick={() => handleImageClick('your-image-url.jpg')}
        className="cursor-pointer"
      />
      
      <ImageViewer
        src={imageUrl}
        alt="Image description"
        open={viewerOpen}
        onClose={() => setViewerOpen(false)}
      />
    </>
  );
}
```

## Props
- `src` (string, required): Image URL
- `alt` (string, optional): Image description
- `open` (boolean, required): Controls visibility
- `onClose` (function, required): Called when user closes viewer

## Controls
- **Zoom In**: Increase zoom by 25%
- **Zoom Out**: Decrease zoom by 25%
- **Rotate**: Rotate 90 degrees clockwise
- **Download**: Download image to device
- **Close**: Close viewer (X button)

## Example: Content Viewer Page
```tsx
// In ContentViewerPage.tsx or similar
const [showImageViewer, setShowImageViewer] = useState(false);

// When rendering image content
{content.file_type === 'image' && (
  <>
    <img
      src={content.file_url}
      alt={content.title}
      onClick={() => setShowImageViewer(true)}
      className="cursor-pointer hover:opacity-90 transition-opacity"
    />
    
    <ImageViewer
      src={content.file_url}
      alt={content.title}
      open={showImageViewer}
      onClose={() => setShowImageViewer(false)}
    />
  </>
)}
```

## Styling
- Uses shadcn/ui Dialog component
- Responsive: 95vw x 95vh
- Toolbar at top with controls
- Smooth CSS transitions
- Background: muted/20

## Notes
- Component automatically resets zoom and rotation on close
- Zoom range: 50% to 200%
- Rotation: 0°, 90°, 180°, 270° (cycles)
- Download uses browser's download API
- Works on all screen sizes
