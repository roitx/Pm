# शॉर्टकट समस्या निवारण गाइड / Shortcuts Troubleshooting Guide

## समस्या / Problem
ऐप आइकन को लॉन्ग प्रेस करने पर शॉर्टकट नहीं दिख रहे हैं।
App shortcuts are not showing when long-pressing the app icon.

---

## समाधान / Solution

### चरण 1: ऐप को अनइंस्टॉल करें / Step 1: Uninstall the App

**Android पर:**
1. ऐप आइकन को लॉन्ग प्रेस करें
2. "Uninstall" या "अनइंस्टॉल" चुनें
3. पुष्टि करें

**Desktop पर (Chrome/Edge):**
1. ब्राउज़र में ऐप खोलें
2. Address bar में तीन डॉट्स (⋮) क्लिक करें
3. "Uninstall PM - Roit" चुनें

---

### चरण 2: ब्राउज़र कैश साफ़ करें / Step 2: Clear Browser Cache

**Android Chrome:**
```
1. Chrome Settings खोलें
2. Privacy and Security → Clear browsing data
3. "Cached images and files" चुनें
4. Time range: "All time" चुनें
5. "Clear data" क्लिक करें
```

**Desktop Chrome:**
```
1. Ctrl + Shift + Delete दबाएं (Windows/Linux)
2. Cmd + Shift + Delete दबाएं (Mac)
3. "Cached images and files" चुनें
4. Time range: "All time"
5. "Clear data" क्लिक करें
```

---

### चरण 3: Service Worker साफ़ करें / Step 3: Clear Service Worker

**Chrome DevTools में:**
```
1. F12 दबाएं (DevTools खोलें)
2. "Application" टैब पर जाएं
3. बाईं ओर "Service Workers" चुनें
4. "Unregister" बटन क्लिक करें
5. "Storage" → "Clear site data" क्लिक करें
```

---

### चरण 4: ऐप को फिर से इंस्टॉल करें / Step 4: Reinstall the App

**Android:**
```
1. ब्राउज़र में ऐप URL खोलें
2. Address bar में "Install" आइकन दिखेगा
3. "Install" क्लिक करें
4. होम स्क्रीन पर ऐप आइकन दिखेगा
```

**Desktop:**
```
1. ब्राउज़र में ऐप खोलें
2. Address bar में Install आइकन (⊕) क्लिक करें
3. "Install" बटन क्लिक करें
```

---

### चरण 5: शॉर्टकट टेस्ट करें / Step 5: Test Shortcuts

**Android:**
```
1. होम स्क्रीन पर ऐप आइकन ढूंढें
2. आइकन को लॉन्ग प्रेस करें (2-3 सेकंड)
3. शॉर्टकट मेनू दिखना चाहिए:
   🟣 AI सहायक
   🔵 हाल ही में देखे गए
   🟢 डाउनलोड
   🟠 MCQ टेस्ट
```

**Desktop (Windows):**
```
1. Start Menu में ऐप ढूंढें
2. ऐप आइकन पर राइट क्लिक करें
3. Jump List में शॉर्टकट दिखने चाहिए
```

---

## अगर अभी भी काम नहीं कर रहा / If Still Not Working

### विकल्प A: ब्राउज़र अपडेट करें / Option A: Update Browser

```
1. Play Store खोलें (Android)
2. "Chrome" सर्च करें
3. "Update" क्लिक करें
4. अपडेट के बाद ऐप फिर से इंस्टॉल करें
```

### विकल्प B: Manifest कैश साफ़ करें / Option B: Clear Manifest Cache

**Chrome में:**
```
1. chrome://serviceworker-internals खोलें
2. अपनी ऐप ढूंढें
3. "Unregister" क्लिक करें
4. chrome://appcache-internals खोलें
5. अपनी ऐप के लिए "Remove" क्लिक करें
```

### विकल्प C: Force Refresh / Option C: Force Refresh

```
1. ऐप URL खोलें
2. Ctrl + Shift + R दबाएं (Windows/Linux)
3. Cmd + Shift + R दबाएं (Mac)
4. पेज पूरी तरह रीलोड होगा
5. फिर से इंस्टॉल करें
```

---

## तकनीकी जानकारी / Technical Information

### Manifest.json Configuration

```json
{
  "shortcuts": [
    {
      "name": "AI सहायक",
      "short_name": "AI",
      "description": "AI से प्रश्न पूछें और सीखें",
      "url": "/ai-helper",
      "icons": [
        {
          "src": "/icon-ai-helper.svg",
          "sizes": "192x192",
          "type": "image/svg+xml",
          "purpose": "any"
        }
      ]
    },
    {
      "name": "हाल ही में देखे गए",
      "short_name": "Recently Viewed",
      "description": "हाल ही में देखी गई सामग्री",
      "url": "/recently-viewed",
      "icons": [
        {
          "src": "/icon-recently-viewed.svg",
          "sizes": "192x192",
          "type": "image/svg+xml",
          "purpose": "any"
        }
      ]
    },
    {
      "name": "डाउनलोड",
      "short_name": "Downloads",
      "description": "डाउनलोड की गई सामग्री देखें",
      "url": "/downloads",
      "icons": [
        {
          "src": "/icon-downloads.svg",
          "sizes": "192x192",
          "type": "image/svg+xml",
          "purpose": "any"
        }
      ]
    },
    {
      "name": "MCQ टेस्ट",
      "short_name": "MCQ",
      "description": "अभ्यास परीक्षण दें",
      "url": "/mcq-test",
      "icons": [
        {
          "src": "/icon-mcq-test.svg",
          "sizes": "192x192",
          "type": "image/svg+xml",
          "purpose": "any"
        }
      ]
    }
  ]
}
```

### शॉर्टकट आइकन फ़ाइलें / Shortcut Icon Files

```
public/
├── icon-ai-helper.svg          ✅ Purple-Blue gradient (AI robot)
├── icon-recently-viewed.svg    ✅ Blue-Cyan gradient (Clock)
├── icon-downloads.svg          ✅ Green gradient (Download arrow)
└── icon-mcq-test.svg          ✅ Orange-Red gradient (Test paper)
```

---

## ब्राउज़र समर्थन / Browser Support

```
✅ Android Chrome 84+          - Full support
✅ Desktop Chrome 96+          - Full support
✅ Edge 96+                    - Full support
⚠️ Firefox                     - Limited support
❌ Safari (iOS)                - Not supported yet
```

---

## सामान्य समस्याएं / Common Issues

### समस्या 1: शॉर्टकट दिख नहीं रहे
**कारण:** पुराना manifest कैश में है
**समाधान:** ऐप अनइंस्टॉल करें, कैश साफ़ करें, फिर से इंस्टॉल करें

### समस्या 2: शॉर्टकट काम नहीं कर रहे
**कारण:** Service worker पुराना है
**समाधान:** Service worker unregister करें, फिर से इंस्टॉल करें

### समस्या 3: आइकन नहीं दिख रहे
**कारण:** SVG फ़ाइलें लोड नहीं हो रही हैं
**समाधान:** Network tab में check करें, फ़ाइलें accessible हैं या नहीं

---

## डेवलपर के लिए / For Developers

### Manifest Changes को Test करने के लिए:

```bash
# 1. Service worker unregister करें
# Chrome DevTools → Application → Service Workers → Unregister

# 2. Cache साफ़ करें
# Application → Storage → Clear site data

# 3. Hard refresh करें
# Ctrl + Shift + R (Windows/Linux)
# Cmd + Shift + R (Mac)

# 4. Manifest verify करें
# Application → Manifest → Check shortcuts array

# 5. Icons verify करें
# Network tab में icon URLs check करें
```

### Shortcuts Debug करने के लिए:

```javascript
// Console में run करें:
navigator.getInstalledRelatedApps().then(apps => {
  console.log('Installed apps:', apps);
});

// Manifest check करें:
fetch('/manifest.json')
  .then(r => r.json())
  .then(manifest => {
    console.log('Shortcuts:', manifest.shortcuts);
  });
```

---

## सफलता की पुष्टि / Success Verification

### ✅ शॉर्टकट सही तरीके से काम कर रहे हैं अगर:

```
1. ✅ ऐप आइकन लॉन्ग प्रेस पर मेनू दिखता है
2. ✅ 4 शॉर्टकट दिखाई देते हैं
3. ✅ हर शॉर्टकट का अपना colored icon है
4. ✅ शॉर्टकट क्लिक करने पर सही पेज खुलता है
5. ✅ Icons sharp और clear दिखते हैं
```

---

## संपर्क / Contact

अगर समस्या बनी रहती है:
1. ब्राउज़र console में errors check करें (F12)
2. Network tab में manifest.json और icon files check करें
3. Service worker status check करें

---

**अंतिम अपडेट / Last Updated**: 2026-01-17
**संस्करण / Version**: 2.4
**स्थिति / Status**: ✅ Production Ready
