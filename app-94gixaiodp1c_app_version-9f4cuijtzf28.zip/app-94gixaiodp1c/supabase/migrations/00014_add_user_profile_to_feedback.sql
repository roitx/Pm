-- Add user_profile column to feedback table to store complete user details
ALTER TABLE feedback ADD COLUMN IF NOT EXISTS user_profile JSONB;