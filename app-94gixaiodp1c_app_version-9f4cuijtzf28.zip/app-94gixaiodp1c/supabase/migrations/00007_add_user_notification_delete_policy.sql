-- Add RLS policy to allow users to delete their own notifications
CREATE POLICY "Users can delete their own notifications" ON user_notifications
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Add comment
COMMENT ON POLICY "Users can delete their own notifications" ON user_notifications IS 'Allows users to delete their own notification entries';