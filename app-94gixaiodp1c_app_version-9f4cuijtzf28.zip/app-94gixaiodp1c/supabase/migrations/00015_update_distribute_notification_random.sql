-- Drop existing function
DROP FUNCTION IF EXISTS distribute_notification();

-- Create updated function with random motivational quotes
CREATE OR REPLACE FUNCTION distribute_notification()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  motivational_quotes TEXT[] := ARRAY[
    'सफलता का रहस्य है - कभी हार न मानना। हर दिन एक नया अवसर है सीखने और बढ़ने का।',
    'मेहनत का फल मीठा होता है। आज की तैयारी कल की सफलता की नींव है।',
    'सपने वो नहीं जो नींद में आएं, सपने वो हैं जो नींद उड़ा दें।',
    'असफलता सफलता की पहली सीढ़ी है। हर गलती से सीखो और आगे बढ़ो।',
    'विश्वास रखो अपने आप पर। तुम वो सब कर सकते हो जो तुम सोच सकते हो।',
    'शिक्षा सबसे शक्तिशाली हथियार है जिससे तुम दुनिया बदल सकते हो।',
    'छोटे-छोटे कदम भी मंजिल तक पहुंचा देते हैं। रोज थोड़ा पढ़ो, बहुत आगे बढ़ो।',
    'कठिनाइयां तुम्हें मजबूत बनाती हैं। चुनौतियों का सामना करो और विजयी बनो।',
    'ज्ञान ही शक्ति है। जितना सीखोगे, उतने सशक्त बनोगे।',
    'आज का प्रयास कल की सफलता है। मेहनत कभी बेकार नहीं जाती।',
    'अपने लक्ष्य पर ध्यान केंद्रित करो। सफलता जरूर मिलेगी।',
    'हर दिन कुछ नया सीखो। ज्ञान की कोई सीमा नहीं है।',
    'धैर्य और मेहनत से हर मुश्किल आसान हो जाती है।',
    'तुम्हारी मेहनत तुम्हारी पहचान है। कभी हार मत मानो।',
    'सफलता उन्हीं को मिलती है जो कोशिश करते रहते हैं।'
  ];
  random_quote TEXT;
BEGIN
  -- Select a random quote
  random_quote := motivational_quotes[floor(random() * array_length(motivational_quotes, 1) + 1)];
  
  -- Insert notification for all users
  INSERT INTO notifications (title, message, type, created_at)
  VALUES ('आज का प्रेरक विचार 💫', random_quote, 'system', NOW());
END;
$$;