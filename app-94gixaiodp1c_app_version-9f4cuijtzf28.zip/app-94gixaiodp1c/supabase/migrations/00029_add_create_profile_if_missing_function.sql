
-- Create a function to manually create profile if missing
CREATE OR REPLACE FUNCTION public.create_profile_if_missing(user_id UUID, user_email TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
  user_count INTEGER;
  new_role public.user_role;
  profile_exists BOOLEAN;
BEGIN
  -- Check if profile already exists
  SELECT EXISTS(SELECT 1 FROM profiles WHERE id = user_id) INTO profile_exists;
  
  IF profile_exists THEN
    RETURN TRUE;
  END IF;
  
  -- Count existing profiles to determine role
  SELECT COUNT(*) INTO user_count FROM profiles;
  
  -- Determine role: first user is admin, others are regular users
  IF user_count = 0 THEN
    new_role := 'admin'::public.user_role;
  ELSE
    new_role := 'user'::public.user_role;
  END IF;
  
  -- Insert new profile
  INSERT INTO public.profiles (
    id, 
    email, 
    full_name, 
    role, 
    is_premium, 
    premium_expires_at
  )
  VALUES (
    user_id,
    user_email,
    '',
    new_role,
    CASE WHEN new_role = 'admin' THEN true ELSE false END,
    NULL
  );
  
  RETURN TRUE;
  
EXCEPTION WHEN OTHERS THEN
  RAISE WARNING 'Error in create_profile_if_missing: % %', SQLERRM, SQLSTATE;
  RETURN FALSE;
END;
$function$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.create_profile_if_missing(UUID, TEXT) TO authenticated;
