-- Fix admin stats function to count correctly
CREATE OR REPLACE FUNCTION get_admin_stats()
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result JSON;
BEGIN
  SELECT json_build_object(
    'total_students', (SELECT COUNT(*) FROM profiles WHERE role = 'user'),
    'total_content', (SELECT COUNT(*) FROM content),
    'total_mcq_questions', (SELECT COUNT(*) FROM mcq_questions),
    'total_notifications', (SELECT COUNT(*) FROM notifications)
  ) INTO result;
  
  RETURN result;
END;
$$;