-- Fix notification distribution to include sender (admin should also see notifications)
CREATE OR REPLACE FUNCTION distribute_notification_to_users()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert notification for ALL users (including sender/admin)
  INSERT INTO user_notifications (user_id, notification_id, read)
  SELECT 
    id,
    NEW.id,
    false
  FROM profiles
  ON CONFLICT (user_id, notification_id) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate trigger
DROP TRIGGER IF EXISTS on_notification_created ON notifications;
CREATE TRIGGER on_notification_created
  AFTER INSERT ON notifications
  FOR EACH ROW
  EXECUTE FUNCTION distribute_notification_to_users();

-- Backfill existing notifications to all users
INSERT INTO user_notifications (user_id, notification_id, read)
SELECT 
  p.id,
  n.id,
  false
FROM profiles p
CROSS JOIN notifications n
ON CONFLICT (user_id, notification_id) DO NOTHING;

COMMENT ON FUNCTION distribute_notification_to_users() IS 'Automatically creates user_notifications entries for ALL users (including admin) when a notification is created';