-- Allow anonymous users to read email from profiles when querying by phone number for login
-- This is needed for phone number login to work
CREATE POLICY "Allow phone lookup for login" ON profiles
  FOR SELECT TO anon
  USING (true);

-- Note: This policy allows reading profile data for login purposes
-- The actual authentication still requires correct password