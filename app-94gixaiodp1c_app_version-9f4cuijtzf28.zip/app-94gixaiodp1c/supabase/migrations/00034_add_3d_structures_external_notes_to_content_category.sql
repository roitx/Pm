-- Add 3d_structures and external_notes to content category enum
ALTER TYPE content_category ADD VALUE IF NOT EXISTS '3d_structures';
ALTER TYPE content_category ADD VALUE IF NOT EXISTS 'external_notes';

-- Add comment explaining the new categories
COMMENT ON TYPE content_category IS 'Content categories including notes, pyq, important_questions, reference_books, mind_maps, formulas, mcq_tests, iit_jee_questions, 3d_structures, external_notes';