const fs = require('fs');

// Create a simple data URL for the advanced book icon
const createIconSVG = (size) => {
  return `<svg width="${size}" height="${size}" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#3b82f6"/>
      <stop offset="50%" stop-color="#8b5cf6"/>
      <stop offset="100%" stop-color="#a855f7"/>
    </linearGradient>
    <linearGradient id="book" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="100%" stop-color="#f0f0f0"/>
    </linearGradient>
    <linearGradient id="accent" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fbbf24"/>
      <stop offset="100%" stop-color="#f59e0b"/>
    </linearGradient>
  </defs>
  
  <circle cx="256" cy="256" r="240" fill="url(#bg)"/>
  <circle cx="256" cy="256" r="230" fill="none" stroke="white" stroke-width="2" opacity="0.3"/>
  
  <g transform="translate(156, 156)">
    <path d="M 10 15 Q 10 10, 15 10 L 95 10 L 95 185 L 15 185 Q 10 185, 10 180 Z" 
          fill="url(#book)" stroke="#cbd5e1" stroke-width="2"/>
    <path d="M 105 10 L 185 10 Q 190 10, 190 15 L 190 180 Q 190 185, 185 185 L 105 185 Z" 
          fill="url(#book)" stroke="#cbd5e1" stroke-width="2"/>
    <rect x="98" y="10" width="4" height="175" fill="#94a3b8"/>
    
    <line x1="25" y1="35" x2="85" y2="35" stroke="#3b82f6" stroke-width="2" opacity="0.4"/>
    <line x1="25" y1="50" x2="85" y2="50" stroke="#3b82f6" stroke-width="2" opacity="0.4"/>
    <line x1="25" y1="65" x2="85" y2="65" stroke="#3b82f6" stroke-width="2" opacity="0.4"/>
    <line x1="25" y1="100" x2="85" y2="100" stroke="#8b5cf6" stroke-width="2" opacity="0.4"/>
    <line x1="25" y1="115" x2="85" y2="115" stroke="#8b5cf6" stroke-width="2" opacity="0.4"/>
    <line x1="25" y1="150" x2="85" y2="150" stroke="#a855f7" stroke-width="2" opacity="0.4"/>
    
    <line x1="115" y1="35" x2="175" y2="35" stroke="#3b82f6" stroke-width="2" opacity="0.4"/>
    <line x1="115" y1="50" x2="175" y2="50" stroke="#3b82f6" stroke-width="2" opacity="0.4"/>
    <line x1="115" y1="65" x2="175" y2="65" stroke="#3b82f6" stroke-width="2" opacity="0.4"/>
    <line x1="115" y1="100" x2="175" y2="100" stroke="#8b5cf6" stroke-width="2" opacity="0.4"/>
    <line x1="115" y1="115" x2="175" y2="115" stroke="#8b5cf6" stroke-width="2" opacity="0.4"/>
    <line x1="115" y1="150" x2="175" y2="150" stroke="#a855f7" stroke-width="2" opacity="0.4"/>
    
    <path d="M 95 10 L 95 80 L 100 70 L 105 80 L 105 10" fill="url(#accent)"/>
    <path d="M 15 15 Q 20 12, 30 15 L 30 30 Q 20 28, 15 30 Z" fill="white" opacity="0.4"/>
    <path d="M 170 15 Q 175 12, 185 15 L 185 30 Q 175 28, 170 30 Z" fill="white" opacity="0.4"/>
  </g>
  
  <circle cx="140" cy="140" r="3" fill="white" opacity="0.8"/>
  <circle cx="380" cy="160" r="2" fill="white" opacity="0.6"/>
  <circle cx="360" cy="380" r="3" fill="white" opacity="0.7"/>
  <circle cx="150" cy="370" r="2" fill="white" opacity="0.5"/>
</svg>`;
};

// Write SVG files for different sizes
fs.writeFileSync('public/icon-192.svg', createIconSVG(192));
fs.writeFileSync('public/icon-512.svg', createIconSVG(512));
fs.writeFileSync('public/favicon.svg', createIconSVG(32));
fs.writeFileSync('public/apple-touch-icon.svg', createIconSVG(180));

console.log('✅ Icon files created successfully!');
