import { lazy } from 'react';
import type { ReactNode } from 'react';

// Lazy load pages
const LoginPage = lazy(() => import('./pages/LoginPage'));
const SignupPage = lazy(() => import('./pages/SignupPage'));
const ForgotPasswordPage = lazy(() => import('./pages/ForgotPasswordPage'));
const DashboardPage = lazy(() => import('./pages/DashboardPage'));
const ContentBrowserPage = lazy(() => import('./pages/ContentBrowserPage'));
const ContentViewerPage = lazy(() => import('./pages/ContentViewerPage'));
const RecentlyViewedPage = lazy(() => import('./pages/RecentlyViewedPage'));
const DownloadsPage = lazy(() => import('./pages/DownloadsPage'));
const NotificationsPage = lazy(() => import('./pages/NotificationsPage'));
const ProfilePage = lazy(() => import('./pages/ProfilePage'));
const SettingsPage = lazy(() => import('./pages/SettingsPage'));
const InstallGuidePage = lazy(() => import('./pages/InstallGuidePage'));
const AIHelperPage = lazy(() => import('./pages/AIHelperPage'));
const LeaderboardPage = lazy(() => import('./pages/LeaderboardPage'));
const MCQTestPage = lazy(() => import('./pages/MCQTestPage'));
const TakeMCQTestPage = lazy(() => import('./pages/TakeMCQTestPage'));
const MCQTestResultPage = lazy(() => import('./pages/MCQTestResultPage'));
const MCQTestHistoryPage = lazy(() => import('./pages/MCQTestHistoryPage'));
const BookmarksPage = lazy(() => import('./pages/BookmarksPage'));
const StudyTimerPage = lazy(() => import('./pages/StudyTimerPage'));
const DoubtsPage = lazy(() => import('./pages/DoubtsPage'));
const AdminDashboardPage = lazy(() => import('./pages/admin/AdminDashboardPage'));
const AdminAboutSettingsPage = lazy(() => import('./pages/admin/AdminAboutSettingsPage'));
const AboutPage = lazy(() => import('./pages/AboutPage'));
const AdminContentUploadPage = lazy(() => import('./pages/admin/AdminContentUploadPage'));
const AdminMCQUploadPage = lazy(() => import('./pages/admin/AdminMCQUploadPage'));
const AdminStudentManagementPage = lazy(() => import('./pages/admin/AdminStudentManagementPage'));
const AdminNotificationsPage = lazy(() => import('./pages/admin/AdminNotificationsPage'));
const AdminContentManagementPage = lazy(() => import('./pages/admin/AdminContentManagementPage'));
const AdminIITJEEUploadPage = lazy(() => import('./pages/admin/AdminIITJEEUploadPage'));
const AdminDoubtsPage = lazy(() => import('./pages/admin/AdminDoubtsPage'));
const AdminAnalyticsPage = lazy(() => import('./pages/admin/AdminAnalyticsPage'));
const AdminPremiumFeaturesPage = lazy(() => import('./pages/admin/AdminPremiumFeaturesPage'));
const AdminAPKManagementPage = lazy(() => import('./pages/admin/AdminAPKManagementPage'));
const Admin3DStructuresUploadPage = lazy(() => import('./pages/admin/Admin3DStructuresUploadPage'));
const AdminExternalNotesUploadPage = lazy(() => import('./pages/admin/AdminExternalNotesUploadPage'));
const ScientificCalculatorPage = lazy(() => import('./pages/ScientificCalculatorPage'));
const MotivationsPage = lazy(() => import('./pages/MotivationsPage'));
const VideoLectures = lazy(() => import('./pages/VideoLectures'));
const StudyPlanner = lazy(() => import('./pages/StudyPlanner'));
const PerformanceAnalytics = lazy(() => import('./pages/PerformanceAnalytics'));
const ActivityPage = lazy(() => import('./pages/ActivityPage'));
const AppDownloadPage = lazy(() => import('./pages/AppDownloadPage'));
const ThreeDStructuresPage = lazy(() => import('./pages/ThreeDStructuresPage'));
const ExternalNotesPage = lazy(() => import('./pages/ExternalNotesPage'));
const NotFoundPage = lazy(() => import('./pages/NotFoundPage'));

// Uploader pages
const UploaderDashboardPage = lazy(() => import('./pages/uploader/UploaderDashboardPage'));
const UploaderContentUploadPage = lazy(() => import('./pages/uploader/UploaderContentUploadPage'));
const UploaderMCQUploadPage = lazy(() => import('./pages/uploader/UploaderMCQUploadPage'));
const UploaderIITJEEUploadPage = lazy(() => import('./pages/uploader/UploaderIITJEEUploadPage'));
const UploaderContentManagementPage = lazy(() => import('./pages/uploader/UploaderContentManagementPage'));
const UploaderChatPage = lazy(() => import('./pages/uploader/UploaderChatPage'));
const Uploader3DStructuresUploadPage = lazy(() => import('./pages/uploader/Uploader3DStructuresUploadPage'));
const UploaderExternalNotesUploadPage = lazy(() => import('./pages/uploader/UploaderExternalNotesUploadPage'));
const AdminUploaderChatPage = lazy(() => import('./pages/admin/AdminUploaderChatPage'));

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Login',
    path: '/login',
    element: <LoginPage />,
    visible: false,
  },
  {
    name: 'Signup',
    path: '/signup',
    element: <SignupPage />,
    visible: false,
  },
  {
    name: 'Forgot Password',
    path: '/forgot-password',
    element: <ForgotPasswordPage />,
    visible: false,
  },
  {
    name: 'Dashboard',
    path: '/dashboard',
    element: <DashboardPage />,
  },
  {
    name: 'Content Browser',
    path: '/content/:category',
    element: <ContentBrowserPage />,
    visible: false,
  },
  {
    name: 'Content Viewer',
    path: '/content/view/:id',
    element: <ContentViewerPage />,
    visible: false,
  },
  {
    name: 'Recently Viewed',
    path: '/recently-viewed',
    element: <RecentlyViewedPage />,
    visible: false,
  },
  {
    name: 'Downloads',
    path: '/downloads',
    element: <DownloadsPage />,
    visible: false,
  },
  {
    name: 'Notifications',
    path: '/notifications',
    element: <NotificationsPage />,
    visible: false,
  },
  {
    name: 'Profile',
    path: '/profile',
    element: <ProfilePage />,
    visible: false,
  },
  {
    name: 'Settings',
    path: '/settings',
    element: <SettingsPage />,
    visible: false,
  },
  {
    name: 'About',
    path: '/about',
    element: <AboutPage />,
    visible: false,
  },
  {
    name: 'ऐप डाउनलोड करें',
    path: '/app-download',
    element: <AppDownloadPage />,
    visible: false,
  },
  {
    name: '3D संरचनाएं',
    path: '/3d-structures',
    element: <ThreeDStructuresPage />,
    visible: false,
  },
  {
    name: 'बाहरी नोट्स',
    path: '/external-notes',
    element: <ExternalNotesPage />,
    visible: false,
  },
  {
    name: 'Install Guide',
    path: '/install-guide',
    element: <InstallGuidePage />,
    visible: false,
  },
  {
    name: 'AI Helper',
    path: '/ai-helper',
    element: <AIHelperPage />,
  },
  {
    name: 'Scientific Calculator',
    path: '/calculator',
    element: <ScientificCalculatorPage />,
  },
  // Removed: Motivations (backend only), Video Lectures (not needed), Study Planner (not needed), Performance Analytics (not needed)
  {
    name: 'Leaderboard',
    path: '/leaderboard',
    element: <LeaderboardPage />,
  },
  {
    name: 'गतिविधियाँ',
    path: '/activity',
    element: <ActivityPage />,
  },
  {
    name: 'प्रदर्शन विश्लेषण',
    path: '/performance',
    element: <PerformanceAnalytics />,
  },
  {
    name: 'बुकमार्क्स',
    path: '/bookmarks',
    element: <BookmarksPage />,
  },
  {
    name: 'स्टडी टाइमर',
    path: '/study-timer',
    element: <StudyTimerPage />,
  },
  {
    name: 'मेरे प्रश्न',
    path: '/doubts',
    element: <DoubtsPage />,
  },
  {
    name: 'MCQ Test',
    path: '/mcq-test',
    element: <MCQTestPage />,
  },
  {
    name: 'Take MCQ Test',
    path: '/mcq-test/take',
    element: <TakeMCQTestPage />,
    visible: false,
  },
  {
    name: 'MCQ Test Result',
    path: '/mcq-test/result',
    element: <MCQTestResultPage />,
    visible: false,
  },
  {
    name: 'MCQ Test History',
    path: '/mcq-test/history',
    element: <MCQTestHistoryPage />,
    visible: false,
  },
  {
    name: 'Admin',
    path: '/admin',
    element: <AdminDashboardPage />,
    visible: false,
  },
  {
    name: 'Admin Upload',
    path: '/admin/upload',
    element: <AdminContentUploadPage />,
    visible: false,
  },
  {
    name: 'Admin MCQ Upload',
    path: '/admin/mcq-upload',
    element: <AdminMCQUploadPage />,
    visible: false,
  },
  {
    name: 'Admin Students',
    path: '/admin/students',
    element: <AdminStudentManagementPage />,
    visible: false,
  },
  {
    name: 'Admin Notifications',
    path: '/admin/notifications',
    element: <AdminNotificationsPage />,
    visible: false,
  },
  {
    name: 'Admin Content Management',
    path: '/admin/content-management',
    element: <AdminContentManagementPage />,
    visible: false,
  },
  {
    name: 'Admin IIT-JEE Upload',
    path: '/admin/iitjee-upload',
    element: <AdminIITJEEUploadPage />,
    visible: false,
  },
  {
    name: 'Admin Doubts',
    path: '/admin/doubts',
    element: <AdminDoubtsPage />,
    visible: false,
  },
  {
    name: 'Admin Analytics',
    path: '/admin/analytics',
    element: <AdminAnalyticsPage />,
    visible: false,
  },
  {
    name: 'Admin Premium Features',
    path: '/admin/premium-features',
    element: <AdminPremiumFeaturesPage />,
    visible: false,
  },
  {
    name: 'Admin About Settings',
    path: '/admin/about-settings',
    element: <AdminAboutSettingsPage />,
    visible: false,
  },
  {
    name: 'Admin APK Management',
    path: '/admin/apk-management',
    element: <AdminAPKManagementPage />,
    visible: false,
  },
  {
    name: 'Admin 3D Structures Upload',
    path: '/admin/3d-structures-upload',
    element: <Admin3DStructuresUploadPage />,
    visible: false,
  },
  {
    name: 'Admin External Notes Upload',
    path: '/admin/external-notes-upload',
    element: <AdminExternalNotesUploadPage />,
    visible: false,
  },
  {
    name: 'Admin Chat',
    path: '/admin/chat',
    element: <AdminUploaderChatPage />,
    visible: false,
  },
  {
    name: 'Uploader Dashboard',
    path: '/uploader',
    element: <UploaderDashboardPage />,
    visible: false,
  },
  {
    name: 'Uploader Upload',
    path: '/uploader/upload',
    element: <UploaderContentUploadPage />,
    visible: false,
  },
  {
    name: 'Uploader MCQ Upload',
    path: '/uploader/mcq-upload',
    element: <UploaderMCQUploadPage />,
    visible: false,
  },
  {
    name: 'Uploader IIT-JEE Upload',
    path: '/uploader/iitjee-upload',
    element: <UploaderIITJEEUploadPage />,
    visible: false,
  },
  {
    name: 'Uploader Content Management',
    path: '/uploader/content-management',
    element: <UploaderContentManagementPage />,
    visible: false,
  },
  {
    name: 'Uploader 3D Structures Upload',
    path: '/uploader/3d-structures-upload',
    element: <Uploader3DStructuresUploadPage />,
    visible: false,
  },
  {
    name: 'Uploader External Notes Upload',
    path: '/uploader/external-notes-upload',
    element: <UploaderExternalNotesUploadPage />,
    visible: false,
  },
  {
    name: 'Uploader Chat',
    path: '/uploader/chat',
    element: <UploaderChatPage />,
    visible: false,
  },
  {
    name: 'Not Found',
    path: '*',
    element: <NotFoundPage />,
    visible: false,
  },
];

export default routes;
