import { useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';

/**
 * प्रीमियम थीम हुक - प्रीमियम यूजर्स के लिए विशेष थीम लागू करता है
 */
export function usePremiumTheme() {
  const { profile } = useAuth();
  const isPremium = profile?.is_premium || false;

  useEffect(() => {
    const root = document.documentElement;

    if (isPremium) {
      // प्रीमियम थीम क्लास जोड़ें
      root.classList.add('premium-theme');
    } else {
      // प्रीमियम थीम क्लास हटाएं
      root.classList.remove('premium-theme');
    }

    // Cleanup
    return () => {
      root.classList.remove('premium-theme');
    };
  }, [isPremium]);

  return { isPremium };
}
