import { Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { ThemeProvider } from 'next-themes';
import IntersectObserver from '@/components/common/IntersectObserver';
import { AuthProvider } from '@/contexts/AuthContext';
import { LanguageProvider } from '@/contexts/LanguageContext';
import { RouteGuard } from '@/components/common/RouteGuard';
import { Header } from '@/components/layouts/Header';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Toaster } from '@/components/ui/toaster';
import { PWAInstallPrompt } from '@/components/ui/PWAInstallPrompt';
import { BookIcon } from '@/components/ui/BookIcon';
import routes from './routes';

// Loading component with colorful book icon and animated dots
function LoadingFallback() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <div className="flex flex-col items-center space-y-6">
        {/* Smaller colorful book icon */}
        <BookIcon className="w-24 h-24" animate={true} />
        
        {/* Three animated colored dots */}
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }}></div>
          <div className="w-3 h-3 rounded-full bg-secondary animate-bounce" style={{ animationDelay: '150ms' }}></div>
          <div className="w-3 h-3 rounded-full bg-accent animate-bounce" style={{ animationDelay: '300ms' }}></div>
        </div>
      </div>
    </div>
  );
}

// Layout wrapper component
function LayoutWrapper({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const noLayoutPaths = ['/login', '/signup', '/forgot-password'];
  const isNoLayout = noLayoutPaths.includes(location.pathname);

  if (isNoLayout) {
    return <>{children}</>;
  }

  return (
    <>
      <Header />
      <MainLayout>{children}</MainLayout>
    </>
  );
}

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
      <LanguageProvider>
        <Router>
          <AuthProvider>
            <RouteGuard>
              <IntersectObserver />
              <LayoutWrapper>
                <Suspense fallback={<LoadingFallback />}>
                  <Routes>
                    {routes.map((route, index) => (
                      <Route key={index} path={route.path} element={route.element} />
                    ))}
                    <Route path="/" element={<Navigate to="/dashboard" replace />} />
                  </Routes>
                </Suspense>
              </LayoutWrapper>
              <Toaster />
              <PWAInstallPrompt />
            </RouteGuard>
          </AuthProvider>
        </Router>
      </LanguageProvider>
    </ThemeProvider>
  );
}

export default App;
