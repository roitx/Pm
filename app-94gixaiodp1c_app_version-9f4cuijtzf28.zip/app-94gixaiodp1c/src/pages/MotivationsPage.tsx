import * as React from 'react';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  Sparkles, 
  Heart, 
  Share2, 
  Copy, 
  Search,
  RefreshCw,
  TrendingUp,
  Star,
  Zap
} from 'lucide-react';
import { supabase } from '@/db/supabase';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface Motivation {
  id: string;
  quote: string;
  author?: string;
  category: string;
  likes: number;
  created_at: string;
}

export default function MotivationsPage() {
  const [motivations, setMotivations] = useState<Motivation[]>([]);
  const [filteredMotivations, setFilteredMotivations] = useState<Motivation[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('सभी');
  const [likedQuotes, setLikedQuotes] = useState<Set<string>>(new Set());
  const { toast } = useToast();
  const { user } = useAuth();

  const categories = ['सभी', 'सफलता', 'शिक्षा', 'प्रेरणा', 'जीवन', 'मेहनत', 'सपने'];

  useEffect(() => {
    loadMotivations();
    loadLikedQuotes();
  }, []);

  useEffect(() => {
    filterMotivations();
  }, [searchQuery, selectedCategory, motivations]);

  const loadMotivations = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('motivations')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setMotivations(data || []);
    } catch (error) {
      console.error('Error loading motivations:', error);
      toast({
        title: 'त्रुटि',
        description: 'प्रेरक विचार लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const loadLikedQuotes = () => {
    try {
      const saved = localStorage.getItem('liked-quotes');
      if (saved) {
        setLikedQuotes(new Set(JSON.parse(saved)));
      }
    } catch (error) {
      console.error('Error loading liked quotes:', error);
    }
  };

  const filterMotivations = () => {
    let filtered = motivations;

    // Filter by category
    if (selectedCategory !== 'सभी') {
      filtered = filtered.filter(m => m.category === selectedCategory);
    }

    // Filter by search query
    if (searchQuery.trim()) {
      filtered = filtered.filter(m => 
        m.quote.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.author?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    setFilteredMotivations(filtered);
  };

  const handleLike = async (motivationId: string) => {
    try {
      const newLikedQuotes = new Set(likedQuotes);
      const isLiked = likedQuotes.has(motivationId);

      if (isLiked) {
        newLikedQuotes.delete(motivationId);
      } else {
        newLikedQuotes.add(motivationId);
      }

      setLikedQuotes(newLikedQuotes);
      localStorage.setItem('liked-quotes', JSON.stringify(Array.from(newLikedQuotes)));

      // Update likes count in database
      const motivation = motivations.find(m => m.id === motivationId);
      if (motivation) {
        const newLikes = isLiked ? motivation.likes - 1 : motivation.likes + 1;
        await supabase
          .from('motivations')
          .update({ likes: newLikes })
          .eq('id', motivationId);

        setMotivations(prev => 
          prev.map(m => m.id === motivationId ? { ...m, likes: newLikes } : m)
        );
      }
    } catch (error) {
      console.error('Error liking quote:', error);
    }
  };

  const handleCopy = (quote: string) => {
    navigator.clipboard.writeText(quote);
    toast({
      title: 'सफलता',
      description: 'प्रेरक विचार कॉपी हो गया',
    });
  };

  const handleShare = async (quote: string) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'प्रेरक विचार',
          text: quote,
        });
      } catch (error) {
        console.error('Error sharing:', error);
      }
    } else {
      handleCopy(quote);
    }
  };

  const getRandomQuote = () => {
    if (filteredMotivations.length > 0) {
      const randomIndex = Math.floor(Math.random() * filteredMotivations.length);
      const element = document.getElementById(`quote-${filteredMotivations[randomIndex].id}`);
      element?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 p-4 xl:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <Card className="glass-card border-primary/20">
          <CardHeader>
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-gradient-to-br from-primary to-secondary rounded-xl">
                  <Sparkles className="h-6 w-6 text-white" />
                </div>
                <div>
                  <CardTitle className="text-2xl xl:text-3xl gradient-text">
                    प्रेरक विचार
                  </CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">
                    {filteredMotivations.length} प्रेरणादायक उद्धरण
                  </p>
                </div>
              </div>
              <Button
                onClick={getRandomQuote}
                className="hover-glow"
                size="sm"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                रैंडम विचार
              </Button>
            </div>
          </CardHeader>
        </Card>

        {/* Search and Filters */}
        <Card className="glass-card">
          <CardContent className="pt-6 space-y-4">
            {/* Search Bar */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="प्रेरक विचार खोजें..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Category Filters */}
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Badge
                  key={category}
                  variant={selectedCategory === category ? 'default' : 'outline'}
                  className="cursor-pointer hover:scale-105 transition-transform"
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Motivations Grid */}
        {loading ? (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="glass-card">
                <CardContent className="pt-6 space-y-3">
                  <Skeleton className="h-20 w-full bg-muted" />
                  <Skeleton className="h-4 w-1/3 bg-muted" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredMotivations.length === 0 ? (
          <Card className="glass-card">
            <CardContent className="pt-6 text-center py-12">
              <Sparkles className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">
                कोई प्रेरक विचार नहीं मिला
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            {filteredMotivations.map((motivation, index) => (
              <Card
                key={motivation.id}
                id={`quote-${motivation.id}`}
                className="glass-card hover:shadow-lg transition-all duration-300 hover:scale-[1.02]"
                style={{
                  animationDelay: `${index * 0.05}s`,
                  animation: 'fadeInUp 0.5s ease-out forwards',
                }}
              >
                <CardContent className="pt-6 space-y-4">
                  {/* Quote */}
                  <div className="relative">
                    <Zap className="absolute -top-2 -left-2 h-6 w-6 text-primary/20" />
                    <p className="text-lg font-medium leading-relaxed pl-6">
                      {motivation.quote}
                    </p>
                  </div>

                  {/* Author & Category */}
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      {motivation.author && (
                        <span className="text-sm text-muted-foreground">
                          — {motivation.author}
                        </span>
                      )}
                      <Badge variant="secondary" className="text-xs">
                        {motivation.category}
                      </Badge>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-between pt-2 border-t border-border/50">
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleLike(motivation.id)}
                        className={likedQuotes.has(motivation.id) ? 'text-red-500' : ''}
                      >
                        <Heart
                          className={`h-4 w-4 mr-1 ${
                            likedQuotes.has(motivation.id) ? 'fill-current' : ''
                          }`}
                        />
                        {motivation.likes}
                      </Button>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleCopy(motivation.quote)}
                        title="कॉपी करें"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleShare(motivation.quote)}
                        title="शेयर करें"
                      >
                        <Share2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Stats Footer */}
        {!loading && filteredMotivations.length > 0 && (
          <Card className="glass-card border-primary/20">
            <CardContent className="pt-6">
              <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 text-center">
                <div>
                  <div className="flex items-center justify-center gap-2 mb-1">
                    <Star className="h-4 w-4 text-primary" />
                    <p className="text-2xl font-bold">{motivations.length}</p>
                  </div>
                  <p className="text-xs text-muted-foreground">कुल विचार</p>
                </div>
                <div>
                  <div className="flex items-center justify-center gap-2 mb-1">
                    <Heart className="h-4 w-4 text-red-500" />
                    <p className="text-2xl font-bold">{likedQuotes.size}</p>
                  </div>
                  <p className="text-xs text-muted-foreground">पसंदीदा</p>
                </div>
                <div>
                  <div className="flex items-center justify-center gap-2 mb-1">
                    <TrendingUp className="h-4 w-4 text-green-500" />
                    <p className="text-2xl font-bold">{categories.length - 1}</p>
                  </div>
                  <p className="text-xs text-muted-foreground">श्रेणियां</p>
                </div>
                <div>
                  <div className="flex items-center justify-center gap-2 mb-1">
                    <Sparkles className="h-4 w-4 text-primary" />
                    <p className="text-2xl font-bold">{filteredMotivations.length}</p>
                  </div>
                  <p className="text-xs text-muted-foreground">दिखाए गए</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
