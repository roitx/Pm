import * as React from 'react';
import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import { 
  saveAIChatMessage, 
  getAIChatHistory, 
  clearAIChatHistory, 
  getDailyUsageStats,
  createChatSession,
  getChatSessions,
  updateChatSession,
  deleteChatSession
} from '@/db/api';
import { MarkdownMessage } from '@/components/ui/MarkdownMessage';
import { EmojiPicker } from '@/components/ui/EmojiPicker';
import { 
  Loader2, 
  Send, 
  Brain, 
  User, 
  Sparkles, 
  BookOpen, 
  Lightbulb, 
  Zap, 
  Copy, 
  ThumbsUp,
  Check,
  Trash2,
  RotateCcw,
  Square,
  Crown,
  Lock,
  Plus,
  MessageSquarePlus,
  History,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import type { ChatMessage, ChatSession } from '@/types/types';
import { checkFeatureAccess, trackFeatureUsage } from '@/db/api';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';

// Load chat history from database
const loadChatHistoryFromDB = async (userId: string, sessionId?: string): Promise<ChatMessage[]> => {
  try {
    const history = await getAIChatHistory(userId, sessionId);
    const messages: ChatMessage[] = [];
    
    history.reverse().forEach((item: any) => {
      messages.push({
        id: `${item.id}-user`,
        role: 'user',
        content: item.message,
        timestamp: new Date(item.created_at),
      });
      messages.push({
        id: `${item.id}-model`,
        role: 'model',
        content: item.response,
        timestamp: new Date(item.created_at),
      });
    });
    
    return messages;
  } catch (error) {
    console.error('Error loading chat history:', error);
    return [];
  }
};

// Typing effect component with adaptive speed
function TypingText({ 
  text, 
  onComplete 
}: { 
  text: string; 
  onComplete?: () => void;
}) {
  const [displayedText, setDisplayedText] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);
  
  // Adaptive speed based on text length
  const speed = text.length < 100 ? 5 : text.length < 300 ? 8 : 10;

  useEffect(() => {
    if (currentIndex < text.length) {
      const timeout = setTimeout(() => {
        setDisplayedText(prev => prev + text[currentIndex]);
        setCurrentIndex(prev => prev + 1);
      }, speed);
      return () => clearTimeout(timeout);
    } else if (onComplete && currentIndex === text.length) {
      onComplete();
    }
  }, [currentIndex, text, speed, onComplete]);

  return <span className="whitespace-pre-wrap">{displayedText}</span>;
}

export default function AIHelperPage() {
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const [hasAccess, setHasAccess] = useState<boolean | null>(null);
  const [checkingAccess, setCheckingAccess] = useState(true);
  const [aiUsage, setAiUsage] = useState<{ count: number; limit: number } | null>(null);
  const [showNewChatDialog, setShowNewChatDialog] = useState(false);
  const [showLimitDialog, setShowLimitDialog] = useState(false);
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [showHistorySheet, setShowHistorySheet] = useState(false);
  const MESSAGE_LIMIT = 50;
  
  const initialMessage: ChatMessage = {
    id: 'welcome',
    role: 'model',
    content: 'नमस्ते! मैं PM Roit AI Assistant हूं। 🎓\n\nमैं आपकी मदद कर सकता हूं:\n\n📚 **विषय सहायता:**\n• 📐 Physics - गति, बल, ऊर्जा, विद्युत, चुंबकत्व\n• 🧪 Chemistry - रासायनिक अभिक्रियाएं, तत्व, यौगिक, रासायनिक बंधन\n• 🔢 Mathematics - बीजगणित, ज्यामिति, त्रिकोणमिति, कलन\n• 🧬 Biology - कोशिका, आनुवंशिकी, पारिस्थितिकी\n\n💡 **मैं क्या कर सकता हूं:**\n• समस्याओं को step-by-step हल करना\n• अवधारणाओं को सरल भाषा में समझाना\n• सूत्रों और सिद्धांतों की व्याख्या\n• परीक्षा की तैयारी में मदद\n• अभ्यास प्रश्न और उदाहरण\n\nकृपया अपना सवाल पूछें और मैं विस्तृत उत्तर दूंगा। 😊',
    timestamp: new Date(),
  };

  // Load chat history from database on mount
  const [messages, setMessages] = useState<ChatMessage[]>([initialMessage]);
  const [loadingHistory, setLoadingHistory] = useState(true);
  
  // Load AI usage stats
  const loadAiUsage = async () => {
    if (!user) return;
    try {
      const usage = await getDailyUsageStats(user.id, 'ai_helper');
      const isPremium = profile?.is_premium || false;
      setAiUsage({
        count: usage?.count || 0,
        limit: isPremium ? 999 : 50, // 50 for free users, unlimited for premium
      });
    } catch (error) {
      console.error('Error loading AI usage:', error);
    }
  };
  
  // Check feature access on mount
  useEffect(() => {
    const checkAccess = async () => {
      if (!user) {
        setCheckingAccess(false);
        return;
      }
      
      try {
        const access = await checkFeatureAccess(user.id, 'ai_helper');
        setHasAccess(access);
        await loadAiUsage();
      } catch (error) {
        console.error('Error checking feature access:', error);
        setHasAccess(false);
      } finally {
        setCheckingAccess(false);
      }
    };
    
    checkAccess();
  }, [user]);

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [typingMessageId, setTypingMessageId] = useState<string | null>(null);
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);
  const [likedMessages, setLikedMessages] = useState<Set<string>>(new Set());
  const [isTypingComplete, setIsTypingComplete] = useState(true);
  const [lastUserMessage, setLastUserMessage] = useState<string>(''); // For regenerate
  const [abortController, setAbortController] = useState<AbortController | null>(null); // For stopping generation
  const scrollRef = useRef<HTMLDivElement>(null);

  // Quick prompts for common questions
  const quickPrompts = [
    { icon: '📐', text: 'न्यूटन के गति के नियम समझाएं', category: 'Physics' },
    { icon: '🧪', text: 'रासायनिक बंधन क्या है?', category: 'Chemistry' },
    { icon: '🔢', text: 'द्विघात समीकरण कैसे हल करें?', category: 'Mathematics' },
    { icon: '🧬', text: 'DNA की संरचना समझाएं', category: 'Biology' },
    { icon: '⚡', text: 'विद्युत धारा और वोल्टेज में अंतर', category: 'Physics' },
    { icon: '🔬', text: 'अम्ल और क्षार में अंतर', category: 'Chemistry' },
  ];

  // Load chat history from database on mount
  useEffect(() => {
    if (user) {
      loadHistory();
      loadSessions();
    } else {
      setLoadingHistory(false);
    }
  }, [user]);

  const loadSessions = async () => {
    if (!user) return;
    
    try {
      const sessions = await getChatSessions(user.id);
      setChatSessions(sessions);
    } catch (error) {
      console.error('Error loading sessions:', error);
    }
  };

  const loadHistory = async (sessionId?: string) => {
    if (!user) return;
    
    try {
      setLoadingHistory(true);
      const history = await loadChatHistoryFromDB(user.id, sessionId);
      
      if (history.length > 0) {
        setMessages(history);
      } else {
        setMessages([initialMessage]);
      }
    } catch (error) {
      console.error('Error loading history:', error);
      setMessages([initialMessage]);
    } finally {
      setLoadingHistory(false);
    }
  };

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (scrollRef.current) {
      const scrollElement = scrollRef.current;
      // Use requestAnimationFrame for smoother scrolling
      requestAnimationFrame(() => {
        scrollElement.scrollTop = scrollElement.scrollHeight;
      });
    }
  }, [messages, loading]);

  // Also scroll during typing animation - more aggressive
  useEffect(() => {
    if (typingMessageId && scrollRef.current) {
      const interval = setInterval(() => {
        if (scrollRef.current) {
          // Force scroll to bottom during typing
          scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
      }, 100); // Faster interval for smoother scrolling
      return () => clearInterval(interval);
    }
  }, [typingMessageId]);

  const handleSend = async () => {
    // Prevent sending if loading or typing animation is in progress
    if (!input.trim() || loading) return;
    
    // Check access before sending
    if (!hasAccess) {
      toast({
        title: 'प्रीमियम फीचर',
        description: 'यह फीचर प्रीमियम उपयोगकर्ताओं के लिए है',
      });
      return;
    }

    // Check message limit for non-premium users
    const isPremium = profile?.is_premium || false;
    if (!isPremium && messages.length >= MESSAGE_LIMIT) {
      setShowLimitDialog(true);
      return;
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input.trim(),
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setLastUserMessage(input.trim()); // Save for regenerate
    setInput('');
    setLoading(true);
    setIsTypingComplete(false);

    // Create abort controller for this request
    const controller = new AbortController();
    setAbortController(controller);
    
    // Track feature usage
    if (user) {
      trackFeatureUsage(user.id, 'ai_helper').catch(console.error);
    }

    try {
      const apiMessages = messages
        .map(msg => ({
          role: msg.role,
          content: msg.content,
        }));

      apiMessages.push({
        role: 'user',
        content: userMessage.content,
      });

      const { data, error } = await supabase.functions.invoke('ai-helper', {
        body: { 
          messages: apiMessages,
          systemPrompt: `आप एक विशेषज्ञ शिक्षक हैं जो भारतीय छात्रों को Physics, Chemistry, Mathematics और Biology पढ़ाते हैं। 

आपकी जिम्मेदारियां:
1. हमेशा हिंदी में उत्तर दें (जब तक अंग्रेजी में न पूछा जाए)
2. जटिल अवधारणाओं को सरल भाषा में समझाएं
3. Step-by-step समाधान प्रदान करें
4. सूत्रों को सरल text format में लिखें (LaTeX नहीं)
5. वास्तविक जीवन के उदाहरण दें
6. छात्रों को प्रोत्साहित करें और सकारात्मक रहें
7. गणितीय समीकरणों को Unicode या सरल text में लिखें
8. जहां जरूरी हो, चित्र या आरेख का वर्णन करें

महत्वपूर्ण: सूत्र लिखते समय LaTeX ($, $$, \\frac, आदि) का उपयोग न करें। 
इसके बजाय सरल text format का उपयोग करें:
- a² + b² = c² (LaTeX नहीं)
- F = ma (सरल और स्पष्ट)
- v = u + at (आसान पढ़ने योग्य)

उत्तर की संरचना:
- संक्षिप्त परिचय
- विस्तृत व्याख्या
- उदाहरण (यदि लागू हो)
- महत्वपूर्ण बिंदु
- अभ्यास सुझाव (यदि उपयुक्त हो)

हमेशा शैक्षिक और सहायक बने रहें।`
        },
      });

      console.log('AI Helper Response:', { data, error });

      if (error) {
        let errorMsg = 'AI सेवा में त्रुटि';
        try {
          if (error?.context?.text) {
            const errorText = await error.context.text();
            console.error('AI Error context:', errorText);
            errorMsg = errorText;
          } else if (error?.message) {
            console.error('AI Error message:', error.message);
            errorMsg = error.message;
          }
        } catch (e) {
          console.error('Error reading error message:', e);
        }
        console.error('AI Helper error:', errorMsg, error);
        
        // सुधारित त्रुटि संदेश - Improved error message with retry suggestion
        throw new Error('⚠️ AI सेवा अस्थायी रूप से अनुपलब्ध है।\n\n💡 सुझाव:\n• कुछ सेकंड प्रतीक्षा करें और पुनः प्रयास करें\n• अपना इंटरनेट कनेक्शन जांचें\n• यदि समस्या बनी रहे, तो बाद में प्रयास करें');
      }

      // बेहतर रिस्पांस हैंडलिंग - Better response handling
      if (!data) {
        console.error('No data received from AI');
        throw new Error('❌ AI से कोई प्रतिक्रिया नहीं मिली।\n\nकृपया पुनः प्रयास करें। यदि समस्या बनी रहे, तो कुछ देर बाद प्रयास करें।');
      }

      if (!data.response || data.response.trim() === '') {
        console.error('Invalid AI response:', data);
        throw new Error('⚠️ AI प्रतिक्रिया खाली है।\n\nकृपया अपना प्रश्न फिर से पूछें या प्रश्न को अलग तरीके से लिखें।');
      }

      if (data?.response) {
        // Clean up LaTeX formatting if any slipped through
        let cleanedResponse = data.response
          .replace(/\$\$/g, '')  // Remove $$ 
          .replace(/\$/g, '')    // Remove $
          .replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '($1/$2)')  // Convert \frac{a}{b} to (a/b)
          .replace(/\\times/g, '×')
          .replace(/\\div/g, '÷')
          .replace(/\\pm/g, '±')
          .replace(/\\sqrt\{([^}]+)\}/g, '√($1)')
          .replace(/\\\(/g, '')  // Remove \(
          .replace(/\\\)/g, '')  // Remove \)
          .replace(/\\\[/g, '')  // Remove \[
          .replace(/\\\]/g, ''); // Remove \]

        const aiMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          role: 'model',
          content: cleanedResponse,
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, aiMessage]);
        setTypingMessageId(aiMessage.id);
        
        // Track feature usage and reload stats
        if (user) {
          try {
            await trackFeatureUsage(user.id, 'ai_helper');
            await loadAiUsage(); // Reload usage stats
          } catch (trackError) {
            console.error('Error tracking usage:', trackError);
          }
        }
        
        // Save to database for persistence
        if (user) {
          try {
            await saveAIChatMessage(user.id, userMessage.content, cleanedResponse, currentSessionId || undefined);
            
            // Update session timestamp
            if (currentSessionId) {
              await updateChatSession(currentSessionId, { updated_at: new Date().toISOString() });
            }
          } catch (dbError) {
            console.error('Error saving to database:', dbError);
            // Continue even if database save fails
          }
        }
        
        // Scroll to show the new AI message at bottom after a brief delay
        setTimeout(() => {
          if (scrollRef.current) {
            // Scroll to bottom to show the latest AI response
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
          }
        }, 100);
      } else {
        throw new Error('कोई उत्तर नहीं मिला');
      }
    } catch (error: any) {
      if (error.name === 'AbortError') {
        toast({
          title: 'रोक दिया गया',
          description: 'उत्तर जनरेशन रोक दी गई',
        });
      } else {
        console.error('Error calling AI:', error);
        toast({
          title: 'त्रुटि',
          description: error instanceof Error ? error.message : 'AI से संपर्क करने में विफल',
          variant: 'destructive',
        });

        const errorMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          role: 'model',
          content: 'क्षमा करें, मुझे आपके सवाल का जवाब देने में समस्या हो रही है। कृपया पुनः प्रयास करें।',
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, errorMessage]);
        setIsTypingComplete(true);
      }
    } finally {
      setLoading(false);
      setAbortController(null);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey && !loading) {
      e.preventDefault();
      handleSend();
    }
  };

  // Stop generation
  const handleStopGeneration = () => {
    if (abortController) {
      abortController.abort();
      setLoading(false);
      setIsTypingComplete(true);
      setAbortController(null);
      toast({
        title: 'रोक दिया गया',
        description: 'उत्तर जनरेशन रोक दी गई',
      });
    }
  };

  const handleCopy = async (content: string, messageId: string) => {
    try {
      await navigator.clipboard.writeText(content);
      setCopiedMessageId(messageId);
      toast({
        title: 'कॉपी हो गया',
        description: 'संदेश क्लिपबोर्ड में कॉपी कर दिया गया है',
      });
      setTimeout(() => setCopiedMessageId(null), 2000);
    } catch (error) {
      toast({
        title: 'त्रुटि',
        description: 'कॉपी करने में विफल',
        variant: 'destructive',
      });
    }
  };

  const handleLike = (messageId: string) => {
    setLikedMessages(prev => {
      const newSet = new Set(prev);
      if (newSet.has(messageId)) {
        newSet.delete(messageId);
        toast({
          title: 'लाइक हटा दिया',
          description: 'आपने इस उत्तर को अनलाइक कर दिया',
        });
      } else {
        newSet.add(messageId);
        toast({
          title: 'लाइक किया',
          description: 'धन्यवाद! आपकी प्रतिक्रिया हमारे लिए महत्वपूर्ण है',
        });
      }
      return newSet;
    });
  };

  // Delete individual message
  const handleDeleteMessage = (messageId: string) => {
    if (messageId === 'welcome') {
      toast({
        title: 'नहीं हटाया जा सकता',
        description: 'स्वागत संदेश नहीं हटाया जा सकता',
        variant: 'destructive',
      });
      return;
    }
    setMessages(prev => prev.filter(msg => msg.id !== messageId));
    toast({
      title: 'हटा दिया गया',
      description: 'संदेश हटा दिया गया है',
    });
  };

  // Clear all chat history
  const handleClearChat = async () => {
    if (!user) return;
    
    try {
      await clearAIChatHistory(user.id, currentSessionId || undefined);
      setMessages([initialMessage]);
      setLastUserMessage('');
      toast({
        title: 'चैट साफ हो गई',
        description: 'सभी संदेश हटा दिए गए हैं',
      });
    } catch (error) {
      console.error('Error clearing chat:', error);
      toast({
        title: 'त्रुटि',
        description: 'हिस्ट्री साफ करने में समस्या',
        variant: 'destructive',
      });
    }
  };

  // Handle new chat
  const handleNewChat = async () => {
    if (!user) return;
    
    try {
      // Create new session
      const newSession = await createChatSession(user.id, 'नई बातचीत');
      
      if (newSession) {
        setCurrentSessionId(newSession.id);
        setMessages([initialMessage]);
        setLastUserMessage('');
        await loadSessions(); // Reload sessions list
        
        toast({
          title: 'नई चैट शुरू की',
          description: 'आप एक नई बातचीत शुरू कर रहे हैं',
        });
      }
    } catch (error) {
      console.error('Error creating new chat:', error);
      toast({
        title: 'त्रुटि',
        description: 'नई चैट बनाने में समस्या',
        variant: 'destructive',
      });
    }
    setShowNewChatDialog(false);
  };

  // Switch to a different chat session
  const handleSwitchSession = async (sessionId: string) => {
    setCurrentSessionId(sessionId);
    await loadHistory(sessionId);
    setShowHistorySheet(false);
    toast({
      title: 'चैट बदली गई',
      description: 'पुरानी बातचीत लोड हो गई है',
    });
  };

  // Delete a chat session
  const handleDeleteSession = async (sessionId: string) => {
    if (!user) return;
    
    try {
      await deleteChatSession(sessionId);
      
      // If deleting current session, switch to no session
      if (sessionId === currentSessionId) {
        setCurrentSessionId(null);
        await loadHistory();
      }
      
      await loadSessions();
      
      toast({
        title: 'चैट हटा दी गई',
        description: 'बातचीत सफलतापूर्वक हटा दी गई है',
      });
    } catch (error) {
      console.error('Error deleting session:', error);
      toast({
        title: 'त्रुटि',
        description: 'चैट हटाने में समस्या',
        variant: 'destructive',
      });
    }
  };

  // Regenerate last response
  const handleRegenerate = async () => {
    if (!lastUserMessage || loading) return;

    // Remove last AI response
    setMessages(prev => {
      const filtered = [...prev];
      // Remove last model message
      for (let i = filtered.length - 1; i >= 0; i--) {
        if (filtered[i].role === 'model') {
          filtered.splice(i, 1);
          break;
        }
      }
      return filtered;
    });

    setLoading(true);
    setIsTypingComplete(false);

    try {
      const apiMessages = messages
        .filter(msg => msg.role !== 'model' || msg.id !== messages[messages.length - 1]?.id)
        .map(msg => ({
          role: msg.role,
          content: msg.content,
        }));

      const { data, error } = await supabase.functions.invoke('ai-helper', {
        body: { 
          messages: apiMessages,
          systemPrompt: `आप एक विशेषज्ञ शिक्षक हैं जो भारतीय छात्रों को Physics, Chemistry, Mathematics और Biology पढ़ाते हैं। 

आपकी जिम्मेदारियां:
1. हमेशा हिंदी में उत्तर दें (जब तक अंग्रेजी में न पूछा जाए)
2. जटिल अवधारणाओं को सरल भाषा में समझाएं
3. Step-by-step समाधान प्रदान करें
4. सूत्रों और सिद्धांतों की स्पष्ट व्याख्या करें
5. वास्तविक जीवन के उदाहरण दें
6. छात्रों को प्रोत्साहित करें और सकारात्मक रहें
7. गणितीय समीकरणों को स्पष्ट रूप से लिखें
8. जहां जरूरी हो, चित्र या आरेख का वर्णन करें

उत्तर की संरचना:
- संक्षिप्त परिचय
- विस्तृत व्याख्या
- उदाहरण (यदि लागू हो)
- महत्वपूर्ण बिंदु
- अभ्यास सुझाव (यदि उपयुक्त हो)

हमेशा शैक्षिक और सहायक बने रहें।`
        },
      });

      if (error) {
        let errorMsg = 'AI सेवा में त्रुटि';
        try {
          if (error?.context?.text) {
            errorMsg = await error.context.text();
          } else if (error?.message) {
            errorMsg = error.message;
          }
        } catch (e) {
          console.error('Error reading error message:', e);
        }
        console.error('AI Helper regenerate error:', errorMsg);
        throw new Error(errorMsg);
      }

      if (data?.response) {
        const aiMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          role: 'model',
          content: data.response,
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, aiMessage]);
        setTypingMessageId(aiMessage.id);
      }
    } catch (error) {
      console.error('Error regenerating:', error);
      toast({
        title: 'त्रुटि',
        description: 'पुनः उत्पन्न करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleTypingComplete = () => {
    setTypingMessageId(null);
    setIsTypingComplete(true);
  };

  const handleQuickPrompt = (promptText: string) => {
    setInput(promptText);
  };

  return (
    <div className="container mx-auto p-2 sm:p-4 xl:p-6 max-w-5xl h-[calc(100vh-5rem)] sm:h-[calc(100vh-6rem)] xl:h-[calc(100vh-8rem)]">
      {checkingAccess ? (
        <div className="flex items-center justify-center h-full">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : !hasAccess ? (
        <Card className="glass-card h-full flex flex-col items-center justify-center p-8">
          <div className="text-center space-y-6 max-w-md">
            <div className="relative inline-block">
              <div className="absolute inset-0 bg-gradient-to-br from-amber-500 to-yellow-500 rounded-full blur-xl opacity-50" />
              <div className="relative w-24 h-24 rounded-full bg-gradient-to-br from-amber-500 to-yellow-500 flex items-center justify-center">
                <Crown className="h-12 w-12 text-white" />
              </div>
            </div>
            
            <div className="space-y-2">
              <h2 className="text-xl font-semibold">प्रीमियम फीचर</h2>
              <p className="text-sm text-muted-foreground">
                यह फीचर प्रीमियम उपयोगकर्ताओं के लिए उपलब्ध है
              </p>
            </div>
            
            <Alert className="border-muted">
              <Lock className="h-4 w-4" />
              <AlertTitle className="text-sm">प्रीमियम लाभ</AlertTitle>
              <AlertDescription className="text-xs mt-1">
                <ul className="list-disc list-inside space-y-0.5">
                  <li>असीमित AI सहायक</li>
                  <li>असीमित MCQ टेस्ट</li>
                  <li>असीमित डाउनलोड</li>
                </ul>
              </AlertDescription>
            </Alert>
            
            <p className="text-xs text-muted-foreground">
              अधिक जानकारी के लिए एडमिन से संपर्क करें
            </p>
          </div>
        </Card>
      ) : (
      <Card className="glass-card h-full flex flex-col overflow-hidden border-2 border-primary/20 shadow-2xl">
        {/* AI Usage Alert */}
        {aiUsage && !profile?.is_premium && (
          <Alert className={`m-4 mb-0 text-xs ${aiUsage.count >= aiUsage.limit * 0.8 ? "border-destructive" : "border-muted"}`}>
            <Crown className="h-3 w-3" />
            <AlertTitle className="text-xs">दैनिक सीमा</AlertTitle>
            <AlertDescription className="text-xs">
              {aiUsage.count}/{aiUsage.limit} संदेश उपयोग किए गए
              {aiUsage.count >= aiUsage.limit && " - सीमा पूर्ण"}
            </AlertDescription>
          </Alert>
        )}
        
        {/* Gemini-style Header with Sidebar Toggle */}
        <CardHeader className="border-b border-border/50 bg-gradient-to-r from-primary/5 via-secondary/5 to-primary/5 shrink-0">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 flex-1">
              {/* Sidebar Toggle Button (Hamburger Menu) */}
              {chatSessions.length > 0 && (
                <Sheet open={showHistorySheet} onOpenChange={setShowHistorySheet}>
                  <SheetTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-10 w-10 shrink-0"
                      title="चैट देखें"
                    >
                      <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                      </svg>
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-80 overflow-y-auto p-0">
                    <div className="p-4 border-b">
                      <SheetTitle className="text-lg">Roitx AI</SheetTitle>
                      <SheetDescription className="text-xs mt-1">
                        आपकी बातचीत
                      </SheetDescription>
                    </div>
                    
                    {/* New Chat Button - Prominent */}
                    <div className="p-4 border-b">
                      <Button
                        onClick={() => {
                          setShowNewChatDialog(true);
                          setShowHistorySheet(false);
                        }}
                        className="w-full justify-start gap-2 h-11"
                        variant="outline"
                      >
                        <MessageSquarePlus className="h-5 w-5" />
                        <span>नई चैट</span>
                      </Button>
                    </div>

                    {/* Recent Chats Section */}
                    <div className="p-4">
                      <h3 className="text-sm font-medium text-muted-foreground mb-3">हाल की चैट</h3>
                      <div className="space-y-2">
                        {chatSessions.map((session) => (
                          <div
                            key={session.id}
                            className={`p-3 rounded-lg border cursor-pointer transition-all hover:bg-accent group ${
                              session.id === currentSessionId ? 'bg-accent border-primary' : 'border-border'
                            }`}
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div 
                                className="flex-1 min-w-0"
                                onClick={() => handleSwitchSession(session.id)}
                              >
                                <p className="text-sm font-medium truncate">{session.title}</p>
                                <p className="text-xs text-muted-foreground mt-1">
                                  {new Date(session.updated_at).toLocaleDateString('hi-IN', {
                                    day: 'numeric',
                                    month: 'short'
                                  })}
                                </p>
                              </div>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive hover:bg-destructive/10 shrink-0"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteSession(session.id);
                                }}
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        ))}
                        {chatSessions.length === 0 && (
                          <div className="text-center py-8 text-sm text-muted-foreground">
                            कोई पुरानी चैट नहीं है
                          </div>
                        )}
                      </div>
                    </div>
                  </SheetContent>
                </Sheet>
              )}
              
              {/* App Title */}
              <div className="flex items-center gap-2">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary to-secondary rounded-full blur-md opacity-50 animate-pulse" />
                  <Avatar className="h-10 w-10 border-2 border-primary relative">
                    <AvatarFallback className="bg-gradient-to-br from-primary to-secondary">
                      <Brain className="h-5 w-5 text-white" />
                    </AvatarFallback>
                  </Avatar>
                </div>
                <div>
                  <CardTitle className="text-lg xl:text-xl flex items-center gap-2">
                    Roitx AI
                    <Sparkles className="h-4 w-4 text-primary animate-pulse" />
                  </CardTitle>
                  <CardDescription className="text-xs hidden sm:block">
                    {loading ? 'टाइप कर रहा है...' : !isTypingComplete ? 'उत्तर लिख रहा है...' : 'ऑनलाइन'}
                  </CardDescription>
                </div>
              </div>
            </div>
            
            {/* Right Side Actions */}
            <div className="flex items-center gap-2">
              {!profile?.is_premium && messages.length > 1 && (
                <Badge variant="outline" className="text-xs hidden sm:inline-flex">
                  {messages.length}/{MESSAGE_LIMIT}
                </Badge>
              )}
              {messages.length > 1 && (
                <>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowNewChatDialog(true)}
                    className="h-9 w-9"
                    title="नई चैट शुरू करें"
                  >
                    <Plus className="h-5 w-5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleClearChat}
                    className="h-9 w-9 text-destructive hover:text-destructive hover:bg-destructive/10"
                    title="सभी चैट साफ करें"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </>
              )}
            </div>
          </div>
        </CardHeader>

        {/* Messages Area */}
        <CardContent 
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-0 scroll-smooth bg-background"
        >
          <div className="max-w-3xl mx-auto">
            {messages.map((message, index) => (
              <div
                key={message.id}
                className={`py-4 xl:py-6 px-3 xl:px-4 ${
                  message.role === 'user' ? 'bg-background' : 'bg-muted/30'
                } animate-fade-in border-b border-border/30`}
              >
                <div className="flex gap-3 xl:gap-4 max-w-full">
                  {/* Avatar */}
                  {message.role === 'model' ? (
                    <Avatar className="h-8 w-8 xl:h-9 xl:w-9 shrink-0 border border-primary/30">
                      <AvatarFallback className="bg-gradient-to-br from-primary/20 to-secondary/20">
                        <Brain className="h-4 w-4 xl:h-5 xl:w-5 text-primary" />
                      </AvatarFallback>
                    </Avatar>
                  ) : (
                    <Avatar className="h-8 w-8 xl:h-9 xl:w-9 shrink-0 border border-primary/30">
                      <AvatarImage src={profile?.profile_photo_url || undefined} />
                      <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white text-xs xl:text-sm">
                        {profile?.full_name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || 'U'}
                      </AvatarFallback>
                    </Avatar>
                  )}

                  {/* Message Content */}
                  <div className="flex-1 min-w-0 space-y-2">
                    {/* Message Text */}
                    <div className="prose prose-sm xl:prose-base max-w-none">
                      {message.role === 'model' && typingMessageId === message.id ? (
                        <TypingText 
                          text={message.content} 
                          onComplete={handleTypingComplete}
                        />
                      ) : message.role === 'model' ? (
                        <MarkdownMessage content={message.content} />
                      ) : (
                        <div className="text-sm xl:text-base leading-relaxed text-foreground whitespace-pre-wrap">
                          {message.content}
                        </div>
                      )}
                    </div>

                    {/* Action Buttons for AI messages */}
                    {message.role === 'model' && message.id !== 'welcome' && (
                      <div className="flex items-center gap-1 pt-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2 hover:bg-muted"
                          onClick={() => handleCopy(message.content, message.id)}
                          disabled={!isTypingComplete && typingMessageId === message.id}
                        >
                          {copiedMessageId === message.id ? (
                            <>
                              <Check className="h-3.5 w-3.5 mr-1.5 text-green-500" />
                              <span className="text-xs">कॉपी किया</span>
                            </>
                          ) : (
                            <>
                              <Copy className="h-3.5 w-3.5 mr-1.5" />
                              <span className="text-xs">कॉपी करें</span>
                            </>
                          )}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className={`h-8 px-2 hover:bg-muted ${likedMessages.has(message.id) ? 'text-primary' : ''}`}
                          onClick={() => handleLike(message.id)}
                          disabled={!isTypingComplete && typingMessageId === message.id}
                        >
                          <ThumbsUp className={`h-3.5 w-3.5 mr-1.5 ${likedMessages.has(message.id) ? 'fill-current' : ''}`} />
                          <span className="text-xs">{likedMessages.has(message.id) ? 'पसंद किया' : 'पसंद करें'}</span>
                        </Button>
                        {index === messages.length - 1 && message.role === 'model' && lastUserMessage && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 px-2 hover:bg-muted"
                            onClick={handleRegenerate}
                            disabled={loading || !isTypingComplete}
                          >
                            <RotateCcw className="h-3.5 w-3.5 mr-1.5" />
                            <span className="text-xs">पुनः उत्पन्न करें</span>
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {loading && (
              <div className="py-4 xl:py-6 px-3 xl:px-4 bg-muted/30 border-b border-border/30 animate-fade-in">
                <div className="flex gap-3 xl:gap-4 max-w-full">
                  <Avatar className="h-8 w-8 xl:h-9 xl:w-9 shrink-0 border border-primary/30">
                    <AvatarFallback className="bg-gradient-to-br from-primary/20 to-secondary/20">
                      <Brain className="h-4 w-4 xl:h-5 xl:w-5 text-primary animate-pulse" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex items-center gap-2 pt-1">
                    <Loader2 className="h-4 w-4 animate-spin text-primary" />
                    <span className="text-sm text-muted-foreground">सोच रहा हूं...</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>

        {/* Quick Prompts - Show when chat is empty or only welcome message */}
        {messages.length === 1 && (
          <div className="px-3 xl:px-4 pb-3 shrink-0 border-t border-border/30 pt-3 bg-muted/20">
            <p className="text-xs xl:text-sm font-semibold text-foreground mb-2 xl:mb-3 flex items-center gap-2">
              <Lightbulb className="h-4 w-4 text-primary" />
              त्वरित प्रश्न:
            </p>
            <div className="grid grid-cols-2 xl:grid-cols-3 gap-2">
              {quickPrompts.map((prompt, idx) => (
                <Button
                  key={idx}
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuickPrompt(prompt.text)}
                  className="text-xs justify-start hover:bg-primary/10 hover:border-primary/40 hover:shadow-sm transition-all h-auto py-2 px-2.5 xl:px-3"
                  disabled={loading || !isTypingComplete}
                >
                  <span className="mr-1.5 xl:mr-2 text-base">{prompt.icon}</span>
                  <span className="text-left line-clamp-2 text-xs">{prompt.text}</span>
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Input Area */}
        <div className="border-t border-border/50 p-3 xl:p-4 bg-gradient-to-t from-muted/30 to-background/50 backdrop-blur-sm shrink-0">
          <div className="flex gap-2 items-end">
            <div className="flex-1 flex gap-2 items-end">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="अपना सवाल यहां लिखें... (Enter से भेजें, Shift+Enter से नई लाइन)"
                className="min-h-[56px] xl:min-h-[60px] max-h-[120px] resize-none text-sm xl:text-base border-border/60 focus:border-primary/60 shadow-sm flex-1"
                disabled={false} // Allow typing even when loading
              />
              <EmojiPicker onEmojiSelect={(emoji) => setInput(prev => prev + emoji)} />
            </div>
            <div className="flex flex-col gap-2">
              {loading ? (
                <Button
                  onClick={handleStopGeneration}
                  size="icon"
                  variant="destructive"
                  className="h-[56px] xl:h-[60px] w-11 xl:w-12 shrink-0 shadow-md hover:shadow-lg transition-all"
                  title="रोकें"
                >
                  <Square className="h-4 w-4 xl:h-5 xl:w-5" />
                </Button>
              ) : (
                <Button
                  onClick={handleSend}
                  disabled={!input.trim()}
                  size="icon"
                  className="h-[56px] xl:h-[60px] w-11 xl:w-12 shrink-0 bg-gradient-to-r from-primary to-secondary hover:opacity-90 shadow-md hover:shadow-lg transition-all disabled:opacity-50"
                  title="भेजें"
                >
                  <Send className="h-4 w-4 xl:h-5 xl:w-5" />
                </Button>
              )}
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2 text-center">
            AI गलतियां कर सकता है। महत्वपूर्ण जानकारी की जांच करें।
          </p>
        </div>
      </Card>
      )}

      {/* New Chat Confirmation Dialog */}
      <Dialog open={showNewChatDialog} onOpenChange={setShowNewChatDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MessageSquarePlus className="h-5 w-5 text-primary" />
              नई चैट शुरू करें?
            </DialogTitle>
            <DialogDescription>
              क्या आप वाकई नई चैट शुरू करना चाहते हैं? यह वर्तमान चैट को साफ कर देगा।
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowNewChatDialog(false)}>
              रद्द करें
            </Button>
            <Button onClick={handleNewChat} className="gap-2">
              <Plus className="h-4 w-4" />
              नई चैट शुरू करें
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Message Limit Dialog */}
      <Dialog open={showLimitDialog} onOpenChange={setShowLimitDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <Lock className="h-4 w-4 text-primary" />
              संदेश सीमा पूर्ण
            </DialogTitle>
            <DialogDescription className="space-y-2 pt-2 text-sm">
              <p>आपने {MESSAGE_LIMIT} संदेशों की सीमा पूर्ण कर ली है।</p>
              <div className="bg-muted/50 p-3 rounded-lg space-y-1.5">
                <p className="text-xs font-semibold text-foreground flex items-center gap-1.5">
                  <Crown className="h-3 w-3 text-primary" />
                  प्रीमियम लाभ:
                </p>
                <ul className="text-xs space-y-0.5 ml-5 list-disc">
                  <li>असीमित AI संदेश</li>
                  <li>असीमित डाउनलोड</li>
                  <li>असीमित MCQ टेस्ट</li>
                </ul>
              </div>
              <p className="text-xs">या आप नई चैट शुरू कर सकते हैं।</p>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 flex-col sm:flex-row">
            <Button variant="outline" size="sm" onClick={() => setShowLimitDialog(false)}>
              रद्द करें
            </Button>
            <Button variant="secondary" size="sm" onClick={handleNewChat} className="gap-2">
              <MessageSquarePlus className="h-4 w-4" />
              नई चैट शुरू करें
            </Button>
            <Button size="sm" onClick={() => window.location.href = '/premium'} className="gap-2">
              <Crown className="h-4 w-4" />
              प्रीमियम खरीदें
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
