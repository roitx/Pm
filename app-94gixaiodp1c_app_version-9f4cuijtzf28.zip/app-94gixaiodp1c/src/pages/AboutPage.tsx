import * as React from 'react';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import { Mail, Phone, MessageCircle, Youtube, Instagram, Facebook, Twitter, Send, Loader2, Info } from 'lucide-react';
import { motion } from 'framer-motion';

interface AboutSettings {
  app_name: string;
  app_description: string;
  contact_email: string;
  contact_phone: string;
  whatsapp: string;
  youtube_url: string;
  instagram_url: string;
  facebook_url?: string;
  twitter_url?: string;
}

export default function AboutPage() {
  const [settings, setSettings] = useState<AboutSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [feedbackName, setFeedbackName] = useState('');
  const [feedbackEmail, setFeedbackEmail] = useState('');
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [sending, setSending] = useState(false);
  const { toast } = useToast();
  const { profile, user } = useAuth();

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('admin_settings')
        .select('setting_value')
        .eq('setting_key', 'about_page')
        .single();

      if (error) throw error;
      setSettings(data.setting_value as AboutSettings);
    } catch (error) {
      console.error('Error loading settings:', error);
      toast({
        title: 'त्रुटि',
        description: 'सेटिंग्स लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!feedbackName || !feedbackEmail || !feedbackMessage) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया सभी फ़ील्ड भरें',
        variant: 'destructive',
      });
      return;
    }

    setSending(true);
    try {
      // Send feedback via Edge Function with user profile details
      const { data, error } = await supabase.functions.invoke('send-feedback-email', {
        body: {
          name: feedbackName,
          email: feedbackEmail,
          message: feedbackMessage,
          // Include user profile details if logged in
          userProfile: profile ? {
            id: user?.id,
            full_name: profile.full_name,
            email: user?.email,
            profile_photo_url: profile.profile_photo_url,
            school_name: profile.school_name,
            student_class: profile.student_class,
            phone: profile.phone,
            city: profile.city,
            pincode: profile.pincode,
          } : null,
        },
      });

      if (error) {
        console.error('Feedback error:', error);
        throw error;
      }

      toast({
        title: '✅ सफलता',
        description: data?.message || 'आपकी प्रतिक्रिया सफलतापूर्वक भेज दी गई है। हम जल्द ही आपसे संपर्क करेंगे।',
      });

      setFeedbackName('');
      setFeedbackEmail('');
      setFeedbackMessage('');
    } catch (error: any) {
      console.error('Error sending feedback:', error);
      
      // बेहतर त्रुटि संदेश - Better error message
      let errorMessage = '⚠️ फीडबैक भेजने में समस्या हुई।\n\n';
      
      if (error?.message?.includes('fetch')) {
        errorMessage += '💡 कृपया अपना इंटरनेट कनेक्शन जांचें और पुनः प्रयास करें।';
      } else {
        errorMessage += '💡 कृपया सीधे ईमेल या व्हाट्सएप के माध्यम से संपर्क करें।';
      }
      
      toast({
        title: 'सूचना',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setSending(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 xl:p-6 max-w-5xl space-y-6">
      {/* App Info Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="glass-card bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <Info className="h-10 w-10 text-white" />
              </div>
            </div>
            <CardTitle className="text-2xl xl:text-3xl gradient-text">
              {settings?.app_name || 'PM - Roit Study Hub'}
            </CardTitle>
            <CardDescription className="text-base xl:text-lg mt-2">
              {settings?.app_description || 'कक्षा 8-12 के छात्रों के लिए संपूर्ण अध्ययन सामग्री'}
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-muted-foreground">
              हम छात्रों को उच्च गुणवत्ता की अध्ययन सामग्री प्रदान करने के लिए प्रतिबद्ध हैं।
              हमारा लक्ष्य शिक्षा को सभी के लिए सुलभ और प्रभावी बनाना है।
            </p>
          </CardContent>
        </Card>
      </motion.div>

      {/* Contact Options */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-xl xl:text-2xl">📞 हमसे संपर्क करें</CardTitle>
            <CardDescription>हम आपकी सहायता के लिए हमेशा तैयार हैं</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Email */}
              <a
                href={`mailto:${settings?.contact_email}`}
                className="flex items-center gap-4 p-4 rounded-lg bg-gradient-to-br from-red-500/10 to-red-600/10 hover:from-red-500/20 hover:to-red-600/20 transition-all border border-red-500/20 hover-glow"
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-red-500 to-red-600 flex items-center justify-center flex-shrink-0">
                  <Mail className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold">ईमेल</h3>
                  <p className="text-sm text-muted-foreground">{settings?.contact_email}</p>
                </div>
              </a>

              {/* Phone */}
              <a
                href={`tel:${settings?.contact_phone}`}
                className="flex items-center gap-4 p-4 rounded-lg bg-gradient-to-br from-blue-500/10 to-blue-600/10 hover:from-blue-500/20 hover:to-blue-600/20 transition-all border border-blue-500/20 hover-glow"
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center flex-shrink-0">
                  <Phone className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold">फ़ोन</h3>
                  <p className="text-sm text-muted-foreground">{settings?.contact_phone}</p>
                </div>
              </a>

              {/* WhatsApp */}
              <a
                href={`https://wa.me/${settings?.whatsapp?.replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 p-4 rounded-lg bg-gradient-to-br from-green-500/10 to-green-600/10 hover:from-green-500/20 hover:to-green-600/20 transition-all border border-green-500/20 hover-glow"
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center flex-shrink-0">
                  <MessageCircle className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold">व्हाट्सएप</h3>
                  <p className="text-sm text-muted-foreground">{settings?.whatsapp}</p>
                </div>
              </a>

              {/* YouTube */}
              <a
                href={settings?.youtube_url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 p-4 rounded-lg bg-gradient-to-br from-red-600/10 to-red-700/10 hover:from-red-600/20 hover:to-red-700/20 transition-all border border-red-600/20 hover-glow"
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-red-600 to-red-700 flex items-center justify-center flex-shrink-0">
                  <Youtube className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold">YouTube</h3>
                  <p className="text-sm text-muted-foreground">हमारे वीडियो देखें</p>
                </div>
              </a>

              {/* Instagram */}
              <a
                href={settings?.instagram_url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 p-4 rounded-lg bg-gradient-to-br from-pink-500/10 to-purple-600/10 hover:from-pink-500/20 hover:to-purple-600/20 transition-all border border-pink-500/20 hover-glow"
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                  <Instagram className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold">Instagram</h3>
                  <p className="text-sm text-muted-foreground">हमें फॉलो करें</p>
                </div>
              </a>

              {/* Facebook */}
              {settings?.facebook_url && (
                <a
                  href={settings.facebook_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 p-4 rounded-lg bg-gradient-to-br from-blue-600/10 to-blue-700/10 hover:from-blue-600/20 hover:to-blue-700/20 transition-all border border-blue-600/20 hover-glow"
                >
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center flex-shrink-0">
                    <Facebook className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Facebook</h3>
                    <p className="text-sm text-muted-foreground">हमारे पेज पर जाएं</p>
                  </div>
                </a>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Feedback Form */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-xl xl:text-2xl">💬 प्रतिक्रिया दें</CardTitle>
            <CardDescription>हमें अपनी राय बताएं और हमें बेहतर बनाने में मदद करें</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleFeedbackSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">नाम</Label>
                <Input
                  id="name"
                  value={feedbackName}
                  onChange={(e) => setFeedbackName(e.target.value)}
                  placeholder="अपना नाम दर्ज करें"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">ईमेल</Label>
                <Input
                  id="email"
                  type="email"
                  value={feedbackEmail}
                  onChange={(e) => setFeedbackEmail(e.target.value)}
                  placeholder="your@email.com"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">संदेश</Label>
                <Textarea
                  id="message"
                  value={feedbackMessage}
                  onChange={(e) => setFeedbackMessage(e.target.value)}
                  placeholder="अपनी प्रतिक्रिया या सुझाव यहां लिखें..."
                  className="min-h-[120px]"
                  required
                />
              </div>

              <Button
                type="submit"
                disabled={sending}
                className="w-full bg-gradient-to-r from-primary to-secondary"
              >
                {sending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    भेजा जा रहा है...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    प्रतिक्रिया भेजें
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
