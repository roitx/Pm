import * as React from 'react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { getAllProfiles, updateUserRole, deleteUserProfile, bulkDeleteUserProfiles } from '@/db/api';
import { Search, Users, Shield, User as UserIcon, Lock, Trash2, Loader2, Crown, Upload, Mail, Phone, Calendar } from 'lucide-react';
import { formatDate } from '@/lib/constants';
import type { Profile } from '@/types/types';

const ADMIN_PASSWORD = '12/07/2010';

export default function AdminStudentManagementPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [students, setStudents] = useState<Profile[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [showPasswordDialog, setShowPasswordDialog] = useState(true);
  const [selectedStudents, setSelectedStudents] = useState<string[]>([]);
  const [studentToDelete, setStudentToDelete] = useState<Profile | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [bulkDeleting, setBulkDeleting] = useState(false);
  const [showBulkDeleteDialog, setShowBulkDeleteDialog] = useState(false);

  const handlePasswordSubmit = () => {
    if (passwordInput === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      setShowPasswordDialog(false);
      toast({
        title: 'सफल',
        description: 'पासवर्ड सही है। छात्र प्रबंधन खुल रहा है।',
      });
    } else {
      toast({
        title: 'त्रुटि',
        description: 'गलत पासवर्ड। कृपया पुनः प्रयास करें।',
        variant: 'destructive',
      });
      setPasswordInput('');
    }
  };

  const handlePasswordKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handlePasswordSubmit();
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      loadStudents();
    }
  }, [isAuthenticated]);

  useEffect(() => {
    if (searchQuery) {
      const filtered = students.filter(student =>
        student.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student.phone?.includes(searchQuery)
      );
      setFilteredStudents(filtered);
    } else {
      setFilteredStudents(students);
    }
  }, [searchQuery, students]);

  const loadStudents = async () => {
    setLoading(true);
    try {
      const data = await getAllProfiles();
      setStudents(data);
      setFilteredStudents(data);
    } catch (error) {
      console.error('Error loading students:', error);
      toast({
        title: 'त्रुटि',
        description: 'छात्र लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRoleChange = async (userId: string, newRole: 'user' | 'admin' | 'uploader') => {
    try {
      await updateUserRole(userId, newRole);
      toast({
        title: 'सफलता',
        description: 'भूमिका सफलतापूर्वक अपडेट की गई',
      });
      loadStudents();
    } catch (error) {
      console.error('Error updating role:', error);
      toast({
        title: 'त्रुटि',
        description: 'भूमिका अपडेट करने में विफल',
        variant: 'destructive',
      });
    }
  };

  const handleDeleteStudent = async () => {
    if (!studentToDelete) return;

    setDeleting(true);
    try {
      await deleteUserProfile(studentToDelete.id);
      toast({
        title: 'सफलता',
        description: 'छात्र सफलतापूर्वक हटाया गया',
      });
      setSelectedStudents(selectedStudents.filter(id => id !== studentToDelete.id));
      loadStudents();
    } catch (error) {
      console.error('Error deleting student:', error);
      toast({
        title: 'त्रुटि',
        description: 'छात्र हटाने में विफल',
        variant: 'destructive',
      });
    } finally {
      setDeleting(false);
      setStudentToDelete(null);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedStudents.length === 0) return;

    setBulkDeleting(true);
    try {
      await bulkDeleteUserProfiles(selectedStudents);
      toast({
        title: 'सफलता',
        description: `${selectedStudents.length} छात्र सफलतापूर्वक हटाए गए`,
      });
      setSelectedStudents([]);
      loadStudents();
    } catch (error) {
      console.error('Error bulk deleting students:', error);
      toast({
        title: 'त्रुटि',
        description: 'छात्रों को हटाने में विफल',
        variant: 'destructive',
      });
    } finally {
      setBulkDeleting(false);
      setShowBulkDeleteDialog(false);
    }
  };

  const toggleSelectAll = () => {
    if (selectedStudents.length === filteredStudents.length) {
      setSelectedStudents([]);
    } else {
      setSelectedStudents(filteredStudents.map(s => s.id));
    }
  };

  const toggleSelectStudent = (studentId: string) => {
    if (selectedStudents.includes(studentId)) {
      setSelectedStudents(selectedStudents.filter(id => id !== studentId));
    } else {
      setSelectedStudents([...selectedStudents, studentId]);
    }
  };

  const stats = {
    total: students.length,
    admins: students.filter(s => s.role === 'admin').length,
    users: students.filter(s => s.role === 'user').length,
    uploaders: students.filter(s => s.role === 'uploader').length,
  };

  // Password Dialog
  if (!isAuthenticated) {
    return (
      <Dialog open={showPasswordDialog} onOpenChange={() => {}}>
        <DialogContent className="sm:max-w-md" onPointerDownOutside={(e) => e.preventDefault()}>
          <DialogHeader>
            <div className="flex items-center justify-center mb-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <Lock className="h-8 w-8 text-white" />
              </div>
            </div>
            <DialogTitle className="text-center text-xl">छात्र प्रबंधन सुरक्षा</DialogTitle>
            <DialogDescription className="text-center">
              छात्र डेटा देखने के लिए पासवर्ड दर्ज करें
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Input
                type="password"
                placeholder="पासवर्ड दर्ज करें"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                onKeyPress={handlePasswordKeyPress}
                className="text-center text-lg"
                autoFocus
              />
            </div>
            <Button
              onClick={handlePasswordSubmit}
              className="w-full bg-gradient-to-r from-primary to-secondary"
              size="lg"
            >
              <Lock className="mr-2 h-4 w-4" />
              सत्यापित करें
            </Button>
            <Button
              onClick={() => navigate('/admin')}
              variant="outline"
              className="w-full"
            >
              वापस जाएं
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (loading) {
    return (
      <div className="container mx-auto p-4 xl:p-6 space-y-4">
        <Skeleton className="h-12 w-full bg-muted" />
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
          <Skeleton className="h-24 bg-muted" />
          <Skeleton className="h-24 bg-muted" />
          <Skeleton className="h-24 bg-muted" />
        </div>
        <Skeleton className="h-96 bg-muted" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 xl:p-6 space-y-6">
      {/* Header */}
      <Card className="glass-card">
        <CardHeader>
          <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4">
            <div>
              <CardTitle className="text-xl xl:text-2xl gradient-text">छात्र प्रबंधन</CardTitle>
              <CardDescription className="text-base mt-2">
                पंजीकृत उपयोगकर्ताओं को देखें और प्रबंधित करें
              </CardDescription>
            </div>
            <Button variant="outline" onClick={() => navigate('/admin')}>
              वापस जाएं
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <Card className="glass-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">कुल उपयोगकर्ता</p>
                <p className="text-3xl font-bold text-primary">{stats.total}</p>
              </div>
              <Users className="h-12 w-12 text-primary opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">एडमिन</p>
                <p className="text-3xl font-bold text-secondary">{stats.admins}</p>
              </div>
              <Shield className="h-12 w-12 text-secondary opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">अपलोडर</p>
                <p className="text-3xl font-bold text-primary">{stats.uploaders}</p>
              </div>
              <Upload className="h-12 w-12 text-primary opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">छात्र</p>
                <p className="text-3xl font-bold text-accent">{stats.users}</p>
              </div>
              <UserIcon className="h-12 w-12 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card className="glass-card">
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="नाम, ईमेल या फोन से खोजें..."
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Students List */}
      <Card className="glass-card">
        <CardHeader>
          <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
            <CardTitle>उपयोगकर्ता सूची ({filteredStudents.length})</CardTitle>
            {selectedStudents.length > 0 && (
              <div className="flex items-center gap-3">
                <Badge variant="secondary" className="text-base px-3 py-1">
                  {selectedStudents.length} चयनित
                </Badge>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => setShowBulkDeleteDialog(true)}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  चयनित हटाएं
                </Button>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {filteredStudents.length === 0 ? (
            <div className="text-center py-12">
              <Users className="h-16 w-16 mx-auto text-muted-foreground opacity-50 mb-4" />
              <p className="text-muted-foreground">कोई उपयोगकर्ता नहीं मिला</p>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-3 mb-4 pb-3 border-b">
                <Checkbox
                  checked={selectedStudents.length === filteredStudents.length}
                  onCheckedChange={toggleSelectAll}
                  id="select-all"
                />
                <label htmlFor="select-all" className="text-sm font-medium cursor-pointer">
                  सभी चुनें
                </label>
              </div>
              <div className="space-y-3">
                {filteredStudents.map((student) => (
                  <Card key={student.id} className="border-2 hover:border-primary/50 transition-all">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <Checkbox
                          checked={selectedStudents.includes(student.id)}
                          onCheckedChange={() => toggleSelectStudent(student.id)}
                          className="mt-1"
                        />
                        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 flex-1 min-w-0">
                          <div className="flex items-start gap-4 min-w-0 flex-1">
                            <Avatar className="h-12 w-12 shrink-0">
                              <AvatarImage src={student.profile_photo_url || undefined} />
                              <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white font-bold text-lg">
                                {student.full_name?.[0]?.toUpperCase() || student.email?.[0]?.toUpperCase() || '?'}
                              </AvatarFallback>
                            </Avatar>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <h3 className="font-semibold text-base xl:text-lg break-words">
                                  {student.full_name || 'नाम नहीं'}
                                </h3>
                                <Badge variant={student.role === 'admin' ? 'default' : student.role === 'uploader' ? 'outline' : 'secondary'} className="flex items-center gap-1 w-fit">
                                  {student.role === 'admin' ? (
                                    <>
                                      <Crown className="h-3 w-3" />
                                      <span>एडमिन</span>
                                    </>
                                  ) : student.role === 'uploader' ? (
                                    <>
                                      <Upload className="h-3 w-3" />
                                      <span>अपलोडर</span>
                                    </>
                                  ) : (
                                    <>
                                      <UserIcon className="h-3 w-3" />
                                      <span>छात्र</span>
                                    </>
                                  )}
                                </Badge>
                              </div>
                              <div className="space-y-1 mt-2">
                                {student.email && (
                                  <p className="text-sm text-muted-foreground break-all flex items-center gap-1">
                                    <Mail className="h-3 w-3 shrink-0" /> {student.email}
                                  </p>
                                )}
                                {student.phone && (
                                  <p className="text-sm text-muted-foreground flex items-center gap-1">
                                    <Phone className="h-3 w-3 shrink-0" /> {student.phone}
                                  </p>
                                )}
                                <p className="text-xs text-muted-foreground flex items-center gap-1">
                                  <Calendar className="h-3 w-3 shrink-0" /> पंजीकृत: {formatDate(student.created_at)}
                                </p>
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2 shrink-0 flex-wrap">
                            {student.role === 'user' ? (
                              <>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleRoleChange(student.id, 'uploader')}
                                  className="w-full xl:w-auto"
                                >
                                  <Upload className="h-4 w-4 mr-1" />
                                  अपलोडर बनाएं
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleRoleChange(student.id, 'admin')}
                                  className="w-full xl:w-auto"
                                >
                                  <Shield className="h-4 w-4 mr-1" />
                                  एडमिन बनाएं
                                </Button>
                              </>
                            ) : student.role === 'uploader' ? (
                              <>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleRoleChange(student.id, 'user')}
                                  className="w-full xl:w-auto"
                                >
                                  <UserIcon className="h-4 w-4 mr-1" />
                                  छात्र बनाएं
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleRoleChange(student.id, 'admin')}
                                  className="w-full xl:w-auto"
                                >
                                  <Shield className="h-4 w-4 mr-1" />
                                  एडमिन बनाएं
                                </Button>
                              </>
                            ) : (
                              <>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleRoleChange(student.id, 'user')}
                                  className="w-full xl:w-auto"
                                >
                                  <UserIcon className="h-4 w-4 mr-1" />
                                  छात्र बनाएं
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleRoleChange(student.id, 'uploader')}
                                  className="w-full xl:w-auto"
                                >
                                  <Upload className="h-4 w-4 mr-1" />
                                  अपलोडर बनाएं
                                </Button>
                              </>
                            )}
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => setStudentToDelete(student)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Delete Student Dialog */}
      <AlertDialog open={!!studentToDelete} onOpenChange={() => setStudentToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>छात्र हटाएं?</AlertDialogTitle>
            <AlertDialogDescription>
              क्या आप वाकई "{studentToDelete?.full_name || studentToDelete?.email}" को हटाना चाहते हैं? यह क्रिया पूर्ववत नहीं की जा सकती।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>रद्द करें</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteStudent}
              disabled={deleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  हटाया जा रहा है...
                </>
              ) : (
                'हटाएं'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Bulk Delete Dialog */}
      <AlertDialog open={showBulkDeleteDialog} onOpenChange={setShowBulkDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>चयनित छात्र हटाएं?</AlertDialogTitle>
            <AlertDialogDescription>
              क्या आप वाकई {selectedStudents.length} चयनित छात्रों को हटाना चाहते हैं? यह क्रिया पूर्ववत नहीं की जा सकती।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={bulkDeleting}>रद्द करें</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleBulkDelete}
              disabled={bulkDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {bulkDeleting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  हटाया जा रहा है...
                </>
              ) : (
                `${selectedStudents.length} छात्र हटाएं`
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
