import * as React from 'react';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/db/supabase';
import { ArrowLeft, Save, Loader2, Settings } from 'lucide-react';

interface AboutSettings {
  app_name: string;
  app_description: string;
  contact_email: string;
  contact_phone: string;
  whatsapp: string;
  youtube_url: string;
  instagram_url: string;
  facebook_url?: string;
  twitter_url?: string;
}

export default function AdminAboutSettingsPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState<AboutSettings>({
    app_name: 'PM - Roit Study Hub',
    app_description: 'कक्षा 8-12 के छात्रों के लिए संपूर्ण अध्ययन सामग्री',
    contact_email: 'support@pmroit.com',
    contact_phone: '+91 9876543210',
    whatsapp: '+91 9876543210',
    youtube_url: 'https://youtube.com/@pmroit',
    instagram_url: 'https://instagram.com/pmroit',
    facebook_url: 'https://facebook.com/pmroit',
    twitter_url: 'https://twitter.com/pmroit',
  });

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('admin_settings')
        .select('setting_value')
        .eq('setting_key', 'about_page')
        .single();

      if (error) throw error;
      if (data) {
        setSettings(data.setting_value as AboutSettings);
      }
    } catch (error) {
      console.error('Error loading settings:', error);
      toast({
        title: 'त्रुटि',
        description: 'सेटिंग्स लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('admin_settings')
        .update({
          setting_value: settings,
          updated_at: new Date().toISOString(),
        })
        .eq('setting_key', 'about_page');

      if (error) throw error;

      toast({
        title: 'सफलता',
        description: 'सेटिंग्स सफलतापूर्वक अपडेट की गई',
      });
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: 'त्रुटि',
        description: 'सेटिंग्स सहेजने में विफल',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const updateField = (field: keyof AboutSettings, value: string) => {
    setSettings(prev => ({ ...prev, [field]: value }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 xl:p-6 max-w-4xl">
      <Card className="glass-card">
        <CardHeader className="border-b border-border/50">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/admin')}
              className="shrink-0"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <CardTitle className="text-xl xl:text-2xl flex items-center gap-2">
                <Settings className="h-6 w-6" />
                About Page Settings
              </CardTitle>
              <CardDescription className="mt-1">
                About पेज की जानकारी और संपर्क विवरण संपादित करें
              </CardDescription>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-4 xl:p-6 space-y-6">
          {/* App Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">ऐप जानकारी</h3>
            
            <div className="space-y-2">
              <Label htmlFor="app_name">ऐप का नाम</Label>
              <Input
                id="app_name"
                value={settings.app_name}
                onChange={(e) => updateField('app_name', e.target.value)}
                placeholder="PM - Roit Study Hub"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="app_description">ऐप विवरण</Label>
              <Textarea
                id="app_description"
                value={settings.app_description}
                onChange={(e) => updateField('app_description', e.target.value)}
                placeholder="कक्षा 8-12 के छात्रों के लिए संपूर्ण अध्ययन सामग्री"
                className="min-h-[80px]"
              />
            </div>
          </div>

          {/* Contact Details */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">संपर्क विवरण</h3>
            
            <div className="space-y-2">
              <Label htmlFor="contact_email">ईमेल</Label>
              <Input
                id="contact_email"
                type="email"
                value={settings.contact_email}
                onChange={(e) => updateField('contact_email', e.target.value)}
                placeholder="support@pmroit.com"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contact_phone">फ़ोन नंबर</Label>
              <Input
                id="contact_phone"
                value={settings.contact_phone}
                onChange={(e) => updateField('contact_phone', e.target.value)}
                placeholder="+91 9876543210"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="whatsapp">व्हाट्सएप नंबर</Label>
              <Input
                id="whatsapp"
                value={settings.whatsapp}
                onChange={(e) => updateField('whatsapp', e.target.value)}
                placeholder="+91 9876543210"
              />
            </div>
          </div>

          {/* Social Media Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">सोशल मीडिया लिंक</h3>
            
            <div className="space-y-2">
              <Label htmlFor="youtube_url">YouTube URL</Label>
              <Input
                id="youtube_url"
                value={settings.youtube_url}
                onChange={(e) => updateField('youtube_url', e.target.value)}
                placeholder="https://youtube.com/@pmroit"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="instagram_url">Instagram URL</Label>
              <Input
                id="instagram_url"
                value={settings.instagram_url}
                onChange={(e) => updateField('instagram_url', e.target.value)}
                placeholder="https://instagram.com/pmroit"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="facebook_url">Facebook URL (वैकल्पिक)</Label>
              <Input
                id="facebook_url"
                value={settings.facebook_url || ''}
                onChange={(e) => updateField('facebook_url', e.target.value)}
                placeholder="https://facebook.com/pmroit"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="twitter_url">Twitter URL (वैकल्पिक)</Label>
              <Input
                id="twitter_url"
                value={settings.twitter_url || ''}
                onChange={(e) => updateField('twitter_url', e.target.value)}
                placeholder="https://twitter.com/pmroit"
              />
            </div>
          </div>

          {/* Save Button */}
          <div className="flex justify-end pt-4 border-t border-border/50">
            <Button
              onClick={handleSave}
              disabled={saving}
              className="bg-gradient-to-r from-primary to-secondary"
            >
              {saving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  सहेजा जा रहा है...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  सेटिंग्स सहेजें
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
