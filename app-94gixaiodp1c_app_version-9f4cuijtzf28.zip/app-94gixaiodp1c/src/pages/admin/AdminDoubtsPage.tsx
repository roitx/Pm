import * as React from 'react';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { getAllDoubts, answerDoubt, updateDoubtStatus } from '@/db/api';
import { useAuth } from '@/contexts/AuthContext';
import { HelpCircle, Send, CheckCircle, Clock, X } from 'lucide-react';
import { formatDate } from '@/lib/constants';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface Doubt {
  id: string;
  title: string;
  description: string;
  subject: string | null;
  class: number | null;
  status: 'pending' | 'answered' | 'closed';
  answer: string | null;
  answered_at: string | null;
  created_at: string;
  user: {
    full_name: string;
    email: string;
  };
  answerer: {
    full_name: string;
  } | null;
}

export default function AdminDoubtsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [doubts, setDoubts] = useState<Doubt[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDoubt, setSelectedDoubt] = useState<Doubt | null>(null);
  const [answerText, setAnswerText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);

  useEffect(() => {
    loadDoubts();
  }, []);

  const loadDoubts = async () => {
    setLoading(true);
    try {
      const data = await getAllDoubts();
      setDoubts(data as Doubt[]);
    } catch (error) {
      console.error('Error loading doubts:', error);
      toast({
        title: 'त्रुटि',
        description: 'प्रश्न लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerDoubt = async () => {
    if (!selectedDoubt || !user || !answerText.trim()) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया उत्तर लिखें',
        variant: 'destructive',
      });
      return;
    }

    setSubmitting(true);
    try {
      await answerDoubt(selectedDoubt.id, answerText.trim(), user.id);
      toast({
        title: 'सफलता',
        description: 'उत्तर सबमिट हो गया',
      });
      setDialogOpen(false);
      setAnswerText('');
      setSelectedDoubt(null);
      loadDoubts();
    } catch (error) {
      console.error('Error answering doubt:', error);
      toast({
        title: 'त्रुटि',
        description: 'उत्तर सबमिट करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleCloseDoubt = async (doubtId: string) => {
    try {
      await updateDoubtStatus(doubtId, 'closed');
      toast({
        title: 'सफलता',
        description: 'प्रश्न बंद कर दिया गया',
      });
      loadDoubts();
    } catch (error) {
      console.error('Error closing doubt:', error);
      toast({
        title: 'त्रुटि',
        description: 'प्रश्न बंद करने में विफल',
        variant: 'destructive',
      });
    }
  };

  const openAnswerDialog = (doubt: Doubt) => {
    setSelectedDoubt(doubt);
    setAnswerText(doubt.answer || '');
    setDialogOpen(true);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'answered':
        return <Badge variant="default" className="bg-green-500"><CheckCircle className="h-3 w-3 mr-1" />उत्तर दिया गया</Badge>;
      case 'pending':
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />प्रतीक्षारत</Badge>;
      case 'closed':
        return <Badge variant="outline"><X className="h-3 w-3 mr-1" />बंद</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const filterDoubts = (status: string) => {
    if (status === 'all') return doubts;
    return doubts.filter(d => d.status === status);
  };

  const DoubtCard = ({ doubt }: { doubt: Doubt }) => (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg mb-2">{doubt.title}</CardTitle>
            <div className="flex flex-wrap gap-2 mb-2">
              {getStatusBadge(doubt.status)}
              {doubt.subject && (
                <Badge variant="outline">{doubt.subject}</Badge>
              )}
              {doubt.class && (
                <Badge variant="outline">कक्षा {doubt.class}</Badge>
              )}
            </div>
            <p className="text-sm text-muted-foreground">
              पूछा गया: {doubt.user.full_name} ({doubt.user.email})
            </p>
          </div>
          <span className="text-xs text-muted-foreground">
            {formatDate(doubt.created_at)}
          </span>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h4 className="font-semibold mb-2">प्रश्न:</h4>
          <p className="text-muted-foreground whitespace-pre-wrap">
            {doubt.description}
          </p>
        </div>

        {doubt.answer && (
          <div className="border-t pt-4">
            <h4 className="font-semibold mb-2">उत्तर:</h4>
            <p className="text-muted-foreground whitespace-pre-wrap bg-muted/30 p-4 rounded-lg">
              {doubt.answer}
            </p>
            {doubt.answerer && (
              <p className="text-xs text-muted-foreground mt-2">
                उत्तर दिया: {doubt.answerer.full_name} • {formatDate(doubt.answered_at!)}
              </p>
            )}
          </div>
        )}

        <div className="flex gap-2">
          <Button
            onClick={() => openAnswerDialog(doubt)}
            variant={doubt.answer ? 'outline' : 'default'}
            size="sm"
          >
            <Send className="h-4 w-4 mr-2" />
            {doubt.answer ? 'उत्तर संपादित करें' : 'उत्तर दें'}
          </Button>
          {doubt.status !== 'closed' && (
            <Button
              onClick={() => handleCloseDoubt(doubt.id)}
              variant="outline"
              size="sm"
            >
              <X className="h-4 w-4 mr-2" />
              बंद करें
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center animate-float">
            <HelpCircle className="h-8 w-8 text-white" />
          </div>
        </div>
        <h1 className="text-3xl font-bold gradient-text">Doubts प्रबंधन</h1>
        <p className="text-muted-foreground">
          छात्रों के प्रश्नों का उत्तर दें
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardDescription>प्रतीक्षारत</CardDescription>
            <CardTitle className="text-3xl">
              {doubts.filter(d => d.status === 'pending').length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardDescription>उत्तर दिए गए</CardDescription>
            <CardTitle className="text-3xl">
              {doubts.filter(d => d.status === 'answered').length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardDescription>कुल प्रश्न</CardDescription>
            <CardTitle className="text-3xl">{doubts.length}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      {/* Doubts List with Tabs */}
      <Tabs defaultValue="pending" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="pending">प्रतीक्षारत</TabsTrigger>
          <TabsTrigger value="answered">उत्तर दिए गए</TabsTrigger>
          <TabsTrigger value="closed">बंद</TabsTrigger>
          <TabsTrigger value="all">सभी</TabsTrigger>
        </TabsList>

        {['pending', 'answered', 'closed', 'all'].map((status) => (
          <TabsContent key={status} value={status} className="space-y-4">
            {loading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <Card key={i} className="glass-card">
                    <CardHeader>
                      <Skeleton className="h-6 w-3/4 bg-muted" />
                      <Skeleton className="h-4 w-1/2 bg-muted" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-20 w-full bg-muted" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : filterDoubts(status).length > 0 ? (
              filterDoubts(status).map((doubt) => (
                <DoubtCard key={doubt.id} doubt={doubt} />
              ))
            ) : (
              <Card className="glass-card">
                <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                  <HelpCircle className="h-16 w-16 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">
                    इस श्रेणी में कोई प्रश्न नहीं
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        ))}
      </Tabs>

      {/* Answer Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>उत्तर दें</DialogTitle>
            <DialogDescription>
              {selectedDoubt?.title}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-muted/30 p-4 rounded-lg">
              <h4 className="font-semibold mb-2">प्रश्न:</h4>
              <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                {selectedDoubt?.description}
              </p>
            </div>

            <Textarea
              value={answerText}
              onChange={(e) => setAnswerText(e.target.value)}
              placeholder="अपना उत्तर यहाँ लिखें..."
              rows={8}
            />

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                रद्द करें
              </Button>
              <Button onClick={handleAnswerDoubt} disabled={submitting}>
                {submitting ? 'सबमिट हो रहा है...' : 'उत्तर सबमिट करें'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
