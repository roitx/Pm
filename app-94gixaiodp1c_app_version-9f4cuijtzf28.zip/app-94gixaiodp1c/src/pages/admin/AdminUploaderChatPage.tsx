import * as React from 'react';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import { AdminUploaderChat } from '@/components/ui/AdminUploaderChat';
import { Search, MessageSquare, ArrowLeft, Crown, Upload, Users } from 'lucide-react';
import type { Profile } from '@/types/types';

export default function AdminUploaderChatPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user, profile } = useAuth();
  const [users, setUsers] = useState<Profile[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<Profile[]>([]);
  const [selectedUser, setSelectedUser] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (user && profile) {
      loadUsers();
    }
  }, [user, profile]);

  useEffect(() => {
    if (searchQuery) {
      const filtered = users.filter(u =>
        u.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        u.email?.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredUsers(filtered);
    } else {
      setFilteredUsers(users);
    }
  }, [searchQuery, users]);

  const loadUsers = async () => {
    if (!profile) return;

    try {
      setLoading(true);
      
      // Admin can chat with both uploaders and other admins
      // Uploader can chat with admins
      let query = supabase
        .from('profiles')
        .select('*');

      if (profile.role === 'admin') {
        // Admin sees all uploaders AND other admins (excluding self)
        query = query.in('role', ['uploader', 'admin']).neq('id', user?.id || '');
      } else if (profile.role === 'uploader') {
        // Uploader sees all admins
        query = query.eq('role', 'admin');
      } else {
        // Regular users cannot access this page
        toast({
          title: 'त्रुटि',
          description: 'आपके पास इस पेज को देखने की अनुमति नहीं है',
          variant: 'destructive',
        });
        navigate('/');
        return;
      }

      const { data, error } = await query.order('full_name');

      if (error) {
        console.error('Error loading users:', error);
        throw error;
      }

      console.log(`Loaded ${data?.length || 0} users for ${profile.role}`);
      console.log('Users:', data);

      setUsers(data || []);
      setFilteredUsers(data || []);
      
      // Show info if no users found
      if (!data || data.length === 0) {
        const targetRole = profile.role === 'admin' ? 'अपलोडर या एडमिन' : 'एडमिन';
        toast({
          title: 'जानकारी',
          description: `कोई ${targetRole} नहीं मिला`,
        });
      }
    } catch (error) {
      console.error('Error loading users:', error);
      toast({
        title: 'त्रुटि',
        description: 'उपयोगकर्ता लोड करने में समस्या हुई',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (!profile || (profile.role !== 'admin' && profile.role !== 'uploader')) {
    return (
      <div className="container mx-auto p-4 xl:p-6">
        <Card className="glass-card">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <MessageSquare className="h-16 w-16 text-muted-foreground opacity-50 mb-4" />
            <p className="text-muted-foreground">आपके पास इस पेज को देखने की अनुमति नहीं है</p>
            <Button onClick={() => navigate('/')} className="mt-4">
              होम पर जाएं
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 xl:p-6 space-y-6">
      {/* Header */}
      <Card className="glass-card">
        <CardHeader>
          <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4">
            <div>
              <CardTitle className="text-xl xl:text-2xl gradient-text">
                {profile.role === 'admin' ? 'टीम चैट' : 'एडमिन से बात करें'}
              </CardTitle>
              <CardDescription className="text-base mt-2">
                {profile.role === 'admin' 
                  ? 'अपलोडर्स और अन्य एडमिन्स के साथ संवाद करें और फ़ाइलें शेयर करें'
                  : 'एडमिन के साथ संवाद करें और फ़ाइलें शेयर करें'
                }
              </CardDescription>
            </div>
            <Button 
              variant="outline" 
              onClick={() => navigate(profile.role === 'admin' ? '/admin' : '/uploader')}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              वापस जाएं
            </Button>
          </div>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Users List */}
        <Card className="glass-card xl:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">
              {profile.role === 'admin' ? 'टीम सदस्य' : 'एडमिन'}
            </CardTitle>
            <div className="relative mt-3">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="नाम या ईमेल से खोजें..."
                className="pl-10"
              />
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-16 bg-muted" />
                ))}
              </div>
            ) : filteredUsers.length === 0 ? (
              <div className="text-center py-8">
                <Users className="h-12 w-12 mx-auto text-muted-foreground opacity-50 mb-3" />
                <p className="text-muted-foreground text-sm">
                  {profile.role === 'admin' ? 'कोई टीम सदस्य नहीं मिला' : 'कोई एडमिन नहीं मिला'}
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {filteredUsers.map((u) => {
                  // Get unread count for this user (will be implemented with real-time updates)
                  const unreadCount = 0; // Placeholder for now
                  
                  return (
                    <Card
                      key={u.id}
                      className={`cursor-pointer transition-all hover:border-primary/50 ${
                        selectedUser?.id === u.id ? 'border-primary border-2' : ''
                      }`}
                      onClick={() => setSelectedUser(u)}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-center gap-3">
                          <div className="relative">
                            <Avatar className="h-10 w-10">
                              <AvatarImage src={u.profile_photo_url || undefined} />
                              <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white">
                                {u.full_name?.[0]?.toUpperCase() || u.email?.[0]?.toUpperCase() || '?'}
                              </AvatarFallback>
                            </Avatar>
                            {unreadCount > 0 && (
                              <Badge 
                                variant="destructive" 
                                className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
                              >
                                {unreadCount > 9 ? '9+' : unreadCount}
                              </Badge>
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">
                            {u.full_name || 'नाम नहीं'}
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge 
                              variant={u.role === 'admin' ? 'default' : 'outline'} 
                              className="text-xs"
                            >
                              {u.role === 'admin' ? (
                                <>
                                  <Crown className="h-3 w-3 mr-1" />
                                  एडमिन
                                </>
                              ) : (
                                <>
                                  <Upload className="h-3 w-3 mr-1" />
                                  अपलोडर
                                </>
                              )}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Chat Area */}
        <div className="xl:col-span-2">
          {selectedUser ? (
            <AdminUploaderChat
              receiverId={selectedUser.id}
              receiverName={selectedUser.full_name || 'उपयोगकर्ता'}
              receiverRole={selectedUser.role as 'admin' | 'uploader'}
            />
          ) : (
            <Card className="glass-card">
              <CardContent className="flex flex-col items-center justify-center h-[600px]">
                <MessageSquare className="h-16 w-16 text-muted-foreground opacity-50 mb-4" />
                <p className="text-muted-foreground">
                  {profile.role === 'admin' 
                    ? 'बातचीत शुरू करने के लिए एक अपलोडर चुनें'
                    : 'बातचीत शुरू करने के लिए एक एडमिन चुनें'
                  }
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
