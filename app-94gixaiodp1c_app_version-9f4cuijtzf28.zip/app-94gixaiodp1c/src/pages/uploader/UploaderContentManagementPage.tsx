import * as React from 'react';
import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DynamicIcon } from '@/components/ui/DynamicIcon';
import { PDFViewer } from '@/components/ui/PDFViewer';
import { ImageViewer } from '@/components/ui/ImageViewer';
import { useToast } from '@/hooks/use-toast';
import { deleteContent, getMCQQuestions, deleteMCQQuestion, updateMCQQuestion, updateContent, getThreeDStructures, deleteThreeDStructure, updateThreeDStructure, getExternalNotes, deleteExternalNote, updateExternalNote } from '@/db/api';
import { CLASSES, CATEGORIES } from '@/lib/constants';
import { Loader2, Search, Trash2, FileText, Image, File, ArrowLeft, CheckCircle, ClipboardList, Plus, Edit, Eye, Package, Paperclip } from 'lucide-react';
import type { Content, MCQQuestion } from '@/types/types';
import type { ThreeDStructure, ExternalNote } from '@/types/types';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

export default function UploaderContentManagementPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();

  // Active tab state - get from location state or default to 'content'
  const [activeTab, setActiveTab] = useState<string>(
    (location.state as { activeTab?: string })?.activeTab || 'content'
  );

  // Content state
  const [contents, setContents] = useState<Content[]>([]);
  const [filteredContents, setFilteredContents] = useState<Content[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedClass, setSelectedClass] = useState<string>('all');
  const [contentToDelete, setContentToDelete] = useState<Content | null>(null);
  const [deleting, setDeleting] = useState(false);
  
  // Viewer states
  const [viewerOpen, setViewerOpen] = useState(false);
  const [viewingContent, setViewingContent] = useState<Content | null>(null);
  
  // Edit content state
  const [contentToEdit, setContentToEdit] = useState<Content | null>(null);
  const [editingContent, setEditingContent] = useState(false);
  const [contentEditForm, setContentEditForm] = useState<Partial<Content>>({});

  // MCQ state
  const [mcqQuestions, setMcqQuestions] = useState<MCQQuestion[]>([]);
  const [filteredMcqQuestions, setFilteredMcqQuestions] = useState<MCQQuestion[]>([]);
  const [mcqLoading, setMcqLoading] = useState(false);
  const [mcqSearchQuery, setMcqSearchQuery] = useState('');
  const [mcqSelectedClass, setMcqSelectedClass] = useState<string>('all');
  const [mcqToDelete, setMcqToDelete] = useState<MCQQuestion | null>(null);
  const [deletingMcq, setDeletingMcq] = useState(false);
  const [mcqToEdit, setMcqToEdit] = useState<MCQQuestion | null>(null);
  const [editingMcq, setEditingMcq] = useState(false);
  const [editForm, setEditForm] = useState<Partial<MCQQuestion>>({});

  // IIT-JEE state
  const [iitjeeQuestions, setIitjeeQuestions] = useState<MCQQuestion[]>([]);
  const [filteredIitjeeQuestions, setFilteredIitjeeQuestions] = useState<MCQQuestion[]>([]);
  const [iitjeeLoading, setIitjeeLoading] = useState(false);
  const [iitjeeSearchQuery, setIitjeeSearchQuery] = useState('');
  const [iitjeeSelectedClass, setIitjeeSelectedClass] = useState<string>('all');
  const [iitjeeToDelete, setIitjeeToDelete] = useState<MCQQuestion | null>(null);
  const [deletingIitjee, setDeletingIitjee] = useState(false);
  const [iitjeeToEdit, setIitjeeToEdit] = useState<MCQQuestion | null>(null);
  const [editingIitjee, setEditingIitjee] = useState(false);
  const [iitjeeEditForm, setIitjeeEditForm] = useState<Partial<MCQQuestion>>({});

  // 3D Structures state
  const [threeDStructures, setThreeDStructures] = useState<ThreeDStructure[]>([]);
  const [filtered3DStructures, setFiltered3DStructures] = useState<ThreeDStructure[]>([]);
  const [threeDLoading, setThreeDLoading] = useState(false);
  const [threeDSearchQuery, setThreeDSearchQuery] = useState('');
  const [threeDSelectedClass, setThreeDSelectedClass] = useState<string>('all');
  const [threeDToDelete, setThreeDToDelete] = useState<ThreeDStructure | null>(null);
  const [deletingThreeD, setDeletingThreeD] = useState(false);

  // External Notes state
  const [externalNotes, setExternalNotes] = useState<ExternalNote[]>([]);
  const [filteredExternalNotes, setFilteredExternalNotes] = useState<ExternalNote[]>([]);
  const [externalLoading, setExternalLoading] = useState(false);
  const [externalSearchQuery, setExternalSearchQuery] = useState('');
  const [externalSelectedClass, setExternalSelectedClass] = useState<string>('all');
  const [externalToDelete, setExternalToDelete] = useState<ExternalNote | null>(null);
  const [deletingExternal, setDeletingExternal] = useState(false);

  useEffect(() => {
    if (user) {
      loadContents();
      loadMcqQuestions();
      loadIitjeeQuestions();
      load3DStructures();
      loadExternalNotes();
    }
  }, [user]);

  useEffect(() => {
    filterContents();
  }, [searchQuery, selectedCategory, selectedClass, contents]);

  useEffect(() => {
    filterMcqQuestions();
  }, [mcqSearchQuery, mcqSelectedClass, mcqQuestions]);

  useEffect(() => {
    filterIitjeeQuestions();
  }, [iitjeeSearchQuery, iitjeeSelectedClass, iitjeeQuestions]);

  useEffect(() => {
    filter3DStructures();
  }, [threeDSearchQuery, threeDSelectedClass, threeDStructures]);

  useEffect(() => {
    filterExternalNotes();
  }, [externalSearchQuery, externalSelectedClass, externalNotes]);

  // Content functions - Load only uploader's own content
  const loadContents = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('content')
        .select('*')
        .eq('uploaded_by', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setContents(data || []);
    } catch (error) {
      console.error('Error loading contents:', error);
      toast({
        title: 'त्रुटि',
        description: 'सामग्री लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const filterContents = () => {
    let filtered = [...contents];

    if (searchQuery) {
      filtered = filtered.filter(
        (content) =>
          content.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          content.subject?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          content.chapter?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter((content) => content.category === selectedCategory);
    }

    if (selectedClass !== 'all') {
      filtered = filtered.filter((content) => content.class === Number(selectedClass));
    }

    setFilteredContents(filtered);
  };

  // Handle viewing content
  const handleViewContent = (content: Content) => {
    setViewingContent(content);
    setViewerOpen(true);
  };

  // Handle editing content
  const handleEditContent = (content: Content) => {
    setContentToEdit(content);
    setContentEditForm({
      title: content.title,
      description: content.description,
      subject: content.subject,
      chapter: content.chapter,
    });
  };

  const handleSaveContentEdit = async () => {
    if (!contentToEdit) return;

    setEditingContent(true);
    try {
      await updateContent(contentToEdit.id, contentEditForm);
      toast({
        title: 'सफलता',
        description: 'सामग्री अपडेट हो गई',
      });
      setContentToEdit(null);
      loadContents();
    } catch (error) {
      console.error('Error updating content:', error);
      toast({
        title: 'त्रुटि',
        description: 'सामग्री अपडेट करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setEditingContent(false);
    }
  };

  const handleDeleteContent = async () => {
    if (!contentToDelete) return;

    setDeleting(true);
    try {
      await deleteContent(contentToDelete.id);
      toast({
        title: 'सफलता',
        description: 'सामग्री हटा दी गई',
      });
      setContentToDelete(null);
      loadContents();
    } catch (error) {
      console.error('Error deleting content:', error);
      toast({
        title: 'त्रुटि',
        description: 'सामग्री हटाने में विफल',
        variant: 'destructive',
      });
    } finally {
      setDeleting(false);
    }
  };

  // 3D Structures functions
  const load3DStructures = async () => {
    if (!user) return;
    
    setThreeDLoading(true);
    try {
      const data = await getThreeDStructures();
      // Filter by uploader
      const uploaderData = data.filter(item => item.uploaded_by === user.id);
      setThreeDStructures(uploaderData);
      setFiltered3DStructures(uploaderData);
    } catch (error) {
      console.error('Error loading 3D structures:', error);
      toast({
        title: 'त्रुटि',
        description: '3D संरचनाएं लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setThreeDLoading(false);
    }
  };

  const filter3DStructures = () => {
    let filtered = [...threeDStructures];

    if (threeDSearchQuery) {
      filtered = filtered.filter(item =>
        item.title.toLowerCase().includes(threeDSearchQuery.toLowerCase()) ||
        item.subject.toLowerCase().includes(threeDSearchQuery.toLowerCase())
      );
    }

    if (threeDSelectedClass !== 'all') {
      filtered = filtered.filter(item => item.class.toString() === threeDSelectedClass);
    }

    setFiltered3DStructures(filtered);
  };

  const handleDelete3DStructure = async () => {
    if (!threeDToDelete) return;

    setDeletingThreeD(true);
    try {
      await deleteThreeDStructure(threeDToDelete.id);
      toast({
        title: 'सफलता',
        description: '3D संरचना हटा दी गई',
      });
      setThreeDToDelete(null);
      load3DStructures();
    } catch (error) {
      console.error('Error deleting 3D structure:', error);
      toast({
        title: 'त्रुटि',
        description: '3D संरचना हटाने में विफल',
        variant: 'destructive',
      });
    } finally {
      setDeletingThreeD(false);
    }
  };

  // External Notes functions
  const loadExternalNotes = async () => {
    if (!user) return;
    
    setExternalLoading(true);
    try {
      const data = await getExternalNotes();
      // Filter by uploader
      const uploaderData = data.filter(item => item.uploaded_by === user.id);
      setExternalNotes(uploaderData);
      setFilteredExternalNotes(uploaderData);
    } catch (error) {
      console.error('Error loading external notes:', error);
      toast({
        title: 'त्रुटि',
        description: 'बाहरी नोट्स लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setExternalLoading(false);
    }
  };

  const filterExternalNotes = () => {
    let filtered = [...externalNotes];

    if (externalSearchQuery) {
      filtered = filtered.filter(item =>
        item.title.toLowerCase().includes(externalSearchQuery.toLowerCase()) ||
        item.subject.toLowerCase().includes(externalSearchQuery.toLowerCase()) ||
        item.source.toLowerCase().includes(externalSearchQuery.toLowerCase())
      );
    }

    if (externalSelectedClass !== 'all') {
      filtered = filtered.filter(item => item.class.toString() === externalSelectedClass);
    }

    setFilteredExternalNotes(filtered);
  };

  const handleDeleteExternalNote = async () => {
    if (!externalToDelete) return;

    setDeletingExternal(true);
    try {
      await deleteExternalNote(externalToDelete.id);
      toast({
        title: 'सफलता',
        description: 'बाहरी नोट्स हटा दिए गए',
      });
      setExternalToDelete(null);
      loadExternalNotes();
    } catch (error) {
      console.error('Error deleting external note:', error);
      toast({
        title: 'त्रुटि',
        description: 'बाहरी नोट्स हटाने में विफल',
        variant: 'destructive',
      });
    } finally {
      setDeletingExternal(false);
    }
  };

  // MCQ functions - Load only uploader's own MCQs
  const loadMcqQuestions = async () => {
    if (!user) return;
    
    setMcqLoading(true);
    try {
      const { data, error } = await supabase
        .from('mcq_questions')
        .select('*')
        .eq('created_by', user.id)
        .neq('category', 'iit_jee_questions')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setMcqQuestions(data || []);
    } catch (error) {
      console.error('Error loading MCQ questions:', error);
      toast({
        title: 'त्रुटि',
        description: 'MCQ प्रश्न लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setMcqLoading(false);
    }
  };

  const filterMcqQuestions = () => {
    let filtered = [...mcqQuestions];

    if (mcqSearchQuery) {
      filtered = filtered.filter(
        (q) =>
          q.question.toLowerCase().includes(mcqSearchQuery.toLowerCase()) ||
          q.subject?.toLowerCase().includes(mcqSearchQuery.toLowerCase())
      );
    }

    if (mcqSelectedClass !== 'all') {
      filtered = filtered.filter((q) => q.class === Number(mcqSelectedClass));
    }

    setFilteredMcqQuestions(filtered);
  };

  const handleEditMcq = (mcq: MCQQuestion) => {
    setMcqToEdit(mcq);
    setEditForm({
      question: mcq.question,
      option_a: mcq.option_a,
      option_b: mcq.option_b,
      option_c: mcq.option_c,
      option_d: mcq.option_d,
      correct_answer: mcq.correct_answer,
      explanation: mcq.explanation,
    });
  };

  const handleSaveMcqEdit = async () => {
    if (!mcqToEdit) return;

    setEditingMcq(true);
    try {
      await updateMCQQuestion(mcqToEdit.id, editForm);
      toast({
        title: 'सफलता',
        description: 'MCQ प्रश्न अपडेट हो गया',
      });
      setMcqToEdit(null);
      loadMcqQuestions();
    } catch (error) {
      console.error('Error updating MCQ:', error);
      toast({
        title: 'त्रुटि',
        description: 'MCQ अपडेट करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setEditingMcq(false);
    }
  };

  const handleDeleteMcq = async () => {
    if (!mcqToDelete) return;

    setDeletingMcq(true);
    try {
      await deleteMCQQuestion(mcqToDelete.id);
      toast({
        title: 'सफलता',
        description: 'MCQ प्रश्न हटा दिया गया',
      });
      setMcqToDelete(null);
      loadMcqQuestions();
    } catch (error) {
      console.error('Error deleting MCQ:', error);
      toast({
        title: 'त्रुटि',
        description: 'MCQ हटाने में विफल',
        variant: 'destructive',
      });
    } finally {
      setDeletingMcq(false);
    }
  };

  // IIT-JEE functions - Load only uploader's own IIT-JEE questions
  const loadIitjeeQuestions = async () => {
    if (!user) return;
    
    setIitjeeLoading(true);
    try {
      const { data, error } = await supabase
        .from('mcq_questions')
        .select('*')
        .eq('created_by', user.id)
        .eq('category', 'iit_jee_questions')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setIitjeeQuestions(data || []);
    } catch (error) {
      console.error('Error loading IIT-JEE questions:', error);
      toast({
        title: 'त्रुटि',
        description: 'IIT-JEE प्रश्न लोड करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setIitjeeLoading(false);
    }
  };

  const filterIitjeeQuestions = () => {
    let filtered = [...iitjeeQuestions];

    if (iitjeeSearchQuery) {
      filtered = filtered.filter(
        (q) =>
          q.question.toLowerCase().includes(iitjeeSearchQuery.toLowerCase()) ||
          q.subject?.toLowerCase().includes(iitjeeSearchQuery.toLowerCase())
      );
    }

    if (iitjeeSelectedClass !== 'all') {
      filtered = filtered.filter((q) => q.class === Number(iitjeeSelectedClass));
    }

    setFilteredIitjeeQuestions(filtered);
  };

  const handleEditIitjee = (iitjee: MCQQuestion) => {
    setIitjeeToEdit(iitjee);
    setIitjeeEditForm({
      question: iitjee.question,
      option_a: iitjee.option_a,
      option_b: iitjee.option_b,
      option_c: iitjee.option_c,
      option_d: iitjee.option_d,
      correct_answer: iitjee.correct_answer,
      explanation: iitjee.explanation,
    });
  };

  const handleSaveIitjeeEdit = async () => {
    if (!iitjeeToEdit) return;

    setEditingIitjee(true);
    try {
      await updateMCQQuestion(iitjeeToEdit.id, iitjeeEditForm);
      toast({
        title: 'सफलता',
        description: 'IIT-JEE प्रश्न अपडेट हो गया',
      });
      setIitjeeToEdit(null);
      loadIitjeeQuestions();
    } catch (error) {
      console.error('Error updating IIT-JEE:', error);
      toast({
        title: 'त्रुटि',
        description: 'IIT-JEE अपडेट करने में विफल',
        variant: 'destructive',
      });
    } finally {
      setEditingIitjee(false);
    }
  };

  const handleDeleteIitjee = async () => {
    if (!iitjeeToDelete) return;

    setDeletingIitjee(true);
    try {
      await deleteMCQQuestion(iitjeeToDelete.id);
      toast({
        title: 'सफलता',
        description: 'IIT-JEE प्रश्न हटा दिया गया',
      });
      setIitjeeToDelete(null);
      loadIitjeeQuestions();
    } catch (error) {
      console.error('Error deleting IIT-JEE:', error);
      toast({
        title: 'त्रुटि',
        description: 'IIT-JEE हटाने में विफल',
        variant: 'destructive',
      });
    } finally {
      setDeletingIitjee(false);
    }
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.includes('pdf')) return <FileText className="h-4 w-4" />;
    if (fileType.includes('image')) return <Image className="h-4 w-4" />;
    return <File className="h-4 w-4" />;
  };

  return (
    <div className="container mx-auto p-4 xl:p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate('/uploader')}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-2xl xl:text-3xl font-bold">सामग्री प्रबंधन</h1>
          <p className="text-muted-foreground mt-1">अपनी अपलोड की गई सामग्री देखें और संपादित करें</p>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="content">
            <FileText className="h-4 w-4 mr-2" />
            सामग्री फ़ाइलें
          </TabsTrigger>
          <TabsTrigger value="3d">
            <Package className="h-4 w-4 mr-2" />
            3D संरचनाएं
          </TabsTrigger>
          <TabsTrigger value="external">
            <Paperclip className="h-4 w-4 mr-2" />
            बाहरी नोट्स
          </TabsTrigger>
          <TabsTrigger value="mcq">
            <ClipboardList className="h-4 w-4 mr-2" />
            MCQ प्रश्न
          </TabsTrigger>
          <TabsTrigger value="iitjee">
            <ClipboardList className="h-4 w-4 mr-2" />
            IIT-JEE प्रश्न
          </TabsTrigger>
        </TabsList>

        {/* Content Tab */}
        <TabsContent value="content" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">सामग्री फ़ाइलें (PDF, Images, etc.)</h3>
            <Button onClick={() => navigate('/uploader/content-upload')} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              नई सामग्री जोड़ें
            </Button>
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 xl:grid-cols-4 gap-3">
            <div className="xl:col-span-2 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="शीर्षक, विषय या अध्याय खोजें..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <SelectValue placeholder="श्रेणी चुनें" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">सभी श्रेणियां</SelectItem>
                {CATEGORIES.filter(cat => 
                  cat.id !== 'mcq_tests' && 
                  cat.id !== 'iit_jee_questions' && 
                  cat.id !== '3d_structures' && 
                  cat.id !== 'external_notes'
                ).map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedClass} onValueChange={setSelectedClass}>
              <SelectTrigger>
                <SelectValue placeholder="कक्षा चुनें" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">सभी कक्षाएं</SelectItem>
                {CLASSES.map((cls) => (
                  <SelectItem key={cls} value={cls.toString()}>
                    कक्षा {cls}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Content List */}
          {loading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredContents.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                कोई सामग्री नहीं मिली
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
              {filteredContents.map((content) => (
                <Card key={content.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-base">{content.title}</CardTitle>
                        <CardDescription className="mt-1">
                          {content.subject} {content.chapter && `• ${content.chapter}`}
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        {getFileIcon(content.file_type)}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="secondary">
                        {CATEGORIES.find((c) => c.id === content.category)?.name}
                      </Badge>
                      {content.class && <Badge variant="outline">कक्षा {content.class}</Badge>}
                    </div>
                    {content.description && (
                      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                        {content.description}
                      </p>
                    )}
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleViewContent(content)}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        देखें
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEditContent(content)}
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        संपादित करें
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => setContentToDelete(content)}
                      >
                        <Trash2 className="h-4 w-4 mr-1" />
                        हटाएं
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* MCQ Tab */}
        <TabsContent value="mcq" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">MCQ प्रश्न</h3>
            <Button onClick={() => navigate('/uploader/mcq-upload')} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              नया MCQ जोड़ें
            </Button>
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="प्रश्न या विषय खोजें..."
                value={mcqSearchQuery}
                onChange={(e) => setMcqSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={mcqSelectedClass} onValueChange={setMcqSelectedClass}>
              <SelectTrigger>
                <SelectValue placeholder="कक्षा चुनें" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">सभी कक्षाएं</SelectItem>
                {CLASSES.map((cls) => (
                  <SelectItem key={cls} value={cls.toString()}>
                    कक्षा {cls}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* MCQ List */}
          {mcqLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredMcqQuestions.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                कोई MCQ प्रश्न नहीं मिला
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredMcqQuestions.map((mcq) => (
                <Card key={mcq.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-base">{mcq.question}</CardTitle>
                        <CardDescription className="mt-1">
                          {mcq.subject} • कक्षा {mcq.class}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 mb-3">
                      <div className="text-sm">
                        <span className="font-medium">A:</span> {mcq.option_a}
                      </div>
                      <div className="text-sm">
                        <span className="font-medium">B:</span> {mcq.option_b}
                      </div>
                      <div className="text-sm">
                        <span className="font-medium">C:</span> {mcq.option_c}
                      </div>
                      <div className="text-sm">
                        <span className="font-medium">D:</span> {mcq.option_d}
                      </div>
                      <div className="text-sm text-green-600 font-medium">
                        सही उत्तर: {mcq.correct_answer}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEditMcq(mcq)}
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        संपादित करें
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => setMcqToDelete(mcq)}
                      >
                        <Trash2 className="h-4 w-4 mr-1" />
                        हटाएं
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* 3D Structures Tab */}
        <TabsContent value="3d" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">3D संरचनाएं</h3>
            <Button onClick={() => navigate('/uploader/3d-structures-upload')} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              नई 3D संरचना जोड़ें
            </Button>
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="शीर्षक खोजें..."
                value={threeDSearchQuery}
                onChange={(e) => setThreeDSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={threeDSelectedClass} onValueChange={setThreeDSelectedClass}>
              <SelectTrigger>
                <SelectValue placeholder="कक्षा चुनें" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">सभी कक्षाएं</SelectItem>
                {CLASSES.map((cls) => (
                  <SelectItem key={cls} value={cls.toString()}>
                    कक्षा {cls}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* 3D Structures List */}
          {threeDLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filtered3DStructures.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                कोई 3D संरचना नहीं मिली
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {filtered3DStructures.map((structure) => (
                <Card key={structure.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold truncate">{structure.title}</h4>
                        <div className="flex flex-wrap gap-2 mt-2">
                          <Badge variant="secondary">कक्षा {structure.class}</Badge>
                          <Badge variant="outline">{structure.subject}</Badge>
                          {structure.chapter && <Badge variant="outline">{structure.chapter}</Badge>}
                          <Badge variant="outline">{structure.file_type}</Badge>
                        </div>
                        {structure.description && (
                          <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                            {structure.description}
                          </p>
                        )}
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <Button
                          variant="destructive"
                          size="icon"
                          onClick={() => setThreeDToDelete(structure)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* External Notes Tab */}
        <TabsContent value="external" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">बाहरी नोट्स</h3>
            <Button onClick={() => navigate('/uploader/external-notes-upload')} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              नए बाहरी नोट्स जोड़ें
            </Button>
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="शीर्षक खोजें..."
                value={externalSearchQuery}
                onChange={(e) => setExternalSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={externalSelectedClass} onValueChange={setExternalSelectedClass}>
              <SelectTrigger>
                <SelectValue placeholder="कक्षा चुनें" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">सभी कक्षाएं</SelectItem>
                {CLASSES.map((cls) => (
                  <SelectItem key={cls} value={cls.toString()}>
                    कक्षा {cls}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* External Notes List */}
          {externalLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredExternalNotes.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                कोई बाहरी नोट्स नहीं मिले
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {filteredExternalNotes.map((note) => (
                <Card key={note.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold truncate">{note.title}</h4>
                        <div className="flex flex-wrap gap-2 mt-2">
                          <Badge variant="secondary">कक्षा {note.class}</Badge>
                          <Badge variant="outline">{note.subject}</Badge>
                          {note.chapter && <Badge variant="outline">{note.chapter}</Badge>}
                          <Badge variant="outline">{note.source}</Badge>
                          <Badge variant="outline">{note.file_type}</Badge>
                        </div>
                        {note.description && (
                          <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                            {note.description}
                          </p>
                        )}
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <Button
                          variant="destructive"
                          size="icon"
                          onClick={() => setExternalToDelete(note)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* IIT-JEE Tab */}
        <TabsContent value="iitjee" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">IIT-JEE प्रश्न</h3>
            <Button onClick={() => navigate('/uploader/iitjee-upload')} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              नया IIT-JEE प्रश्न जोड़ें
            </Button>
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="प्रश्न या विषय खोजें..."
                value={iitjeeSearchQuery}
                onChange={(e) => setIitjeeSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={iitjeeSelectedClass} onValueChange={setIitjeeSelectedClass}>
              <SelectTrigger>
                <SelectValue placeholder="कक्षा चुनें" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">सभी कक्षाएं</SelectItem>
                {CLASSES.map((cls) => (
                  <SelectItem key={cls} value={cls.toString()}>
                    कक्षा {cls}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* IIT-JEE List */}
          {iitjeeLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredIitjeeQuestions.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                कोई IIT-JEE प्रश्न नहीं मिला
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredIitjeeQuestions.map((iitjee) => (
                <Card key={iitjee.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-base">{iitjee.question}</CardTitle>
                        <CardDescription className="mt-1">
                          {iitjee.subject} • कक्षा {iitjee.class}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 mb-3">
                      <div className="text-sm">
                        <span className="font-medium">A:</span> {iitjee.option_a}
                      </div>
                      <div className="text-sm">
                        <span className="font-medium">B:</span> {iitjee.option_b}
                      </div>
                      <div className="text-sm">
                        <span className="font-medium">C:</span> {iitjee.option_c}
                      </div>
                      <div className="text-sm">
                        <span className="font-medium">D:</span> {iitjee.option_d}
                      </div>
                      <div className="text-sm text-green-600 font-medium">
                        सही उत्तर: {iitjee.correct_answer}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEditIitjee(iitjee)}
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        संपादित करें
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => setIitjeeToDelete(iitjee)}
                      >
                        <Trash2 className="h-4 w-4 mr-1" />
                        हटाएं
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Content Viewer Dialog */}
      {viewingContent && (
        <>
          {viewingContent.file_type.includes('pdf') ? (
            <Dialog open={viewerOpen} onOpenChange={setViewerOpen}>
              <DialogContent className="max-w-6xl h-[90vh]">
                <PDFViewer url={viewingContent.file_url} title={viewingContent.title} />
              </DialogContent>
            </Dialog>
          ) : viewingContent.file_type.includes('image') ? (
            <ImageViewer
              src={viewingContent.file_url}
              alt={viewingContent.title}
              open={viewerOpen}
              onClose={() => setViewerOpen(false)}
            />
          ) : null}
        </>
      )}

      {/* Content Edit Dialog */}
      <Dialog open={!!contentToEdit} onOpenChange={(open) => !open && setContentToEdit(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>सामग्री संपादित करें</DialogTitle>
            <DialogDescription>सामग्री की जानकारी अपडेट करें</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>शीर्षक</Label>
              <Input
                value={contentEditForm.title || ''}
                onChange={(e) => setContentEditForm({ ...contentEditForm, title: e.target.value })}
              />
            </div>
            <div>
              <Label>विषय</Label>
              <Input
                value={contentEditForm.subject || ''}
                onChange={(e) => setContentEditForm({ ...contentEditForm, subject: e.target.value })}
              />
            </div>
            <div>
              <Label>अध्याय</Label>
              <Input
                value={contentEditForm.chapter || ''}
                onChange={(e) => setContentEditForm({ ...contentEditForm, chapter: e.target.value })}
              />
            </div>
            <div>
              <Label>विवरण</Label>
              <Textarea
                value={contentEditForm.description || ''}
                onChange={(e) => setContentEditForm({ ...contentEditForm, description: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setContentToEdit(null)}>
              रद्द करें
            </Button>
            <Button onClick={handleSaveContentEdit} disabled={editingContent}>
              {editingContent && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              सहेजें
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Content Delete Dialog */}
      <AlertDialog open={!!contentToDelete} onOpenChange={(open) => !open && setContentToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>क्या आप निश्चित हैं?</AlertDialogTitle>
            <AlertDialogDescription>
              यह सामग्री स्थायी रूप से हटा दी जाएगी। यह क्रिया पूर्ववत नहीं की जा सकती।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>रद्द करें</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteContent} disabled={deleting}>
              {deleting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              हटाएं
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* MCQ Edit Dialog */}
      <Dialog open={!!mcqToEdit} onOpenChange={(open) => !open && setMcqToEdit(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>MCQ संपादित करें</DialogTitle>
            <DialogDescription>MCQ प्रश्न की जानकारी अपडेट करें</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 max-h-[60vh] overflow-y-auto">
            <div>
              <Label>प्रश्न</Label>
              <Textarea
                value={editForm.question || ''}
                onChange={(e) => setEditForm({ ...editForm, question: e.target.value })}
              />
            </div>
            <div>
              <Label>विकल्प A</Label>
              <Input
                value={editForm.option_a || ''}
                onChange={(e) => setEditForm({ ...editForm, option_a: e.target.value })}
              />
            </div>
            <div>
              <Label>विकल्प B</Label>
              <Input
                value={editForm.option_b || ''}
                onChange={(e) => setEditForm({ ...editForm, option_b: e.target.value })}
              />
            </div>
            <div>
              <Label>विकल्प C</Label>
              <Input
                value={editForm.option_c || ''}
                onChange={(e) => setEditForm({ ...editForm, option_c: e.target.value })}
              />
            </div>
            <div>
              <Label>विकल्प D</Label>
              <Input
                value={editForm.option_d || ''}
                onChange={(e) => setEditForm({ ...editForm, option_d: e.target.value })}
              />
            </div>
            <div>
              <Label>सही उत्तर</Label>
              <Select
                value={editForm.correct_answer || ''}
                onValueChange={(value) => setEditForm({ ...editForm, correct_answer: value as 'A' | 'B' | 'C' | 'D' })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A">A</SelectItem>
                  <SelectItem value="B">B</SelectItem>
                  <SelectItem value="C">C</SelectItem>
                  <SelectItem value="D">D</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>व्याख्या</Label>
              <Textarea
                value={editForm.explanation || ''}
                onChange={(e) => setEditForm({ ...editForm, explanation: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setMcqToEdit(null)}>
              रद्द करें
            </Button>
            <Button onClick={handleSaveMcqEdit} disabled={editingMcq}>
              {editingMcq && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              सहेजें
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* MCQ Delete Dialog */}
      <AlertDialog open={!!mcqToDelete} onOpenChange={(open) => !open && setMcqToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>क्या आप निश्चित हैं?</AlertDialogTitle>
            <AlertDialogDescription>
              यह MCQ प्रश्न स्थायी रूप से हटा दिया जाएगा। यह क्रिया पूर्ववत नहीं की जा सकती।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>रद्द करें</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteMcq} disabled={deletingMcq}>
              {deletingMcq && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              हटाएं
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* IIT-JEE Edit Dialog */}
      <Dialog open={!!iitjeeToEdit} onOpenChange={(open) => !open && setIitjeeToEdit(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>IIT-JEE प्रश्न संपादित करें</DialogTitle>
            <DialogDescription>IIT-JEE प्रश्न की जानकारी अपडेट करें</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 max-h-[60vh] overflow-y-auto">
            <div>
              <Label>प्रश्न</Label>
              <Textarea
                value={iitjeeEditForm.question || ''}
                onChange={(e) => setIitjeeEditForm({ ...iitjeeEditForm, question: e.target.value })}
              />
            </div>
            <div>
              <Label>विकल्प A</Label>
              <Input
                value={iitjeeEditForm.option_a || ''}
                onChange={(e) => setIitjeeEditForm({ ...iitjeeEditForm, option_a: e.target.value })}
              />
            </div>
            <div>
              <Label>विकल्प B</Label>
              <Input
                value={iitjeeEditForm.option_b || ''}
                onChange={(e) => setIitjeeEditForm({ ...iitjeeEditForm, option_b: e.target.value })}
              />
            </div>
            <div>
              <Label>विकल्प C</Label>
              <Input
                value={iitjeeEditForm.option_c || ''}
                onChange={(e) => setIitjeeEditForm({ ...iitjeeEditForm, option_c: e.target.value })}
              />
            </div>
            <div>
              <Label>विकल्प D</Label>
              <Input
                value={iitjeeEditForm.option_d || ''}
                onChange={(e) => setIitjeeEditForm({ ...iitjeeEditForm, option_d: e.target.value })}
              />
            </div>
            <div>
              <Label>सही उत्तर</Label>
              <Select
                value={iitjeeEditForm.correct_answer || ''}
                onValueChange={(value) => setIitjeeEditForm({ ...iitjeeEditForm, correct_answer: value as 'A' | 'B' | 'C' | 'D' })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A">A</SelectItem>
                  <SelectItem value="B">B</SelectItem>
                  <SelectItem value="C">C</SelectItem>
                  <SelectItem value="D">D</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>व्याख्या</Label>
              <Textarea
                value={iitjeeEditForm.explanation || ''}
                onChange={(e) => setIitjeeEditForm({ ...iitjeeEditForm, explanation: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIitjeeToEdit(null)}>
              रद्द करें
            </Button>
            <Button onClick={handleSaveIitjeeEdit} disabled={editingIitjee}>
              {editingIitjee && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              सहेजें
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* IIT-JEE Delete Dialog */}
      <AlertDialog open={!!iitjeeToDelete} onOpenChange={(open) => !open && setIitjeeToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>क्या आप निश्चित हैं?</AlertDialogTitle>
            <AlertDialogDescription>
              यह IIT-JEE प्रश्न स्थायी रूप से हटा दिया जाएगा। यह क्रिया पूर्ववत नहीं की जा सकती।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>रद्द करें</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteIitjee} disabled={deletingIitjee}>
              {deletingIitjee && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              हटाएं
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* 3D Structure Delete Dialog */}
      <AlertDialog open={!!threeDToDelete} onOpenChange={(open) => !open && setThreeDToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>क्या आप निश्चित हैं?</AlertDialogTitle>
            <AlertDialogDescription>
              यह 3D संरचना स्थायी रूप से हटा दी जाएगी। यह क्रिया पूर्ववत नहीं की जा सकती।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>रद्द करें</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete3DStructure} disabled={deletingThreeD}>
              {deletingThreeD && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              हटाएं
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* External Note Delete Dialog */}
      <AlertDialog open={!!externalToDelete} onOpenChange={(open) => !open && setExternalToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>क्या आप निश्चित हैं?</AlertDialogTitle>
            <AlertDialogDescription>
              यह बाहरी नोट्स स्थायी रूप से हटा दिए जाएंगे। यह क्रिया पूर्ववत नहीं की जा सकती।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>रद्द करें</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteExternalNote} disabled={deletingExternal}>
              {deletingExternal && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              हटाएं
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
