import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { getExternalNotes } from '@/db/api';
import type { ExternalNote } from '@/types/types';
import { Download, Search, Filter, Eye } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ExternalNotesPage() {
  const [notes, setNotes] = useState<ExternalNote[]>([]);
  const [loading, setLoading] = useState(true);
  const [classFilter, setClassFilter] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('');
  const [sourceFilter, setSourceFilter] = useState('');
  const [chapterFilter, setChapterFilter] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadNotes();
  }, [classFilter, subjectFilter, sourceFilter, chapterFilter]);

  const loadNotes = async () => {
    setLoading(true);
    try {
      const data = await getExternalNotes({
        class: classFilter && classFilter !== 'all' ? parseInt(classFilter) : undefined,
        subject: subjectFilter && subjectFilter !== 'all' ? subjectFilter : undefined,
        source: sourceFilter && sourceFilter !== 'all' ? sourceFilter : undefined,
        chapter: chapterFilter || undefined,
      });
      setNotes(data);
    } catch (error) {
      console.error('Error loading external notes:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredNotes = notes.filter(note =>
    note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    note.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDownload = (url: string, title: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = title;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleView = (url: string) => {
    // Open in new tab for viewing
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="container mx-auto p-4 xl:p-6 space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-2"
      >
        <h1 className="text-3xl xl:text-4xl font-bold gradient-text">📝 बाहरी नोट्स</h1>
        <p className="text-muted-foreground">अतिरिक्त अध्ययन सामग्री और नोट्स</p>
      </motion.div>

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="glass-card">
          <CardContent className="p-4 xl:p-6 space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <Filter className="h-5 w-5 text-primary" />
              <h2 className="text-lg font-semibold">फ़िल्टर</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {/* Class Filter */}
              <div className="space-y-2">
                <Label>कक्षा</Label>
                <Select value={classFilter} onValueChange={setClassFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="सभी कक्षाएं" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">सभी कक्षाएं</SelectItem>
                    {[6, 7, 8, 9, 10, 11, 12].map(cls => (
                      <SelectItem key={cls} value={cls.toString()}>
                        कक्षा {cls}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Subject Filter */}
              <div className="space-y-2">
                <Label>विषय</Label>
                <Select value={subjectFilter} onValueChange={setSubjectFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="सभी विषय" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">सभी विषय</SelectItem>
                    <SelectItem value="गणित">गणित</SelectItem>
                    <SelectItem value="विज्ञान">विज्ञान</SelectItem>
                    <SelectItem value="भौतिकी">भौतिकी</SelectItem>
                    <SelectItem value="रसायन विज्ञान">रसायन विज्ञान</SelectItem>
                    <SelectItem value="जीव विज्ञान">जीव विज्ञान</SelectItem>
                    <SelectItem value="सामाजिक विज्ञान">सामाजिक विज्ञान</SelectItem>
                    <SelectItem value="अंग्रेजी">अंग्रेजी</SelectItem>
                    <SelectItem value="हिंदी">हिंदी</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Source Filter */}
              <div className="space-y-2">
                <Label>स्रोत</Label>
                <Select value={sourceFilter} onValueChange={setSourceFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="सभी स्रोत" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">सभी स्रोत</SelectItem>
                    <SelectItem value="NCERT">NCERT</SelectItem>
                    <SelectItem value="CBSE">CBSE</SelectItem>
                    <SelectItem value="State Board">State Board</SelectItem>
                    <SelectItem value="Reference Books">Reference Books</SelectItem>
                    <SelectItem value="Other">अन्य</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Chapter Filter */}
              <div className="space-y-2">
                <Label>अध्याय</Label>
                <Input
                  placeholder="अध्याय खोजें..."
                  value={chapterFilter}
                  onChange={(e) => setChapterFilter(e.target.value)}
                />
              </div>

              {/* Search */}
              <div className="space-y-2">
                <Label>खोजें</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="शीर्षक खोजें..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Results */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="space-y-4"
      >
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <Card key={i} className="glass-card">
                <CardContent className="p-4 space-y-3">
                  <Skeleton className="h-32 w-full bg-muted" />
                  <Skeleton className="h-4 w-3/4 bg-muted" />
                  <Skeleton className="h-3 w-full bg-muted" />
                  <Skeleton className="h-3 w-2/3 bg-muted" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredNotes.length === 0 ? (
          <Card className="glass-card">
            <CardContent className="p-12 text-center">
              <div className="text-6xl mb-4">📝</div>
              <h3 className="text-xl font-semibold mb-2">कोई नोट्स नहीं मिले</h3>
              <p className="text-muted-foreground">
                कृपया अपने फ़िल्टर बदलें या बाद में पुनः प्रयास करें
              </p>
            </CardContent>
          </Card>
        ) : (
          <>
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                {filteredNotes.length} नोट्स मिले
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredNotes.map((note, index) => (
                <motion.div
                  key={note.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Card className="glass-card hover:shadow-hover transition-all duration-300 hover:-translate-y-1 group h-full">
                    <CardContent className="p-4 xl:p-6 space-y-3">
                      {/* Icon - Monochrome Lucide Icon */}
                      <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center group-hover:bg-muted/80 transition-colors duration-300">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-foreground">
                          <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/>
                          <polyline points="14 2 14 8 20 8"/>
                          <line x1="16" y1="13" x2="8" y2="13"/>
                          <line x1="16" y1="17" x2="8" y2="17"/>
                          <line x1="10" y1="9" x2="8" y2="9"/>
                        </svg>
                      </div>

                      {/* Title */}
                      <h3 className="font-semibold text-base line-clamp-2">
                        {note.title}
                      </h3>

                      {/* Metadata */}
                      <div className="flex flex-wrap gap-2 text-xs">
                        <span className="px-2 py-1 rounded-md bg-muted text-foreground">
                          कक्षा {note.class}
                        </span>
                        <span className="px-2 py-1 rounded-md bg-muted text-foreground">
                          {note.subject}
                        </span>
                        {note.source && (
                          <span className="px-2 py-1 rounded-md bg-muted text-foreground">
                            {note.source}
                          </span>
                        )}
                        {note.chapter && (
                          <span className="px-2 py-1 rounded-md bg-muted text-foreground">
                            {note.chapter}
                          </span>
                        )}
                      </div>

                      {/* Description */}
                      {note.description && (
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {note.description}
                        </p>
                      )}

                      {/* Action Buttons */}
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleView(note.file_url)}
                          className="flex-1"
                          variant="outline"
                          size="sm"
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          देखें
                        </Button>
                        <Button
                          onClick={() => handleDownload(note.file_url, note.title)}
                          className="flex-1"
                          variant="default"
                          size="sm"
                        >
                          <Download className="h-4 w-4 mr-2" />
                          डाउनलोड करें
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </>
        )}
      </motion.div>
    </div>
  );
}
