import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { getMCQQuestions, saveTestResult } from '@/db/api';
import { useAuth } from '@/contexts/AuthContext';
import { Clock, ChevronLeft, ChevronRight, Flag, Pause, Play, Grid3x3, AlertCircle } from 'lucide-react';
import type { MCQQuestion } from '@/types/types';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function TakeMCQTestPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  const { category, class: testClass, questionCount, timeLimit } = location.state || {};

  const [questions, setQuestions] = useState<MCQQuestion[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [timeRemaining, setTimeRemaining] = useState(timeLimit || 600);
  const [loading, setLoading] = useState(true);
  const [isPaused, setIsPaused] = useState(false);
  const [showSubmitDialog, setShowSubmitDialog] = useState(false);
  const [showQuestionGrid, setShowQuestionGrid] = useState(false);

  useEffect(() => {
    if (!category || !testClass) {
      navigate('/mcq-test');
      return;
    }

    loadQuestions();
  }, []);

  useEffect(() => {
    if (timeRemaining <= 0) {
      handleSubmit();
      return;
    }

    if (!isPaused) {
      const timer = setInterval(() => {
        setTimeRemaining(prev => prev - 1);
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [timeRemaining, isPaused]);

  const loadQuestions = async () => {
    setLoading(true);
    try {
      const data = await getMCQQuestions({
        category,
        class: testClass,
        limit: questionCount,
      });

      if (data.length === 0) {
        toast({
          title: 'कोई प्रश्न नहीं',
          description: 'इस कक्षा के लिए अभी तक कोई प्रश्न उपलब्ध नहीं है',
          variant: 'destructive',
        });
        navigate('/mcq-test');
        return;
      }

      setQuestions(data);
    } catch (error) {
      console.error('Error loading questions:', error);
      toast({
        title: 'त्रुटि',
        description: 'प्रश्न लोड करने में विफल',
        variant: 'destructive',
      });
      navigate('/mcq-test');
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerChange = (value: string) => {
    setAnswers(prev => ({
      ...prev,
      [questions[currentQuestion].id]: value,
    }));
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };

  const handleSubmit = async () => {
    if (!user) return;

    setShowSubmitDialog(false);

    // Calculate score
    let correctAnswers = 0;
    questions.forEach(q => {
      if (answers[q.id] === q.correct_answer) {
        correctAnswers++;
      }
    });

    const score = correctAnswers * 4; // 4 marks per question
    const totalMarks = questions.length * 4;
    const percentage = (score / totalMarks) * 100;

    try {
      await saveTestResult({
        user_id: user.id,
        category,
        class: testClass,
        subject: 'General', // Default subject
        chapter: null,
        total_questions: questions.length,
        correct_answers: correctAnswers,
        score,
        time_taken: timeLimit - timeRemaining,
        answers: answers,
      });

      navigate('/mcq-test/result', {
        state: {
          score,
          totalMarks,
          correctAnswers,
          totalQuestions: questions.length,
          percentage,
          timeTaken: timeLimit - timeRemaining,
        },
      });
    } catch (error: any) {
      console.error('Error saving test result:', error);
      toast({
        title: 'त्रुटि',
        description: error?.message || 'परिणाम सहेजने में विफल',
        variant: 'destructive',
      });
      
      // Still navigate to result page even if save fails
      navigate('/mcq-test/result', {
        state: {
          score,
          totalMarks,
          correctAnswers,
          totalQuestions: questions.length,
          percentage,
          timeTaken: timeLimit - timeRemaining,
          saveError: true,
        },
      });
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const togglePause = () => {
    setIsPaused(!isPaused);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (questions.length === 0) {
    return null;
  }

  const currentQ = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const answeredCount = Object.keys(answers).length;
  const skippedCount = questions.length - answeredCount;

  return (
    <div className="container mx-auto p-3 xl:p-6 max-w-5xl">
      {/* Improved Header with Pause and Submit */}
      <Card className="glass-card mb-4 sticky top-0 z-10 shadow-lg">
        <CardContent className="p-3 xl:p-4">
          <div className="flex flex-col xl:flex-row items-start xl:items-center justify-between gap-3">
            {/* Left: Test Info */}
            <div className="flex items-center gap-2 xl:gap-4 flex-wrap">
              <Badge variant="outline" className="text-xs xl:text-sm">
                {category}
              </Badge>
              <div className="text-xs xl:text-sm">
                <span className="font-semibold">प्रश्न:</span> {currentQuestion + 1}/{questions.length}
              </div>
            </div>

            {/* Center: Timer */}
            <div className={`flex items-center gap-2 px-3 xl:px-4 py-2 rounded-full ${
              timeRemaining < 60 ? 'bg-red-500/20 text-red-500' : 'bg-primary/20 text-primary'
            }`}>
              <Clock className="h-4 w-4" />
              <span className="font-mono font-semibold text-sm xl:text-base">{formatTime(timeRemaining)}</span>
            </div>

            {/* Right: Actions */}
            <div className="flex items-center gap-2">
              <Button
                onClick={togglePause}
                variant="outline"
                size="sm"
                className="h-9"
              >
                {isPaused ? (
                  <>
                    <Play className="h-4 w-4 mr-1" />
                    <span className="hidden sm:inline">जारी रखें</span>
                  </>
                ) : (
                  <>
                    <Pause className="h-4 w-4 mr-1" />
                    <span className="hidden sm:inline">रोकें</span>
                  </>
                )}
              </Button>

              <Sheet open={showQuestionGrid} onOpenChange={setShowQuestionGrid}>
                <SheetTrigger asChild>
                  <Button variant="outline" size="sm" className="h-9">
                    <Grid3x3 className="h-4 w-4 mr-1" />
                    <span className="hidden sm:inline">प्रश्न ग्रिड</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-full sm:max-w-md overflow-y-auto">
                  <SheetHeader>
                    <SheetTitle>प्रश्न विश्लेषण</SheetTitle>
                    <SheetDescription>
                      अपने उत्तरों की स्थिति देखें
                    </SheetDescription>
                  </SheetHeader>
                  
                  <div className="mt-6 space-y-4">
                    {/* Stats */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
                        <div className="text-2xl font-bold text-blue-600">{answeredCount}</div>
                        <div className="text-xs text-muted-foreground">उत्तर दिए गए</div>
                      </div>
                      <div className="p-3 rounded-lg bg-orange-500/10 border border-orange-500/20">
                        <div className="text-2xl font-bold text-orange-600">{skippedCount}</div>
                        <div className="text-xs text-muted-foreground">छोड़े गए</div>
                      </div>
                    </div>

                    {/* Legend */}
                    <div className="space-y-2 p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2 text-sm">
                        <div className="w-6 h-6 rounded bg-blue-500"></div>
                        <span>उत्तर दिया गया</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <div className="w-6 h-6 rounded bg-orange-500"></div>
                        <span>छोड़ा गया</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <div className="w-6 h-6 rounded bg-primary"></div>
                        <span>वर्तमान प्रश्न</span>
                      </div>
                    </div>

                    {/* Question Grid */}
                    <div className="grid grid-cols-5 gap-2">
                      {questions.map((q, index) => {
                        const isAnswered = !!answers[q.id];
                        const isCurrent = index === currentQuestion;
                        
                        return (
                          <button
                            key={index}
                            onClick={() => {
                              setCurrentQuestion(index);
                              setShowQuestionGrid(false);
                            }}
                            className={`aspect-square rounded-lg text-sm font-semibold transition-all ${
                              isCurrent
                                ? 'bg-primary text-white shadow-lg scale-110'
                                : isAnswered
                                ? 'bg-blue-500 text-white hover:bg-blue-600'
                                : 'bg-orange-500 text-white hover:bg-orange-600'
                            }`}
                          >
                            {index + 1}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </SheetContent>
              </Sheet>

              <Button
                onClick={() => setShowSubmitDialog(true)}
                size="sm"
                className="h-9 bg-green-600 hover:bg-green-700"
              >
                <Flag className="h-4 w-4 mr-1" />
                <span className="hidden sm:inline">जमा करें</span>
              </Button>
            </div>
          </div>
          <Progress value={progress} className="mt-3" />
        </CardContent>
      </Card>

      {/* Pause Overlay */}
      {isPaused && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <Card className="max-w-md mx-4">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Pause className="h-5 w-5" />
                टेस्ट रोका गया
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                टेस्ट जारी रखने के लिए "जारी रखें" बटन पर क्लिक करें
              </p>
              <Button onClick={togglePause} className="w-full">
                <Play className="h-4 w-4 mr-2" />
                जारी रखें
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Question Card */}
      <Card className="glass-card mb-4">
        <CardHeader>
          <div className="flex items-start justify-between gap-2">
            <CardTitle className="text-base xl:text-xl flex-1">
              प्रश्न {currentQuestion + 1}
            </CardTitle>
            {answers[currentQ.id] && (
              <Badge variant="secondary" className="shrink-0">
                उत्तर दिया गया
              </Badge>
            )}
          </div>
          <p className="text-sm xl:text-base mt-2">{currentQ.question}</p>
        </CardHeader>
        <CardContent className="space-y-3">
          <RadioGroup
            value={answers[currentQ.id] || ''}
            onValueChange={handleAnswerChange}
          >
            {['option_a', 'option_b', 'option_c', 'option_d'].map((optionKey, index) => {
              const optionValue = currentQ[optionKey as keyof MCQQuestion] as string;
              const optionLabel = String.fromCharCode(65 + index); // A, B, C, D

              return (
                <div
                  key={optionKey}
                  className={`flex items-center space-x-3 p-3 xl:p-4 rounded-lg border-2 transition-all cursor-pointer ${
                    answers[currentQ.id] === optionLabel
                      ? 'border-primary bg-primary/10'
                      : 'border-border hover:border-primary/50'
                  }`}
                  onClick={() => handleAnswerChange(optionLabel)}
                >
                  <RadioGroupItem value={optionLabel} id={`${optionKey}-${currentQuestion}`} />
                  <Label htmlFor={`${optionKey}-${currentQuestion}`} className="flex-1 cursor-pointer text-sm xl:text-base">
                    <span className="font-semibold mr-2">{optionLabel}.</span>
                    {optionValue}
                  </Label>
                </div>
              );
            })}
          </RadioGroup>
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex items-center justify-between gap-2 xl:gap-4">
        <Button
          onClick={handlePrevious}
          disabled={currentQuestion === 0}
          variant="outline"
          size="lg"
          className="flex-1 xl:flex-none"
        >
          <ChevronLeft className="mr-1 xl:mr-2 h-4 w-4" />
          <span className="text-sm xl:text-base">पिछला</span>
        </Button>

        <Button
          onClick={handleNext}
          disabled={currentQuestion === questions.length - 1}
          size="lg"
          className="flex-1 xl:flex-none bg-gradient-to-r from-primary to-secondary"
        >
          <span className="text-sm xl:text-base">अगला</span>
          <ChevronRight className="ml-1 xl:ml-2 h-4 w-4" />
        </Button>
      </div>

      {/* Submit Confirmation Dialog */}
      <Dialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>टेस्ट जमा करें?</DialogTitle>
            <DialogDescription className="space-y-3 pt-2">
              <div className="flex items-center gap-2 text-sm">
                <AlertCircle className="h-4 w-4 text-orange-500" />
                <span>कुल प्रश्न: {questions.length}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <AlertCircle className="h-4 w-4 text-blue-500" />
                <span>उत्तर दिए गए: {answeredCount}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <AlertCircle className="h-4 w-4 text-red-500" />
                <span>छोड़े गए: {skippedCount}</span>
              </div>
              {skippedCount > 0 && (
                <p className="text-sm text-muted-foreground mt-2">
                  आपने {skippedCount} प्रश्न छोड़ दिए हैं। क्या आप वाकई टेस्ट जमा करना चाहते हैं?
                </p>
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSubmitDialog(false)}>
              रद्द करें
            </Button>
            <Button onClick={handleSubmit} className="bg-green-600 hover:bg-green-700">
              हां, जमा करें
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
