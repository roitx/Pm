import * as React from 'react';
import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { getUserNotifications, markNotificationAsRead, deleteUserNotification, deleteAllUserNotifications, markAllNotificationsAsRead } from '@/db/api';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { Bell, CheckCircle, AlertCircle, Info, Megaphone, Trash2, Check, X } from 'lucide-react';
import { formatDate } from '@/lib/constants';
import type { UserNotification } from '@/types/types';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export default function NotificationsPage() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const { toast } = useToast();
  const [notifications, setNotifications] = useState<UserNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [notificationToDelete, setNotificationToDelete] = useState<string | null>(null);
  const [bulkDeleteDialogOpen, setBulkDeleteDialogOpen] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    if (user) {
      loadNotifications();
    }
  }, [user]);

  const loadNotifications = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const data = await getUserNotifications(user.id);
      setNotifications(data);
    } catch (error) {
      console.error('Error loading notifications:', error);
      toast({
        title: t('error'),
        description: t('notificationLoadError'),
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsRead = async (notificationId: string) => {
    if (!user) return;

    try {
      await markNotificationAsRead(user.id, notificationId);
      setNotifications(prev =>
        prev.map(n =>
          n.notification_id === notificationId ? { ...n, read: true } : n
        )
      );
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  const handleMarkAllAsRead = async () => {
    if (!user) return;

    setActionLoading(true);
    try {
      await markAllNotificationsAsRead(user.id);
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      
      // Trigger a custom event to notify Header to refresh the counter
      window.dispatchEvent(new CustomEvent('notificationsUpdated'));
      
      toast({
        title: t('success'),
        description: t('allMarkedAsRead'),
      });
    } catch (error) {
      console.error('Error marking all as read:', error);
      toast({
        title: t('error'),
        description: t('notificationUpdateError'),
        variant: 'destructive',
      });
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteClick = (notificationId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotificationToDelete(notificationId);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!user || !notificationToDelete) return;

    setActionLoading(true);
    try {
      await deleteUserNotification(user.id, notificationToDelete);
      setNotifications(prev => prev.filter(n => n.notification_id !== notificationToDelete));
      toast({
        title: t('success'),
        description: t('notificationDeleted'),
      });
    } catch (error) {
      console.error('Error deleting notification:', error);
      toast({
        title: t('error'),
        description: t('notificationDeleteError'),
        variant: 'destructive',
      });
    } finally {
      setActionLoading(false);
      setDeleteDialogOpen(false);
      setNotificationToDelete(null);
    }
  };

  const handleBulkDeleteClick = () => {
    setBulkDeleteDialogOpen(true);
  };

  const handleBulkDeleteConfirm = async () => {
    if (!user) return;

    setActionLoading(true);
    try {
      await deleteAllUserNotifications(user.id);
      setNotifications([]);
      toast({
        title: t('success'),
        description: t('allNotificationsDeleted'),
      });
    } catch (error) {
      console.error('Error deleting all notifications:', error);
      toast({
        title: t('error'),
        description: t('notificationDeleteError'),
        variant: 'destructive',
      });
    } finally {
      setActionLoading(false);
      setBulkDeleteDialogOpen(false);
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'new_content':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'exam_reminder':
        return <AlertCircle className="h-5 w-5 text-orange-500" />;
      case 'announcement':
        return <Megaphone className="h-5 w-5 text-blue-500" />;
      default:
        return <Info className="h-5 w-5 text-gray-500" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'new_content':
        return 'from-green-500/10 to-emerald-500/10';
      case 'exam_reminder':
        return 'from-orange-500/10 to-red-500/10';
      case 'announcement':
        return 'from-blue-500/10 to-cyan-500/10';
      default:
        return 'from-gray-500/10 to-slate-500/10';
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-3xl animate-float">
            <Bell className="h-8 w-8 text-white" />
          </div>
        </div>
        <h1 className="text-3xl font-bold gradient-text">{t('notificationsPageTitle')}</h1>
        <p className="text-muted-foreground">
          {t('notificationsPageSubtitle')}
        </p>
      </div>

      {/* Action Buttons */}
      {!loading && notifications.length > 0 && (
        <div className="flex flex-wrap gap-2 justify-center">
          <Button
            variant="outline"
            size="sm"
            onClick={handleMarkAllAsRead}
            disabled={actionLoading || notifications.every(n => n.read)}
            className="hover-glow"
          >
            <Check className="h-4 w-4 mr-2" />
            {t('markAllAsRead')}
          </Button>
          <Button
            variant="destructive"
            size="sm"
            onClick={handleBulkDeleteClick}
            disabled={actionLoading}
            className="hover-glow"
          >
            <Trash2 className="h-4 w-4 mr-2" />
            {t('deleteAllNotifications')}
          </Button>
        </div>
      )}

      {/* Notifications List */}
      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3, 4, 5].map((i) => (
            <Card key={i} className="glass-card">
              <CardHeader>
                <Skeleton className="h-6 w-3/4 bg-muted" />
                <Skeleton className="h-4 w-1/2 bg-muted" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-16 w-full bg-muted" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : notifications.length > 0 ? (
        <div className="space-y-4">
          {notifications.map((item) => (
            <Card
              key={item.id}
              className={`glass-card hover:shadow-hover transition-all ${
                !item.read ? 'border-l-4 border-l-primary' : ''
              }`}
            >
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div 
                    className="flex items-start gap-3 flex-1 cursor-pointer"
                    onClick={() => !item.read && handleMarkAsRead(item.notification_id)}
                  >
                    <div className={`p-3 rounded-full bg-gradient-to-br ${getNotificationColor(item.notification?.type || 'system')}`}>
                      {getNotificationIcon(item.notification?.type || 'system')}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <CardTitle className="text-lg break-words">
                          {item.notification?.title}
                        </CardTitle>
                        {!item.read && (
                          <Badge variant="default" className="text-xs shrink-0">
                            {t('newNotification')}
                          </Badge>
                        )}
                      </div>
                      <CardDescription>
                        {formatDate(item.created_at)}
                      </CardDescription>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => handleDeleteClick(item.notification_id, e)}
                    className="shrink-0 hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm break-words whitespace-pre-wrap mb-3">{item.notification?.message}</p>
                
                {/* Show Details button if feedback_details exists in metadata */}
                {item.notification?.metadata?.feedback_details && (
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        <Info className="h-4 w-4 mr-2" />
                        विवरण देखें
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-md max-h-[80vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>फीडबैक विवरण</DialogTitle>
                        <DialogDescription>
                          उपयोगकर्ता की पूरी जानकारी
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-3 mt-4">
                        <div>
                          <p className="text-sm font-medium">नाम</p>
                          <p className="text-sm text-muted-foreground">
                            {item.notification.metadata.feedback_details.user_profile?.full_name || 'N/A'}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">ईमेल</p>
                          <p className="text-sm text-muted-foreground">
                            {item.notification.metadata.feedback_details.email || 'N/A'}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">स्कूल/कॉलेज</p>
                          <p className="text-sm text-muted-foreground">
                            {item.notification.metadata.feedback_details.user_profile?.school_name || 'N/A'}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">कक्षा</p>
                          <p className="text-sm text-muted-foreground">
                            {item.notification.metadata.feedback_details.user_profile?.student_class || 'N/A'}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">शहर</p>
                          <p className="text-sm text-muted-foreground">
                            {item.notification.metadata.feedback_details.user_profile?.city || 'N/A'}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">पिनकोड</p>
                          <p className="text-sm text-muted-foreground">
                            {item.notification.metadata.feedback_details.user_profile?.pincode || 'N/A'}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">फोन</p>
                          <p className="text-sm text-muted-foreground">
                            {item.notification.metadata.feedback_details.user_profile?.phone || 'N/A'}
                          </p>
                        </div>
                        {item.notification.metadata.feedback_details.user_profile?.profile_photo_url && (
                          <div>
                            <p className="text-sm font-medium mb-2">प्रोफाइल फोटो</p>
                            <img 
                              src={item.notification.metadata.feedback_details.user_profile.profile_photo_url} 
                              alt="Profile" 
                              className="w-20 h-20 rounded-full object-cover border-2 border-border"
                            />
                          </div>
                        )}
                        <div>
                          <p className="text-sm font-medium">फीडबैक संदेश</p>
                          <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                            {item.notification.metadata.feedback_details.message}
                          </p>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="glass-card">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Bell className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">{t('noNotifications')}</h3>
            <p className="text-muted-foreground text-center">
              {t('noNotificationsDesc')}
            </p>
          </CardContent>
        </Card>
      )}

      {/* Delete Single Notification Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('deleteNotificationTitle')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('deleteNotificationDesc')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={actionLoading}>
              <X className="h-4 w-4 mr-2" />
              {t('cancel')}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              disabled={actionLoading}
              className="bg-destructive hover:bg-destructive/90"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              {actionLoading ? t('deleting') : t('delete')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Bulk Delete Dialog */}
      <AlertDialog open={bulkDeleteDialogOpen} onOpenChange={setBulkDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('deleteAllNotificationsTitle')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('deleteAllNotificationsDesc')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={actionLoading}>
              <X className="h-4 w-4 mr-2" />
              {t('cancel')}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleBulkDeleteConfirm}
              disabled={actionLoading}
              className="bg-destructive hover:bg-destructive/90"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              {actionLoading ? t('deleting') : t('delete')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
