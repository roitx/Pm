import * as React from 'react';
import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { createStudySession, getUserStudySessions, getStudyStats } from '@/db/api';
import { useAuth } from '@/contexts/AuthContext';
import { Timer, Play, Pause, RotateCcw, Clock, TrendingUp } from 'lucide-react';
import { formatDate } from '@/lib/constants';

interface StudySession {
  id: string;
  duration_minutes: number;
  subject: string | null;
  notes: string | null;
  completed: boolean;
  created_at: string;
}

export default function StudyTimerPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Timer state
  const [minutes, setMinutes] = useState(25); // Pomodoro default
  const [seconds, setSeconds] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [totalMinutes, setTotalMinutes] = useState(25);
  
  // Session details
  const [subject, setSubject] = useState('');
  const [notes, setNotes] = useState('');
  
  // History
  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [stats, setStats] = useState<{ total: number; today: number; thisWeek: number }>({
    total: 0,
    today: 0,
    thisWeek: 0,
  });
  
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (user) {
      loadSessions();
      loadStats();
    }
  }, [user]);

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        if (seconds === 0) {
          if (minutes === 0) {
            // Timer completed
            handleTimerComplete();
          } else {
            setMinutes(m => m - 1);
            setSeconds(59);
          }
        } else {
          setSeconds(s => s - 1);
        }
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning, minutes, seconds]);

  const loadSessions = async () => {
    if (!user) return;
    try {
      const data = await getUserStudySessions(user.id, 10);
      setSessions(data as StudySession[]);
    } catch (error) {
      console.error('Error loading sessions:', error);
    }
  };

  const loadStats = async () => {
    if (!user) return;
    try {
      const data = await getStudyStats(user.id, 7);
      const total = data.reduce((sum, s) => sum + s.duration_minutes, 0);
      
      const today = new Date().toDateString();
      const todayMinutes = data
        .filter(s => new Date(s.created_at).toDateString() === today)
        .reduce((sum, s) => sum + s.duration_minutes, 0);
      
      setStats({
        total,
        today: todayMinutes,
        thisWeek: total,
      });
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  };

  const handleTimerComplete = async () => {
    setIsRunning(false);
    
    // Play completion sound (optional)
    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBTGH0fPTgjMGHm7A7+OZSA0PVqzn77BdGAg+ltryxnMpBSuBzvLZiTYIGGe77OmfTRAMUKfj8LZjHAY4kdfyzHksBSR3x/DdkEAKFF606+uoVRQKRp/g8r5sIQUxh9Hz04IzBh5uwO/jmUgND1as5++wXRgIPpba8sZzKQUrgc7y2Yk2CBhnu+zpn00QDFCn4/C2YxwGOJHX8sx5LAUkd8fw3ZBAC');
    audio.play().catch(() => {});
    
    toast({
      title: '🎉 बधाई हो!',
      description: `आपने ${totalMinutes} मिनट की पढ़ाई पूरी की!`,
    });

    // Save session
    if (user) {
      try {
        await createStudySession({
          user_id: user.id,
          duration_minutes: totalMinutes,
          subject: subject || undefined,
          notes: notes || undefined,
          completed: true,
        });
        loadSessions();
        loadStats();
      } catch (error) {
        console.error('Error saving session:', error);
      }
    }

    // Reset
    setMinutes(totalMinutes);
    setSeconds(0);
  };

  const handleStart = () => {
    if (minutes === 0 && seconds === 0) {
      toast({
        title: 'त्रुटि',
        description: 'कृपया समय सेट करें',
        variant: 'destructive',
      });
      return;
    }
    setIsRunning(true);
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setIsRunning(false);
    setMinutes(totalMinutes);
    setSeconds(0);
  };

  const setPresetTime = (mins: number) => {
    setTotalMinutes(mins);
    setMinutes(mins);
    setSeconds(0);
    setIsRunning(false);
  };

  return (
    <div className="container mx-auto p-6 space-y-6 max-w-6xl">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center animate-float">
            <Timer className="h-8 w-8 text-white" />
          </div>
        </div>
        <h1 className="text-3xl font-bold gradient-text">स्टडी टाइमर</h1>
        <p className="text-muted-foreground">
          Pomodoro तकनीक से अपनी पढ़ाई को व्यवस्थित करें
        </p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Timer Card */}
        <div className="xl:col-span-2">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle>टाइमर</CardTitle>
              <CardDescription>अपना स्टडी सेशन शुरू करें</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Timer Display */}
              <div className="text-center">
                <div className="text-7xl font-bold gradient-text mb-6">
                  {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
                </div>
                
                {/* Preset Buttons */}
                <div className="flex flex-wrap justify-center gap-2 mb-6">
                  <Button
                    variant={totalMinutes === 25 ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setPresetTime(25)}
                    disabled={isRunning}
                  >
                    25 मिनट
                  </Button>
                  <Button
                    variant={totalMinutes === 45 ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setPresetTime(45)}
                    disabled={isRunning}
                  >
                    45 मिनट
                  </Button>
                  <Button
                    variant={totalMinutes === 60 ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setPresetTime(60)}
                    disabled={isRunning}
                  >
                    1 घंटा
                  </Button>
                  <Button
                    variant={totalMinutes === 90 ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setPresetTime(90)}
                    disabled={isRunning}
                  >
                    1.5 घंटे
                  </Button>
                </div>

                {/* Control Buttons */}
                <div className="flex justify-center gap-4">
                  {!isRunning ? (
                    <Button onClick={handleStart} size="lg" className="px-8">
                      <Play className="h-5 w-5 mr-2" />
                      शुरू करें
                    </Button>
                  ) : (
                    <Button onClick={handlePause} size="lg" variant="secondary" className="px-8">
                      <Pause className="h-5 w-5 mr-2" />
                      रोकें
                    </Button>
                  )}
                  <Button onClick={handleReset} size="lg" variant="outline">
                    <RotateCcw className="h-5 w-5 mr-2" />
                    रीसेट
                  </Button>
                </div>
              </div>

              {/* Session Details */}
              <div className="space-y-4 pt-6 border-t">
                <div className="space-y-2">
                  <Label htmlFor="subject">विषय (वैकल्पिक)</Label>
                  <Input
                    id="subject"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="जैसे: Physics, Mathematics"
                    disabled={isRunning}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notes">नोट्स (वैकल्पिक)</Label>
                  <Textarea
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="आज क्या पढ़ा..."
                    disabled={isRunning}
                    rows={3}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Stats & History */}
        <div className="space-y-6">
          {/* Stats Card */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                आँकड़े
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">आज</span>
                  <Badge variant="default">{stats.today} मिनट</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">इस हफ्ते</span>
                  <Badge variant="secondary">{stats.thisWeek} मिनट</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">कुल घंटे</span>
                  <Badge variant="outline">{Math.floor(stats.total / 60)} घंटे</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Sessions */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                हाल के सेशन
              </CardTitle>
            </CardHeader>
            <CardContent>
              {sessions.length > 0 ? (
                <div className="space-y-3">
                  {sessions.slice(0, 5).map((session) => (
                    <div
                      key={session.id}
                      className="flex items-center justify-between p-3 rounded-lg bg-muted/30"
                    >
                      <div className="flex-1">
                        <p className="font-medium text-sm">
                          {session.subject || 'सामान्य अध्ययन'}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {formatDate(session.created_at)}
                        </p>
                      </div>
                      <Badge variant="secondary">
                        {session.duration_minutes} मिनट
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">
                  अभी तक कोई सेशन नहीं
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
