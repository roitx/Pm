import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { motion } from 'framer-motion';
import { Calculator, Delete, Trash2 } from 'lucide-react';

export default function ScientificCalculatorPage() {
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');
  const [isRadians, setIsRadians] = useState(true);
  const [memory, setMemory] = useState(0);
  const [showMemory, setShowMemory] = useState(false);
  const [history, setHistory] = useState<string[]>([]);

  const handleNumber = (num: string) => {
    if (display === '0' || display === 'Error') {
      setDisplay(num);
    } else {
      setDisplay(display + num);
    }
  };

  const handleOperator = (op: string) => {
    setEquation(display + ' ' + op + ' ');
    setDisplay('0');
  };

  const handleFunction = (func: string) => {
    try {
      const value = parseFloat(display);
      let result: number;

      switch (func) {
        // Trigonometric Functions
        case 'sin':
          result = isRadians ? Math.sin(value) : Math.sin((value * Math.PI) / 180);
          break;
        case 'cos':
          result = isRadians ? Math.cos(value) : Math.cos((value * Math.PI) / 180);
          break;
        case 'tan':
          result = isRadians ? Math.tan(value) : Math.tan((value * Math.PI) / 180);
          break;
        case 'sec':
          result = isRadians ? 1 / Math.cos(value) : 1 / Math.cos((value * Math.PI) / 180);
          break;
        case 'csc':
          result = isRadians ? 1 / Math.sin(value) : 1 / Math.sin((value * Math.PI) / 180);
          break;
        case 'cot':
          result = isRadians ? 1 / Math.tan(value) : 1 / Math.tan((value * Math.PI) / 180);
          break;
        
        // Inverse Trigonometric Functions
        case 'asin':
          result = isRadians ? Math.asin(value) : (Math.asin(value) * 180) / Math.PI;
          break;
        case 'acos':
          result = isRadians ? Math.acos(value) : (Math.acos(value) * 180) / Math.PI;
          break;
        case 'atan':
          result = isRadians ? Math.atan(value) : (Math.atan(value) * 180) / Math.PI;
          break;
        
        // Hyperbolic Functions
        case 'sinh':
          result = Math.sinh(value);
          break;
        case 'cosh':
          result = Math.cosh(value);
          break;
        case 'tanh':
          result = Math.tanh(value);
          break;
        
        // Logarithmic Functions
        case 'log':
          result = Math.log10(value);
          break;
        case 'ln':
          result = Math.log(value);
          break;
        case 'log2':
          result = Math.log2(value);
          break;
        
        // Power and Root Functions
        case 'sqrt':
          result = Math.sqrt(value);
          break;
        case 'cbrt':
          result = Math.cbrt(value);
          break;
        case 'square':
          result = value * value;
          break;
        case 'cube':
          result = value * value * value;
          break;
        case 'pow10':
          result = Math.pow(10, value);
          break;
        case 'exp':
          result = Math.exp(value);
          break;
        
        // Other Functions
        case 'abs':
          result = Math.abs(value);
          break;
        case 'factorial':
          result = factorial(value);
          break;
        case 'reciprocal':
          result = 1 / value;
          break;
        case 'percent':
          result = value / 100;
          break;
        case 'negate':
          result = -value;
          break;
        
        default:
          result = value;
      }

      const calcString = `${func}(${value}) = ${result}`;
      addToHistory(calcString);
      setDisplay(result.toString());
    } catch (error) {
      setDisplay('Error');
    }
  };

  const factorial = (n: number): number => {
    if (n < 0) return NaN;
    if (n === 0 || n === 1) return 1;
    let result = 1;
    for (let i = 2; i <= n; i++) {
      result *= i;
    }
    return result;
  };

  const handleEquals = () => {
    try {
      if (equation) {
        const fullEquation = equation + display;
        const result = eval(fullEquation.replace(/×/g, '*').replace(/÷/g, '/'));
        addToHistory(`${fullEquation} = ${result}`);
        setDisplay(result.toString());
        setEquation('');
      }
    } catch (error) {
      setDisplay('Error');
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setEquation('');
  };

  const handleBackspace = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay('0');
    }
  };

  const addToHistory = (entry: string) => {
    setHistory(prev => [entry, ...prev].slice(0, 10));
  };

  const clearHistory = () => {
    setHistory([]);
  };

  // Memory Functions
  const memoryClear = () => {
    setMemory(0);
    setShowMemory(false);
  };

  const memoryRecall = () => {
    setDisplay(memory.toString());
  };

  const memoryAdd = () => {
    setMemory(memory + parseFloat(display));
    setShowMemory(true);
  };

  const memorySubtract = () => {
    setMemory(memory - parseFloat(display));
    setShowMemory(true);
  };

  const memoryStore = () => {
    setMemory(parseFloat(display));
    setShowMemory(true);
  };

  return (
    <div className="container mx-auto p-4 xl:p-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-6 w-6" />
              वैज्ञानिक कैलकुलेटर
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Display */}
            <div className="space-y-2">
              {equation && (
                <div className="text-sm text-muted-foreground text-right px-4 py-2 bg-muted/30 rounded-lg overflow-hidden text-ellipsis whitespace-nowrap">
                  {equation}
                </div>
              )}
              <div className="text-4xl font-bold text-right px-4 py-4 bg-muted/50 rounded-lg border-2 border-primary/20 min-h-[80px] flex items-center justify-end overflow-hidden text-ellipsis whitespace-nowrap">
                {display}
              </div>
              {showMemory && (
                <div className="text-xs text-primary text-right px-2 overflow-hidden text-ellipsis whitespace-nowrap">
                  Memory: {memory}
                </div>
              )}
            </div>

            {/* Calculator Tabs */}
            <Tabs defaultValue="basic" className="w-full">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="basic">मूल</TabsTrigger>
                <TabsTrigger value="trig">त्रिकोण</TabsTrigger>
                <TabsTrigger value="advanced">उन्नत</TabsTrigger>
                <TabsTrigger value="conversion">रूपांतरण</TabsTrigger>
                <TabsTrigger value="history">इतिहास</TabsTrigger>
              </TabsList>

              {/* Basic Calculator */}
              <TabsContent value="basic" className="space-y-2">
                <div className="grid grid-cols-4 gap-2">
                  {/* Memory Functions */}
                  <Button variant="outline" size="sm" onClick={memoryClear}>MC</Button>
                  <Button variant="outline" size="sm" onClick={memoryRecall}>MR</Button>
                  <Button variant="outline" size="sm" onClick={memoryAdd}>M+</Button>
                  <Button variant="outline" size="sm" onClick={memorySubtract}>M-</Button>
                  
                  {/* Clear and Operations */}
                  <Button variant="destructive" size="sm" onClick={handleClear}>C</Button>
                  <Button variant="outline" size="sm" onClick={handleBackspace}>
                    <Delete className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleFunction('percent')}>%</Button>
                  <Button variant="outline" size="sm" onClick={() => handleOperator('÷')}>÷</Button>

                  {/* Numbers and Operators */}
                  <Button variant="outline" onClick={() => handleNumber('7')}>7</Button>
                  <Button variant="outline" onClick={() => handleNumber('8')}>8</Button>
                  <Button variant="outline" onClick={() => handleNumber('9')}>9</Button>
                  <Button variant="outline" onClick={() => handleOperator('×')}>×</Button>

                  <Button variant="outline" onClick={() => handleNumber('4')}>4</Button>
                  <Button variant="outline" onClick={() => handleNumber('5')}>5</Button>
                  <Button variant="outline" onClick={() => handleNumber('6')}>6</Button>
                  <Button variant="outline" onClick={() => handleOperator('-')}>-</Button>

                  <Button variant="outline" onClick={() => handleNumber('1')}>1</Button>
                  <Button variant="outline" onClick={() => handleNumber('2')}>2</Button>
                  <Button variant="outline" onClick={() => handleNumber('3')}>3</Button>
                  <Button variant="outline" onClick={() => handleOperator('+')}>+</Button>

                  <Button variant="outline" onClick={() => handleFunction('negate')}>±</Button>
                  <Button variant="outline" onClick={() => handleNumber('0')}>0</Button>
                  <Button variant="outline" onClick={() => handleNumber('.')}>.</Button>
                  <Button variant="default" onClick={handleEquals}>=</Button>
                </div>

                <div className="grid grid-cols-4 gap-2 mt-4">
                  <Button variant="secondary" size="sm" onClick={() => handleFunction('sqrt')}>√</Button>
                  <Button variant="secondary" size="sm" onClick={() => handleFunction('square')}>x²</Button>
                  <Button variant="secondary" size="sm" onClick={() => handleFunction('cube')}>x³</Button>
                  <Button variant="secondary" size="sm" onClick={() => handleFunction('reciprocal')}>1/x</Button>
                  <Button variant="secondary" size="sm" onClick={() => handleFunction('abs')}>|x|</Button>
                  <Button variant="secondary" size="sm" onClick={() => handleFunction('factorial')}>n!</Button>
                  <Button variant="secondary" size="sm" onClick={memoryStore}>MS</Button>
                  <Button variant="secondary" size="sm" onClick={() => handleNumber('3.14159')}>π</Button>
                </div>
              </TabsContent>

              {/* Trigonometric Functions */}
              <TabsContent value="trig" className="space-y-2">
                <div className="flex justify-center mb-2">
                  <Button
                    variant={isRadians ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setIsRadians(!isRadians)}
                  >
                    {isRadians ? 'Radians' : 'Degrees'}
                  </Button>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <Button variant="secondary" onClick={() => handleFunction('sin')}>sin</Button>
                  <Button variant="secondary" onClick={() => handleFunction('cos')}>cos</Button>
                  <Button variant="secondary" onClick={() => handleFunction('tan')}>tan</Button>
                  
                  <Button variant="secondary" onClick={() => handleFunction('asin')}>sin⁻¹</Button>
                  <Button variant="secondary" onClick={() => handleFunction('acos')}>cos⁻¹</Button>
                  <Button variant="secondary" onClick={() => handleFunction('atan')}>tan⁻¹</Button>
                  
                  <Button variant="secondary" onClick={() => handleFunction('sec')}>sec</Button>
                  <Button variant="secondary" onClick={() => handleFunction('csc')}>csc</Button>
                  <Button variant="secondary" onClick={() => handleFunction('cot')}>cot</Button>
                  
                  <Button variant="secondary" onClick={() => handleFunction('sinh')}>sinh</Button>
                  <Button variant="secondary" onClick={() => handleFunction('cosh')}>cosh</Button>
                  <Button variant="secondary" onClick={() => handleFunction('tanh')}>tanh</Button>
                </div>
              </TabsContent>

              {/* Advanced Functions */}
              <TabsContent value="advanced" className="space-y-2">
                <div className="grid grid-cols-3 gap-2">
                  <Button variant="secondary" onClick={() => handleFunction('log')}>log</Button>
                  <Button variant="secondary" onClick={() => handleFunction('ln')}>ln</Button>
                  <Button variant="secondary" onClick={() => handleFunction('log2')}>log₂</Button>
                  
                  <Button variant="secondary" onClick={() => handleFunction('exp')}>eˣ</Button>
                  <Button variant="secondary" onClick={() => handleFunction('pow10')}>10ˣ</Button>
                  <Button variant="secondary" onClick={() => handleNumber('2.71828')}>e</Button>
                  
                  <Button variant="secondary" onClick={() => handleFunction('sqrt')}>√x</Button>
                  <Button variant="secondary" onClick={() => handleFunction('cbrt')}>∛x</Button>
                  <Button variant="secondary" onClick={() => handleOperator('^')}>xʸ</Button>
                  
                  <Button variant="secondary" onClick={() => handleFunction('square')}>x²</Button>
                  <Button variant="secondary" onClick={() => handleFunction('cube')}>x³</Button>
                  <Button variant="secondary" onClick={() => handleFunction('reciprocal')}>1/x</Button>
                  
                  <Button variant="secondary" onClick={() => handleFunction('abs')}>|x|</Button>
                  <Button variant="secondary" onClick={() => handleFunction('factorial')}>n!</Button>
                  <Button variant="secondary" onClick={() => handleNumber('3.14159')}>π</Button>
                </div>
              </TabsContent>

              {/* Conversion Tools */}
              <TabsContent value="conversion" className="space-y-4">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>तापमान रूपांतरण</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        variant="outline"
                        onClick={() => {
                          const celsius = parseFloat(display);
                          const fahrenheit = (celsius * 9/5) + 32;
                          setDisplay(fahrenheit.toString());
                          addToHistory(`${celsius}°C = ${fahrenheit}°F`);
                        }}
                      >
                        °C → °F
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => {
                          const fahrenheit = parseFloat(display);
                          const celsius = (fahrenheit - 32) * 5/9;
                          setDisplay(celsius.toString());
                          addToHistory(`${fahrenheit}°F = ${celsius}°C`);
                        }}
                      >
                        °F → °C
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>लंबाई रूपांतरण</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        variant="outline"
                        onClick={() => {
                          const km = parseFloat(display);
                          const miles = km * 0.621371;
                          setDisplay(miles.toString());
                          addToHistory(`${km} km = ${miles} miles`);
                        }}
                      >
                        km → miles
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => {
                          const miles = parseFloat(display);
                          const km = miles * 1.60934;
                          setDisplay(km.toString());
                          addToHistory(`${miles} miles = ${km} km`);
                        }}
                      >
                        miles → km
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => {
                          const meters = parseFloat(display);
                          const feet = meters * 3.28084;
                          setDisplay(feet.toString());
                          addToHistory(`${meters} m = ${feet} ft`);
                        }}
                      >
                        m → ft
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => {
                          const feet = parseFloat(display);
                          const meters = feet * 0.3048;
                          setDisplay(meters.toString());
                          addToHistory(`${feet} ft = ${meters} m`);
                        }}
                      >
                        ft → m
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>वजन रूपांतरण</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        variant="outline"
                        onClick={() => {
                          const kg = parseFloat(display);
                          const lbs = kg * 2.20462;
                          setDisplay(lbs.toString());
                          addToHistory(`${kg} kg = ${lbs} lbs`);
                        }}
                      >
                        kg → lbs
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => {
                          const lbs = parseFloat(display);
                          const kg = lbs * 0.453592;
                          setDisplay(kg.toString());
                          addToHistory(`${lbs} lbs = ${kg} kg`);
                        }}
                      >
                        lbs → kg
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>

              {/* History */}
              <TabsContent value="history" className="space-y-2">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-sm font-semibold">गणना इतिहास</h3>
                  <Button variant="ghost" size="sm" onClick={clearHistory}>
                    <Trash2 className="h-4 w-4 mr-2" />
                    साफ़ करें
                  </Button>
                </div>
                <div className="space-y-2 max-h-[400px] overflow-y-auto">
                  {history.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      कोई इतिहास नहीं
                    </p>
                  ) : (
                    history.map((entry, index) => (
                      <div
                        key={index}
                        className="p-3 bg-muted/30 rounded-lg text-sm hover:bg-muted/50 transition-colors cursor-pointer"
                        onClick={() => {
                          const result = entry.split('=')[1]?.trim();
                          if (result) setDisplay(result);
                        }}
                      >
                        {entry}
                      </div>
                    ))
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
