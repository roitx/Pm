import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Download, X } from 'lucide-react';
import { BookLogo } from '@/components/ui/BookLogo';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showPrompt, setShowPrompt] = useState(false);

  useEffect(() => {
    // चेक करें कि PWA पहले से इंस्टॉल है या नहीं
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setShowPrompt(false);
      return;
    }

    // PWA इंस्टॉल प्रॉम्प्ट को कैप्चर करें
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      
      // चेक करें कि यूजर ने पहले dismiss किया है या नहीं
      const dismissed = localStorage.getItem('pwa-install-dismissed');
      if (!dismissed) {
        // 3 सेकंड बाद प्रॉम्प्ट दिखाएं
        setTimeout(() => {
          setShowPrompt(true);
        }, 3000);
      }
    };

    window.addEventListener('beforeinstallprompt', handler);

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) {
      return;
    }

    // इंस्टॉल प्रॉम्प्ट दिखाएं
    deferredPrompt.prompt();

    // यूजर की पसंद का इंतजार करें
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      console.log('यूजर ने PWA इंस्टॉल किया');
    } else {
      console.log('यूजर ने PWA इंस्टॉल dismiss किया');
    }

    // प्रॉम्प्ट को रीसेट करें
    setDeferredPrompt(null);
    setShowPrompt(false);
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    // 7 दिनों के लिए dismiss स्टेट सेव करें
    const dismissedUntil = Date.now() + (7 * 24 * 60 * 60 * 1000);
    localStorage.setItem('pwa-install-dismissed', dismissedUntil.toString());
  };

  // अगर प्रॉम्प्ट नहीं दिखाना है तो कुछ भी रेंडर न करें
  if (!showPrompt || !deferredPrompt) {
    return null;
  }

  return (
    <div className="fixed bottom-4 left-4 right-4 xl:left-auto xl:right-4 xl:w-96 z-50 animate-in slide-in-from-bottom-5">
      <Card className="glass-card p-4 shadow-2xl border-2 border-primary/20">
        <div className="flex items-start gap-3">
          <div className="shrink-0">
            <BookLogo size={48} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-2">
              <h3 className="font-bold text-base">ऐप इंस्टॉल करें</h3>
              <Button
                variant="ghost"
                size="sm"
                className="h-6 w-6 p-0 shrink-0"
                onClick={handleDismiss}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-sm text-muted-foreground mb-3">
              PM - Roit को अपने होम स्क्रीन पर जोड़ें और ऑफलाइन भी पढ़ाई करें!
            </p>
            <Button
              onClick={handleInstallClick}
              className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90"
              size="sm"
            >
              <Download className="w-4 h-4 mr-2" />
              अभी इंस्टॉल करें
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
