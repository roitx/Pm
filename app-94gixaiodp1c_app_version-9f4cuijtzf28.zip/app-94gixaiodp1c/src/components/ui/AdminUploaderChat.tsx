import * as React from 'react';
import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import { 
  Send, 
  Loader2,
  MessageSquare,
} from 'lucide-react';
import { formatDate } from '@/lib/constants';
import type { Profile } from '@/types/types';

interface ChatMessage {
  id: string;
  sender_id: string;
  receiver_id: string;
  message: string;
  file_url: string | null;
  file_name: string | null;
  file_type: string | null;
  file_size: number | null;
  is_read: boolean;
  created_at: string;
  sender_profile?: Profile;
}

interface AdminUploaderChatProps {
  receiverId: string;
  receiverName: string;
  receiverRole: 'admin' | 'uploader';
}

export function AdminUploaderChat({ receiverId, receiverName, receiverRole }: AdminUploaderChatProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load messages
  useEffect(() => {
    if (user) {
      loadMessages();
      
      // Subscribe to real-time updates for messages between current user and receiver
      const channel = supabase
        .channel(`chat-${user.id}-${receiverId}`)
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'chat_messages',
          },
          (payload) => {
            console.log('Real-time message update:', payload);
            // Reload messages when any change occurs
            loadMessages();
          }
        )
        .subscribe((status) => {
          console.log('Subscription status:', status);
        });

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [user, receiverId]);

  // Scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadMessages = async () => {
    if (!user) {
      console.error('No user found for loading messages');
      return;
    }

    console.log('Loading messages between:', user.id, 'and', receiverId);

    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('chat_messages')
        .select(`
          *,
          sender_profile:profiles!sender_id(*)
        `)
        .or(`and(sender_id.eq.${user.id},receiver_id.eq.${receiverId}),and(sender_id.eq.${receiverId},receiver_id.eq.${user.id})`)
        .order('created_at', { ascending: true });

      console.log('Messages loaded:', { count: data?.length, error });

      if (error) {
        console.error('Error loading messages:', error);
        throw error;
      }

      setMessages(data || []);

      // Mark received messages as read
      const unreadMessages = data?.filter(
        (msg) => msg.receiver_id === user.id && !msg.is_read
      );

      if (unreadMessages && unreadMessages.length > 0) {
        console.log('Marking messages as read:', unreadMessages.length);
        await supabase
          .from('chat_messages')
          .update({ is_read: true })
          .in('id', unreadMessages.map((msg) => msg.id));
      }
    } catch (error) {
      console.error('Error loading messages:', error);
      toast({
        title: 'संदेश लोड करने में समस्या',
        description: 'कृपया पेज को रिफ्रेश करें या कुछ देर बाद पुनः प्रयास करें',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSendMessage = async () => {
    if (!user || !newMessage.trim()) return;

    setSending(true);
    try {
      // Send message
      const { error: messageError } = await supabase.from('chat_messages').insert({
        sender_id: user.id,
        receiver_id: receiverId,
        message: newMessage.trim(),
        file_url: null,
        file_name: null,
        file_type: null,
        file_size: null,
      });

      if (messageError) {
        console.error('Message send error:', messageError);
        throw messageError;
      }

      console.log('Message sent successfully');

      // Create notification for receiver
      try {
        // First, create the notification
        const { data: notification, error: notificationError } = await supabase
          .from('notifications')
          .insert({
            title: 'नया संदेश',
            message: `${receiverRole === 'admin' ? 'अपलोडर' : 'एडमिन'} ने आपको संदेश भेजा है`,
            type: 'chat',
            link: receiverRole === 'admin' ? '/admin/chat' : '/uploader/chat',
          })
          .select()
          .single();

        if (notificationError) {
          console.error('Error creating notification:', notificationError);
        } else if (notification) {
          // Then, create user_notification entry for the receiver
          const { error: userNotifError } = await supabase
            .from('user_notifications')
            .insert({
              user_id: receiverId,
              notification_id: notification.id,
            });

          if (userNotifError) {
            console.error('Error creating user notification:', userNotifError);
          }
        }
      } catch (notifError) {
        console.error('Notification error:', notifError);
        // Continue even if notification fails
      }

      setNewMessage('');

      toast({
        title: 'सफलता',
        description: 'संदेश भेज दिया गया',
      });
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: 'त्रुटि',
        description: 'संदेश भेजने में समस्या हुई। कृपया पुनः प्रयास करें।',
        variant: 'destructive',
      });
    } finally {
      setSending(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (loading) {
    return (
      <Card className="glass-card">
        <CardContent className="flex items-center justify-center h-96">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card flex flex-col h-[600px]">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10">
            <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white">
              {receiverName[0]?.toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <CardTitle className="text-lg">{receiverName}</CardTitle>
            <CardDescription className="text-xs">
              <Badge variant={receiverRole === 'admin' ? 'default' : 'outline'} className="text-xs">
                {receiverRole === 'admin' ? 'एडमिन' : 'अपलोडर'}
              </Badge>
            </CardDescription>
          </div>
          <MessageSquare className="h-5 w-5 text-muted-foreground" />
        </div>
      </CardHeader>
      <Separator />
      
      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.length === 0 ? (
            <div className="text-center py-12">
              <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground opacity-50 mb-3" />
              <p className="text-muted-foreground">कोई संदेश नहीं</p>
              <p className="text-sm text-muted-foreground mt-1">बातचीत शुरू करें</p>
            </div>
          ) : (
            messages.map((message) => {
              const isSender = message.sender_id === user?.id;
              return (
                <div
                  key={message.id}
                  className={`flex ${isSender ? 'justify-end' : 'justify-start'} group`}
                >
                  <div
                    className={`max-w-[80%] xl:max-w-[70%] rounded-lg p-3 relative ${
                      isSender
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted'
                    }`}
                  >
                    {message.message && (
                      <p className="text-sm whitespace-pre-wrap break-words">
                        {message.message}
                      </p>
                    )}
                    
                    <div className="flex items-center justify-end gap-2 mt-1">
                      <p className="text-xs opacity-70">
                        {new Date(message.created_at).toLocaleTimeString('hi-IN', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      <Separator />
      
      {/* Input */}
      <CardContent className="pt-3 pb-3">
        <div className="flex gap-2">
          <Textarea
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder="संदेश लिखें..."
            className="min-h-[40px] max-h-[120px] resize-none"
            disabled={sending}
          />
          
          <Button
            onClick={handleSendMessage}
            disabled={!newMessage.trim() || sending}
            className="shrink-0"
          >
            {sending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
