import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Flame, Calendar, TrendingUp } from 'lucide-react';

interface StudyStreak {
  currentStreak: number;
  longestStreak: number;
  lastStudyDate: string;
  totalDays: number;
}

const STREAK_KEY = 'study-streak-data';

export function StudyStreakTracker() {
  const [streak, setStreak] = useState<StudyStreak>({
    currentStreak: 0,
    longestStreak: 0,
    lastStudyDate: '',
    totalDays: 0,
  });

  useEffect(() => {
    // Load streak data
    const loadStreak = () => {
      try {
        const saved = localStorage.getItem(STREAK_KEY);
        if (saved) {
          const data = JSON.parse(saved);
          const today = new Date().toDateString();
          const lastDate = new Date(data.lastStudyDate).toDateString();
          const yesterday = new Date(Date.now() - 86400000).toDateString();

          // Check if user studied today
          if (lastDate === today) {
            setStreak(data);
          } else if (lastDate === yesterday) {
            // Continue streak
            setStreak(data);
          } else {
            // Streak broken
            setStreak({
              ...data,
              currentStreak: 0,
            });
          }
        }
      } catch (error) {
        console.error('Error loading streak:', error);
      }
    };

    loadStreak();

    // Update streak for today
    const updateStreak = () => {
      const today = new Date().toDateString();
      const saved = localStorage.getItem(STREAK_KEY);
      
      if (saved) {
        const data = JSON.parse(saved);
        const lastDate = new Date(data.lastStudyDate).toDateString();
        
        if (lastDate !== today) {
          const yesterday = new Date(Date.now() - 86400000).toDateString();
          const newStreak = lastDate === yesterday ? data.currentStreak + 1 : 1;
          
          const newData = {
            currentStreak: newStreak,
            longestStreak: Math.max(newStreak, data.longestStreak),
            lastStudyDate: new Date().toISOString(),
            totalDays: data.totalDays + 1,
          };
          
          localStorage.setItem(STREAK_KEY, JSON.stringify(newData));
          setStreak(newData);
        }
      } else {
        // First time
        const newData = {
          currentStreak: 1,
          longestStreak: 1,
          lastStudyDate: new Date().toISOString(),
          totalDays: 1,
        };
        localStorage.setItem(STREAK_KEY, JSON.stringify(newData));
        setStreak(newData);
      }
    };

    updateStreak();
  }, []);

  return (
    <Card className="glass-card border-primary/20">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg flex items-center gap-2">
              <Flame className="h-5 w-5 text-orange-500" />
              अध्ययन स्ट्रीक
            </CardTitle>
            <CardDescription>लगातार अध्ययन करें और स्ट्रीक बनाए रखें</CardDescription>
          </div>
          <Badge variant="secondary" className="text-2xl px-4 py-2 flex items-center gap-1">
            {streak.currentStreak}
            <Flame className="h-5 w-5 text-orange-500" />
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            <div>
              <p className="text-xs text-muted-foreground">सबसे लंबी स्ट्रीक</p>
              <p className="text-lg font-bold">{streak.longestStreak} दिन</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-primary" />
            <div>
              <p className="text-xs text-muted-foreground">कुल अध्ययन दिन</p>
              <p className="text-lg font-bold">{streak.totalDays} दिन</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
