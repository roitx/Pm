import * as React from 'react';
import { useState, useRef, useEffect } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { 
  X, 
  ZoomIn, 
  ZoomOut, 
  RotateCw, 
  RotateCcw,
  Download, 
  Maximize2, 
  Minimize2, 
  Loader2,
  Printer,
  Save,
  ExternalLink,
  MoreVertical,
  Hand,
  MousePointer
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';

interface ImageViewerProps {
  src: string;
  alt?: string;
  open: boolean;
  onClose: () => void;
}

export function ImageViewer({ src, alt = 'Image', open, onClose }: ImageViewerProps) {
  const [zoom, setZoom] = useState(100);
  const [rotation, setRotation] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [cursorMode, setCursorMode] = useState<'pointer' | 'hand'>('pointer');
  const [showHelpOverlay, setShowHelpOverlay] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    
    // Reset image loaded state when src changes
    setImageLoaded(false);
    
    // Show help overlay when dialog opens
    if (open) {
      setShowHelpOverlay(true);
      // Auto-hide after 3 seconds
      const timer = setTimeout(() => {
        setShowHelpOverlay(false);
      }, 3000);
      return () => {
        document.removeEventListener('fullscreenchange', handleFullscreenChange);
        clearTimeout(timer);
      };
    }
    
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, [src, open]);

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 25, 300));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 25, 50));
  };

  const handleRotateClockwise = () => {
    setRotation(prev => (prev + 90) % 360);
  };

  const handleRotateCounterclockwise = () => {
    setRotation(prev => (prev - 90 + 360) % 360);
  };

  const handleFullscreen = async () => {
    if (!document.fullscreenElement && containerRef.current) {
      try {
        await containerRef.current.requestFullscreen();
        toast({
          title: 'फुलस्क्रीन',
          description: 'फुलस्क्रीन मोड में खोला गया',
        });
      } catch (err) {
        console.error('Fullscreen error:', err);
      }
    } else if (document.fullscreenElement) {
      await document.exitFullscreen();
    }
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = src;
    link.download = alt || 'image';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: 'डाउनलोड शुरू',
      description: 'इमेज डाउनलोड हो रही है...',
    });
  };

  const handleSave = () => {
    handleDownload();
  };

  const handlePrint = () => {
    window.open(src, '_blank');
    toast({
      title: 'प्रिंट',
      description: 'नई टैब में खोलें और प्रिंट करें',
    });
  };

  const handleOpenInNewTab = () => {
    window.open(src, '_blank');
  };

  const toggleCursorMode = () => {
    setCursorMode(prev => prev === 'pointer' ? 'hand' : 'pointer');
    toast({
      title: 'कर्सर मोड',
      description: cursorMode === 'pointer' ? 'हैंड टूल' : 'पॉइंटर टूल',
    });
  };

  const handleClose = () => {
    if (document.fullscreenElement) {
      document.exitFullscreen();
    }
    setZoom(100);
    setRotation(0);
    onClose();
  };

  const handleReset = () => {
    setZoom(100);
    setRotation(0);
    toast({
      title: 'रीसेट',
      description: 'इमेज रीसेट की गई',
    });
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent 
        ref={containerRef}
        className="max-w-[95vw] max-h-[95vh] p-0 overflow-hidden bg-black/95"
      >
        {/* Toolbar - Always visible with high z-index */}
        <div className="absolute top-0 left-0 right-0 z-50 bg-background/98 backdrop-blur-md border-b border-border p-3 flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2 flex-wrap">
            <Button
              variant="secondary"
              size="icon"
              onClick={handleZoomOut}
              disabled={zoom <= 50}
              title="ज़ूम आउट"
              className="h-9 w-9"
            >
              <ZoomOut className="h-5 w-5" />
            </Button>
            <span className="text-sm font-bold min-w-[60px] text-center bg-muted px-3 py-1 rounded">
              {zoom}%
            </span>
            <Button
              variant="secondary"
              size="icon"
              onClick={handleZoomIn}
              disabled={zoom >= 300}
              title="ज़ूम इन"
              className="h-9 w-9"
            >
              <ZoomIn className="h-5 w-5" />
            </Button>
            <div className="w-px h-6 bg-border mx-1" />
            <Button
              variant="secondary"
              size="icon"
              onClick={handleRotateClockwise}
              title="दक्षिणावर्त घुमाएं"
              className="h-9 w-9"
            >
              <RotateCw className="h-5 w-5" />
            </Button>
            <Button
              variant="secondary"
              size="icon"
              onClick={handleRotateCounterclockwise}
              title="वामावर्त घुमाएं"
              className="h-9 w-9"
            >
              <RotateCcw className="h-5 w-5" />
            </Button>
            <div className="w-px h-6 bg-border mx-1" />
            <Button
              variant="secondary"
              size="icon"
              onClick={handleFullscreen}
              title={isFullscreen ? 'फुलस्क्रीन से बाहर निकलें' : 'फुलस्क्रीन'}
              className="h-9 w-9"
            >
              {isFullscreen ? (
                <Minimize2 className="h-5 w-5" />
              ) : (
                <Maximize2 className="h-5 w-5" />
              )}
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={handleReset}
              title="रीसेट करें"
              className="h-9 px-3"
            >
              रीसेट
            </Button>
            <div className="w-px h-6 bg-border mx-1" />
            <Button
              variant="secondary"
              size="icon"
              onClick={handleDownload}
              title="डाउनलोड करें"
              className="h-9 w-9"
            >
              <Download className="h-5 w-5" />
            </Button>
            
            {/* More Options Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="secondary" size="icon" className="h-9 w-9">
                  <MoreVertical className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem onClick={handleOpenInNewTab}>
                  <ExternalLink className="mr-2 h-4 w-4" />
                  <span>Open</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handlePrint}>
                  <Printer className="mr-2 h-4 w-4" />
                  <span>Print</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleSave}>
                  <Save className="mr-2 h-4 w-4" />
                  <span>Save</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleRotateClockwise}>
                  <RotateCw className="mr-2 h-4 w-4" />
                  <span>Rotate Clockwise</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleRotateCounterclockwise}>
                  <RotateCcw className="mr-2 h-4 w-4" />
                  <span>Rotate Counterclockwise</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={toggleCursorMode}>
                  {cursorMode === 'pointer' ? (
                    <>
                      <Hand className="mr-2 h-4 w-4" />
                      <span>Hand Tool</span>
                    </>
                  ) : (
                    <>
                      <MousePointer className="mr-2 h-4 w-4" />
                      <span>Pointer Tool</span>
                    </>
                  )}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleClose}
            title="बंद करें"
            className="h-9 w-9"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Image Container */}
        <div 
          className="w-full h-[calc(95vh-60px)] mt-[60px] flex items-center justify-center overflow-auto bg-muted/20"
          style={{
            cursor: cursorMode === 'hand' ? 'grab' : 'default',
          }}
        >
          {!imageLoaded && (
            <div className="absolute inset-0 flex items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          )}
          <img
            src={src}
            alt={alt}
            onLoad={() => setImageLoaded(true)}
            onError={() => setImageLoaded(true)}
            className={`max-w-full max-h-full object-contain transition-all duration-300 ${!imageLoaded ? 'opacity-0' : 'opacity-100'}`}
            style={{
              transform: `scale(${zoom / 100}) rotate(${rotation}deg)`,
            }}
            loading="eager"
          />
          
          {/* Help Overlay - Shows controls hint */}
          {showHelpOverlay && imageLoaded && (
            <div 
              className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-40 animate-in fade-in duration-300"
              onClick={() => setShowHelpOverlay(false)}
            >
              <div className="bg-background/95 backdrop-blur-md rounded-lg p-6 max-w-md mx-4 shadow-2xl border-2 border-primary">
                <div className="text-center space-y-4">
                  <div className="flex items-center justify-center gap-2">
                    <Maximize2 className="h-6 w-6 text-primary" />
                    <h3 className="text-lg font-bold">इमेज व्यूअर नियंत्रण</h3>
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p className="flex items-center gap-2">
                      <ZoomIn className="h-4 w-4 text-primary" />
                      <span>ज़ूम इन/आउट करें</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <RotateCw className="h-4 w-4 text-primary" />
                      <span>इमेज घुमाएं</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <Maximize2 className="h-4 w-4 text-primary" />
                      <span>फुलस्क्रीन मोड</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <Download className="h-4 w-4 text-primary" />
                      <span>डाउनलोड करें</span>
                    </p>
                  </div>
                  <p className="text-xs text-muted-foreground mt-4">
                    ऊपर टूलबार में सभी नियंत्रण उपलब्ध हैं
                  </p>
                  <Button 
                    onClick={() => setShowHelpOverlay(false)}
                    className="w-full"
                    size="sm"
                  >
                    समझ गया
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
