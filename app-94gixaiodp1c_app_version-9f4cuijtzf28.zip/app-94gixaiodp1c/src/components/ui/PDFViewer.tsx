import * as React from 'react';
import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Download,
  Loader2,
  FileText,
  ExternalLink,
  Printer,
  Save,
  Presentation,
  MoreVertical,
  RotateCw,
  RotateCcw,
  ChevronsUp,
  ChevronsDown,
  Hand,
  MousePointer,
  AlignJustify,
  AlignLeft,
  ZoomIn,
  ZoomOut
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';

interface PDFViewerProps {
  url: string;
  title?: string;
  onClose?: () => void;
  embedded?: boolean;
}

export function PDFViewer({ url, title, embedded = true }: PDFViewerProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [zoom, setZoom] = useState(100);
  const [scrollMode, setScrollMode] = useState<'vertical' | 'page'>('vertical');
  const [cursorMode, setCursorMode] = useState<'text' | 'hand'>('text');
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const { toast } = useToast();

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = url;
    link.download = title || 'document.pdf';
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: 'डाउनलोड शुरू',
      description: 'फ़ाइल डाउनलोड हो रही है...',
    });
  };

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 25, 300));
    toast({
      title: 'ज़ूम इन',
      description: `${Math.min(zoom + 25, 300)}% ज़ूम`,
    });
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 25, 50));
    toast({
      title: 'ज़ूम आउट',
      description: `${Math.max(zoom - 25, 50)}% ज़ूम`,
    });
  };

  const handleSave = () => {
    handleDownload();
  };

  const handlePrint = () => {
    window.open(url, '_blank');
    toast({
      title: 'प्रिंट',
      description: 'नई टैब में खोलें और प्रिंट करें',
    });
  };

  const handleOpenInNewTab = () => {
    window.open(url, '_blank');
  };

  const handlePresentationMode = () => {
    if (iframeRef.current) {
      iframeRef.current.requestFullscreen();
    }
    toast({
      title: 'प्रेजेंटेशन मोड',
      description: 'फुलस्क्रीन मोड में खोला गया',
    });
  };

  const handleRotateClockwise = () => {
    setRotation((prev) => (prev + 90) % 360);
    toast({
      title: 'घुमाया गया',
      description: 'दक्षिणावर्त घुमाया गया',
    });
  };

  const handleRotateCounterclockwise = () => {
    setRotation((prev) => (prev - 90 + 360) % 360);
    toast({
      title: 'घुमाया गया',
      description: 'वामावर्त घुमाया गया',
    });
  };

  const handleGoToFirstPage = () => {
    toast({
      title: 'पहला पेज',
      description: 'पहले पेज पर जाएं',
    });
  };

  const handleGoToLastPage = () => {
    toast({
      title: 'अंतिम पेज',
      description: 'अंतिम पेज पर जाएं',
    });
  };

  const handleCurrentPage = () => {
    toast({
      title: 'वर्तमान पेज',
      description: 'वर्तमान पेज पर हैं',
    });
  };

  const toggleScrollMode = () => {
    setScrollMode((prev) => (prev === 'vertical' ? 'page' : 'vertical'));
    toast({
      title: 'स्क्रॉल मोड',
      description: scrollMode === 'vertical' ? 'पेज स्क्रॉलिंग' : 'वर्टिकल स्क्रॉलिंग',
    });
  };

  const toggleCursorMode = () => {
    setCursorMode((prev) => (prev === 'text' ? 'hand' : 'text'));
    toast({
      title: 'कर्सर मोड',
      description: cursorMode === 'text' ? 'हैंड टूल' : 'टेक्स्ट सिलेक्शन टूल',
    });
  };

  const handleLoad = () => {
    setLoading(false);
    setError(false);
  };

  const handleError = () => {
    setLoading(false);
    setError(true);
  };

  // सुधारित PDF व्यूअर - सीधे PDF.js का उपयोग करें (बेहतर विश्वसनीयता)
  // Improved PDF Viewer - Use PDF.js directly for better reliability
  const [useFallback, setUseFallback] = React.useState(false);

  React.useEffect(() => {
    // Reset fallback when URL changes
    setUseFallback(false);
    setLoading(true);
    setError(false);
  }, [url]);

  const handleIframeError = () => {
    console.log('PDF viewer error, trying fallback...', { useFallback });
    
    if (!useFallback) {
      // Fallback: Try direct URL
      setUseFallback(true);
      setLoading(true);
      setError(false);
    } else {
      // All methods failed
      handleError();
    }
  };

  // Primary: Mozilla PDF.js (most reliable)
  const pdfJsViewer = `https://mozilla.github.io/pdf.js/web/viewer.html?file=${encodeURIComponent(url)}`;
  // Fallback: Direct URL
  const directUrl = url;

  const viewerSrc = useFallback ? directUrl : pdfJsViewer;

  return (
    <div className={embedded ? "flex flex-col h-[70vh] overflow-hidden border rounded-lg bg-card" : "fixed inset-0 z-50 bg-background flex flex-col"}>
      {/* Toolbar */}
      <div className="border-b shrink-0 p-3 flex items-center justify-between gap-2 bg-muted/30">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <FileText className="h-5 w-5 text-primary shrink-0" />
          <h3 className="font-semibold truncate text-sm xl:text-base">
            {title || 'PDF दस्तावेज़'}
          </h3>
        </div>
        <div className="flex items-center gap-2 shrink-0 flex-wrap">
          {/* Zoom Controls */}
          <div className="flex items-center gap-1 border rounded-md p-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleZoomOut}
              disabled={zoom <= 50}
              className="h-7 w-7"
              title="ज़ूम आउट"
            >
              <ZoomOut className="h-4 w-4" />
            </Button>
            <span className="text-xs font-medium min-w-[45px] text-center px-1">
              {zoom}%
            </span>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleZoomIn}
              disabled={zoom >= 300}
              className="h-7 w-7"
              title="ज़ूम इन"
            >
              <ZoomIn className="h-4 w-4" />
            </Button>
          </div>
          
          <Button
            variant="outline"
            size="sm"
            onClick={handleOpenInNewTab}
            className="h-8"
            title="नई टैब में खोलें"
          >
            <ExternalLink className="h-4 w-4 xl:mr-2" />
            <span className="hidden xl:inline">खोलें</span>
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleDownload}
            className="h-8"
            title="डाउनलोड करें"
          >
            <Download className="h-4 w-4 xl:mr-2" />
            <span className="hidden xl:inline">डाउनलोड</span>
          </Button>
          
          {/* More Options Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-8">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuItem onClick={handleOpenInNewTab}>
                <ExternalLink className="mr-2 h-4 w-4" />
                <span>Open</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handlePrint}>
                <Printer className="mr-2 h-4 w-4" />
                <span>Print</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleSave}>
                <Save className="mr-2 h-4 w-4" />
                <span>Save</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handlePresentationMode}>
                <Presentation className="mr-2 h-4 w-4" />
                <span>Presentation Mode</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleCurrentPage}>
                <FileText className="mr-2 h-4 w-4" />
                <span>Current Page</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleGoToFirstPage}>
                <ChevronsUp className="mr-2 h-4 w-4" />
                <span>Go to First Page</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleGoToLastPage}>
                <ChevronsDown className="mr-2 h-4 w-4" />
                <span>Go to Last Page</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleRotateClockwise}>
                <RotateCw className="mr-2 h-4 w-4" />
                <span>Rotate Clockwise</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleRotateCounterclockwise}>
                <RotateCcw className="mr-2 h-4 w-4" />
                <span>Rotate Counterclockwise</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={toggleCursorMode}>
                {cursorMode === 'text' ? (
                  <>
                    <Hand className="mr-2 h-4 w-4" />
                    <span>Hand Tool</span>
                  </>
                ) : (
                  <>
                    <MousePointer className="mr-2 h-4 w-4" />
                    <span>Text Selection Tool</span>
                  </>
                )}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={toggleScrollMode}>
                {scrollMode === 'vertical' ? (
                  <>
                    <AlignJustify className="mr-2 h-4 w-4" />
                    <span>Page Scrolling</span>
                  </>
                ) : (
                  <>
                    <AlignLeft className="mr-2 h-4 w-4" />
                    <span>Vertical Scrolling</span>
                  </>
                )}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* PDF Viewer */}
      <div className="flex-1 relative bg-muted/20 overflow-hidden">
        {loading && !error && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-background/80 z-10">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-sm text-muted-foreground">PDF लोड हो रहा है...</p>
          </div>
        )}
        
        {error ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 p-6">
            <FileText className="h-16 w-16 text-muted-foreground" />
            <div className="text-center space-y-2">
              <h3 className="text-lg font-semibold">PDF व्यूअर लोड नहीं हो सका</h3>
              <p className="text-sm text-muted-foreground max-w-md">
                कृपया फ़ाइल को नई टैब में खोलें या डाउनलोड करें
              </p>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleOpenInNewTab} variant="outline">
                <ExternalLink className="h-4 w-4 mr-2" />
                नई टैब में खोलें
              </Button>
              <Button onClick={handleDownload}>
                <Download className="h-4 w-4 mr-2" />
                डाउनलोड करें
              </Button>
            </div>
          </div>
        ) : (
          <div 
            className="w-full h-full overflow-auto"
            style={{
              transform: `rotate(${rotation}deg) scale(${zoom / 100})`,
              transition: 'transform 0.3s ease',
              cursor: cursorMode === 'hand' ? 'grab' : 'text',
            }}
          >
            <iframe
              ref={iframeRef}
              src={viewerSrc}
              className="w-full h-full border-0"
              title={title || 'PDF दस्तावेज़'}
              onLoad={handleLoad}
              onError={handleIframeError}
              allow="fullscreen"
            />
          </div>
        )}
      </div>
    </div>
  );
}
