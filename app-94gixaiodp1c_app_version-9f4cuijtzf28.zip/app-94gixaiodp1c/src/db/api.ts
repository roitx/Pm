import { supabase } from './supabase';
import type {
  Profile,
  Content,
  MCQQuestion,
  TestResult,
  Notification,
  UserNotification,
  RecentlyViewed,
  Download,
  ContentFilter,
  TestConfig,
  PremiumFeature,
  UserFeatureUsage,
  APKFile,
  ThreeDStructure,
  ExternalNote,
} from '@/types/types';

// ============ Profile APIs ============

export async function getProfile(userId: string) {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();
  
  if (error) throw error;
  return data as Profile | null;
}

export async function updateProfile(userId: string, updates: Partial<Profile>) {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as Profile;
}

export async function getAllProfiles() {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function updateUserRole(userId: string, role: 'user' | 'admin' | 'uploader') {
  const { error } = await supabase
    .from('profiles')
    .update({ role })
    .eq('id', userId);

  if (error) throw error;
}

// ============ Content APIs ============

export async function getContent(filter: ContentFilter = {}) {
  let query = supabase.from('content').select('*');
  
  if (filter.category) query = query.eq('category', filter.category);
  if (filter.class) query = query.eq('class', filter.class);
  if (filter.subject) query = query.eq('subject', filter.subject);
  if (filter.chapter) query = query.eq('chapter', filter.chapter);
  if (filter.search) query = query.ilike('title', `%${filter.search}%`);
  
  const { data, error } = await query.order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getContentById(id: string) {
  const { data, error } = await supabase
    .from('content')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  
  if (error) throw error;
  return data as Content | null;
}

export async function createContent(content: Omit<Content, 'id' | 'created_at' | 'updated_at'>) {
  const { data, error } = await supabase
    .from('content')
    .insert(content)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as Content;
}

export async function updateContent(id: string, updates: Partial<Content>) {
  const { data, error } = await supabase
    .from('content')
    .update(updates)
    .eq('id', id)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as Content;
}

export async function deleteContent(id: string) {
  const { error } = await supabase
    .from('content')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
}

export async function getSubjects(category: string, classNum: number) {
  const { data, error } = await supabase
    .from('content')
    .select('subject')
    .eq('category', category)
    .eq('class', classNum);
  
  if (error) throw error;
  const subjects = Array.isArray(data) ? [...new Set(data.map(item => item.subject))] : [];
  return subjects;
}

export async function getChapters(category: string, classNum: number, subject: string) {
  const { data, error } = await supabase
    .from('content')
    .select('chapter')
    .eq('category', category)
    .eq('class', classNum)
    .eq('subject', subject);
  
  if (error) throw error;
  const chapters = Array.isArray(data) ? [...new Set(data.map(item => item.chapter))] : [];
  return chapters;
}

// ============ MCQ APIs ============

export async function getMCQQuestions(config: Partial<TestConfig> & { category: string; class: number; limit?: number }) {
  let query = supabase
    .from('mcq_questions')
    .select('*')
    .eq('category', config.category)
    .eq('class', config.class);
  
  // केवल तभी फ़िल्टर करें जब मान मौजूद हो और 'all' न हो
  if (config.subject && config.subject !== 'all') {
    query = query.eq('subject', config.subject);
  }
  if (config.chapter && config.chapter !== 'all') {
    query = query.eq('chapter', config.chapter);
  }
  if (config.difficulty && config.difficulty !== 'all' as any) {
    query = query.eq('difficulty', config.difficulty);
  }
  
  const limit = config.limit || config.questionCount || 10;
  const { data, error } = await query.limit(limit);
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function createMCQQuestion(question: Omit<MCQQuestion, 'id' | 'created_at'>) {
  const { data, error } = await supabase
    .from('mcq_questions')
    .insert(question)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as MCQQuestion;
}

export async function updateMCQQuestion(id: string, updates: Partial<MCQQuestion>) {
  const { data, error } = await supabase
    .from('mcq_questions')
    .update(updates)
    .eq('id', id)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as MCQQuestion;
}

export async function deleteMCQQuestion(id: string) {
  const { error } = await supabase
    .from('mcq_questions')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
}

// Delete user profile
export async function deleteUserProfile(userId: string) {
  const { error } = await supabase
    .from('profiles')
    .delete()
    .eq('id', userId);
  
  if (error) throw error;
}

// Bulk delete user profiles
export async function bulkDeleteUserProfiles(userIds: string[]) {
  const { error } = await supabase
    .from('profiles')
    .delete()
    .in('id', userIds);
  
  if (error) throw error;
}

// ============ Test Results APIs ============

export async function saveTestResult(result: Omit<TestResult, 'id' | 'created_at'>) {
  const { data, error } = await supabase
    .from('test_results')
    .insert(result)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as TestResult;
}

export async function getUserTestResults(userId: string) {
  const { data, error } = await supabase
    .from('test_results')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getTestHistory(userId: string) {
  const { data, error } = await supabase
    .from('test_results')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getAllTestResults() {
  const { data, error } = await supabase
    .from('test_results')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

// ============ Notifications APIs ============

// Get latest motivational message for home page
export async function getLatestMotivation(): Promise<string> {
  const { data, error } = await supabase
    .from('notifications')
    .select('message')
    .eq('type', 'system')
    .ilike('title', '%प्रेरक विचार%')
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    console.error('Error fetching motivation:', error);
    return 'सफलता का रहस्य है - कभी हार न मानना। हर दिन एक नया अवसर है सीखने और बढ़ने का।';
  }

  return data?.message || 'सफलता का रहस्य है - कभी हार न मानना। हर दिन एक नया अवसर है सीखने और बढ़ने का।';
}

export async function createNotification(notification: Omit<Notification, 'id' | 'created_at'>) {
  const { data, error } = await supabase
    .from('notifications')
    .insert(notification)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as Notification;
}

export async function getNotifications() {
  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getUserNotifications(userId: string) {
  const { data, error } = await supabase
    .from('user_notifications')
    .select('*, notification:notifications(*)')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function markNotificationAsRead(userId: string, notificationId: string) {
  const { error } = await supabase
    .from('user_notifications')
    .upsert({
      user_id: userId,
      notification_id: notificationId,
      read: true,
    });
  
  if (error) throw error;
}

export async function deleteUserNotification(userId: string, notificationId: string) {
  const { error } = await supabase
    .from('user_notifications')
    .delete()
    .eq('user_id', userId)
    .eq('notification_id', notificationId);
  
  if (error) throw error;
}

export async function deleteAllUserNotifications(userId: string) {
  const { error } = await supabase
    .from('user_notifications')
    .delete()
    .eq('user_id', userId);
  
  if (error) throw error;
}

export async function markAllNotificationsAsRead(userId: string) {
  const { error } = await supabase
    .from('user_notifications')
    .update({ read: true })
    .eq('user_id', userId)
    .eq('read', false);
  
  if (error) throw error;
}

// ============ Recently Viewed APIs ============

export async function addRecentlyViewed(userId: string, contentId: string) {
  const { error } = await supabase
    .from('recently_viewed')
    .upsert({
      user_id: userId,
      content_id: contentId,
      viewed_at: new Date().toISOString(),
    });
  
  if (error) throw error;
}

export async function getRecentlyViewed(userId: string, limit = 10) {
  const { data, error } = await supabase
    .from('recently_viewed')
    .select('*, content:content!recently_viewed_content_id_fkey(*)')
    .eq('user_id', userId)
    .order('viewed_at', { ascending: false })
    .limit(limit);
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

// ============ Downloads APIs ============

export async function addDownload(userId: string, contentId: string) {
  const { error } = await supabase
    .from('downloads')
    .insert({
      user_id: userId,
      content_id: contentId,
    });
  
  if (error) throw error;
}

export async function getRecentDownloads(userId: string, limit = 10) {
  const { data, error } = await supabase
    .from('downloads')
    .select('*, content:content!downloads_content_id_fkey(*)')
    .eq('user_id', userId)
    .order('downloaded_at', { ascending: false })
    .limit(limit);
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

// ============ Storage APIs ============

export async function uploadFile(bucket: string, path: string, file: File) {
  // Extract the desired filename from the path
  const filename = path.split('/').pop() || file.name;
  
  // Create a new File object with the correct filename
  const renamedFile = new File([file], filename, { type: file.type });
  
  const { data, error } = await supabase.storage
    .from(bucket)
    .upload(path, renamedFile, {
      upsert: true,
    });
  
  if (error) throw error;
  
  const { data: urlData } = supabase.storage
    .from(bucket)
    .getPublicUrl(data.path);
  
  return urlData.publicUrl;
}

export async function deleteFile(bucket: string, path: string) {
  const { error } = await supabase.storage
    .from(bucket)
    .remove([path]);
  
  if (error) throw error;
}

export function getPublicUrl(bucket: string, path: string) {
  const { data } = supabase.storage
    .from(bucket)
    .getPublicUrl(path);
  
  return data.publicUrl;
}

// ============ AI Chat History APIs ============

export async function saveAIChatMessage(userId: string, message: string, response: string, sessionId?: string) {
  const { data, error } = await supabase
    .from('ai_chat_history')
    .insert({
      user_id: userId,
      message,
      response,
      session_id: sessionId || null,
    })
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function getAIChatHistory(userId: string, sessionId?: string, limit: number = 50) {
  let query = supabase
    .from('ai_chat_history')
    .select('*')
    .eq('user_id', userId);
  
  if (sessionId) {
    query = query.eq('session_id', sessionId);
  } else {
    // Get messages without session_id (legacy messages)
    query = query.is('session_id', null);
  }
  
  const { data, error } = await query
    .order('created_at', { ascending: false })
    .limit(limit);
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function clearAIChatHistory(userId: string, sessionId?: string) {
  let query = supabase
    .from('ai_chat_history')
    .delete()
    .eq('user_id', userId);
  
  if (sessionId) {
    query = query.eq('session_id', sessionId);
  }
  
  const { error } = await query;
  
  if (error) throw error;
}

// ============ AI Chat Sessions APIs ============

export async function createChatSession(userId: string, title: string = 'नई बातचीत') {
  const { data, error } = await supabase
    .from('ai_chat_sessions')
    .insert({
      user_id: userId,
      title,
    })
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function getChatSessions(userId: string) {
  const { data, error } = await supabase
    .from('ai_chat_sessions')
    .select('*')
    .eq('user_id', userId)
    .order('updated_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function updateChatSession(sessionId: string, updates: { title?: string; updated_at?: string }) {
  const { data, error } = await supabase
    .from('ai_chat_sessions')
    .update(updates)
    .eq('id', sessionId)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function deleteChatSession(sessionId: string) {
  const { error } = await supabase
    .from('ai_chat_sessions')
    .delete()
    .eq('id', sessionId);
  
  if (error) throw error;
}

// ============ Password Recovery APIs ============

export async function recoverPassword(studentClass: string, phone: string) {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, username, full_name, student_class, phone')
    .eq('student_class', studentClass)
    .eq('phone', phone)
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function recoverPasswordByPhonePincode(phone: string, pincode: string) {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, username, full_name, phone, pincode')
    .eq('phone', phone)
    .eq('pincode', pincode)
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

// ============ Leaderboard with Pincode Filter ============

export async function getLeaderboardByPincode(pincode?: string) {
  let query = supabase
    .from('profiles')
    .select('id, full_name, email, total_points, pincode')
    .order('total_points', { ascending: false })
    .limit(100);
  
  if (pincode) {
    query = query.eq('pincode', pincode);
  }
  
  const { data, error } = await query;
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

// ============ Bookmarks APIs ============

export async function addBookmark(userId: string, contentId: string) {
  const { error } = await supabase
    .from('bookmarks')
    .insert({
      user_id: userId,
      content_id: contentId,
    });
  
  if (error) throw error;
}

export async function removeBookmark(userId: string, contentId: string) {
  const { error } = await supabase
    .from('bookmarks')
    .delete()
    .eq('user_id', userId)
    .eq('content_id', contentId);
  
  if (error) throw error;
}

export async function getUserBookmarks(userId: string) {
  const { data, error } = await supabase
    .from('bookmarks')
    .select('*, content:content!bookmarks_content_id_fkey(*)')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function isBookmarked(userId: string, contentId: string) {
  const { data, error } = await supabase
    .from('bookmarks')
    .select('id')
    .eq('user_id', userId)
    .eq('content_id', contentId)
    .maybeSingle();
  
  if (error) throw error;
  return !!data;
}

// ============ Study Sessions APIs ============

export async function createStudySession(session: {
  user_id: string;
  duration_minutes: number;
  subject?: string;
  notes?: string;
  completed?: boolean;
}) {
  const { data, error } = await supabase
    .from('study_sessions')
    .insert(session)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function getUserStudySessions(userId: string, limit = 50) {
  const { data, error } = await supabase
    .from('study_sessions')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(limit);
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getStudyStats(userId: string, days = 7) {
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);
  
  const { data, error } = await supabase
    .from('study_sessions')
    .select('duration_minutes, subject, created_at')
    .eq('user_id', userId)
    .gte('created_at', startDate.toISOString())
    .eq('completed', true);
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

// ============ Doubts APIs ============

export async function createDoubt(doubt: {
  user_id: string;
  title: string;
  description: string;
  subject?: string;
  class?: number;
}) {
  const { data, error } = await supabase
    .from('doubts')
    .insert(doubt)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function getUserDoubts(userId: string) {
  const { data, error } = await supabase
    .from('doubts')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getAllDoubts() {
  const { data, error } = await supabase
    .from('doubts')
    .select(`
      *,
      user:profiles!doubts_user_id_fkey(full_name, email),
      answerer:profiles!doubts_answered_by_fkey(full_name)
    `)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function answerDoubt(doubtId: string, answer: string, answeredBy: string) {
  const { data, error } = await supabase
    .from('doubts')
    .update({
      answer,
      answered_by: answeredBy,
      answered_at: new Date().toISOString(),
      status: 'answered',
    })
    .eq('id', doubtId)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function updateDoubtStatus(doubtId: string, status: 'pending' | 'answered' | 'closed') {
  const { error } = await supabase
    .from('doubts')
    .update({ status })
    .eq('id', doubtId);
  
  if (error) throw error;
}

// ============ Analytics APIs (Admin) ============

export async function getContentAnalytics() {
  // Get most viewed content
  const { data: viewsData, error: viewsError } = await supabase
    .from('recently_viewed')
    .select('content_id, content:content!recently_viewed_content_id_fkey(title, category)')
    .order('viewed_at', { ascending: false })
    .limit(100);
  
  if (viewsError) throw viewsError;
  
  // Get most downloaded content
  const { data: downloadsData, error: downloadsError } = await supabase
    .from('downloads')
    .select('content_id, content:content!downloads_content_id_fkey(title, category)')
    .order('downloaded_at', { ascending: false })
    .limit(100);
  
  if (downloadsError) throw downloadsError;
  
  return {
    views: Array.isArray(viewsData) ? viewsData : [],
    downloads: Array.isArray(downloadsData) ? downloadsData : [],
  };
}

export async function getUserActivityStats() {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, full_name, email, student_class, created_at');
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

// ============ Premium Features APIs ============

export async function getAllPremiumFeatures() {
  const { data, error } = await supabase
    .from('premium_features')
    .select('*')
    .order('created_at', { ascending: true });
  
  if (error) throw error;
  return Array.isArray(data) ? (data as PremiumFeature[]) : [];
}

export async function updatePremiumFeature(id: string, updates: Partial<PremiumFeature>) {
  const { data, error } = await supabase
    .from('premium_features')
    .update(updates)
    .eq('id', id)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as PremiumFeature;
}

export async function checkFeatureAccess(userId: string, featureKey: string) {
  const { data, error } = await supabase
    .rpc('can_access_feature_with_limit', {
      user_id_param: userId,
      feature_key_param: featureKey,
    });
  
  if (error) throw error;
  return data as boolean;
}

export async function hasPremiumAccess(userId: string) {
  const { data, error } = await supabase
    .rpc('has_premium_access', {
      user_id_param: userId,
    });
  
  if (error) throw error;
  return data as boolean;
}

export async function updateUserPremiumStatus(userId: string, isPremium: boolean, expiresAt?: string | null) {
  const updates: any = { is_premium: isPremium };
  if (expiresAt !== undefined) {
    updates.premium_expires_at = expiresAt;
  }
  
  const { error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId);
  
  if (error) throw error;
}

export async function trackFeatureUsage(userId: string, featureKey: string) {
  const { error } = await supabase
    .rpc('track_feature_usage_with_limit', {
      user_id_param: userId,
      feature_key_param: featureKey,
    });
  
  if (error) throw error;
}

export async function getUserFeatureUsage(userId: string) {
  const { data, error } = await supabase
    .from('user_feature_usage')
    .select('*')
    .eq('user_id', userId)
    .order('last_used_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? (data as UserFeatureUsage[]) : [];
}

export async function getDailyUsageStats(userId: string, featureKey: string) {
  const { data, error } = await supabase
    .from('user_feature_usage')
    .select('daily_usage_count, daily_usage_date')
    .eq('user_id', userId)
    .eq('feature_key', featureKey)
    .maybeSingle();
  
  if (error) throw error;
  
  // If no record or old date, return 0
  if (!data || data.daily_usage_date !== new Date().toISOString().split('T')[0]) {
    return { count: 0, limit: null };
  }
  
  // Get feature limit
  const { data: featureData } = await supabase
    .from('premium_features')
    .select('free_daily_limit')
    .eq('feature_key', featureKey)
    .maybeSingle();
  
  return { 
    count: data.daily_usage_count || 0, 
    limit: featureData?.free_daily_limit || null 
  };
}

// ============ APK Management APIs ============

export async function getActiveAPKFile() {
  const { data, error } = await supabase
    .from('apk_files')
    .select('*')
    .eq('is_active', true)
    .order('version_code', { ascending: false })
    .limit(1)
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function getAllAPKFiles() {
  const { data, error } = await supabase
    .from('apk_files')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function createAPKFile(apkData: {
  version_name: string;
  version_code: number;
  file_name: string;
  file_path: string;
  file_size: number;
  download_url: string;
  release_notes?: string;
  uploaded_by: string;
}) {
  const { data, error } = await supabase
    .from('apk_files')
    .insert({
      ...apkData,
      is_active: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function updateAPKFile(id: string, updates: {
  version_name?: string;
  version_code?: number;
  release_notes?: string;
  is_active?: boolean;
}) {
  const { data, error } = await supabase
    .from('apk_files')
    .update({
      ...updates,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function deleteAPKFile(id: string) {
  const { error } = await supabase
    .from('apk_files')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
}

export async function deleteAPKFileFromStorage(filePath: string) {
  const { error } = await supabase.storage
    .from('apk-files')
    .remove([filePath]);
  
  if (error) throw error;
}

// ============ Chat APIs ============

export async function getChatMessages(userId: string, otherUserId: string) {
  const { data, error } = await supabase
    .from('chat_messages')
    .select(`
      *,
      sender_profile:profiles!chat_messages_sender_id_fkey(*)
    `)
    .or(`and(sender_id.eq.${userId},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${userId})`)
    .order('created_at', { ascending: true });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function sendChatMessage(
  senderId: string,
  receiverId: string,
  message: string,
  fileUrl?: string | null,
  fileName?: string | null,
  fileType?: string | null,
  fileSize?: number | null
) {
  const { data, error } = await supabase
    .from('chat_messages')
    .insert({
      sender_id: senderId,
      receiver_id: receiverId,
      message,
      file_url: fileUrl,
      file_name: fileName,
      file_type: fileType,
      file_size: fileSize,
    })
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function markChatMessagesAsRead(userId: string, senderId: string) {
  const { error } = await supabase
    .from('chat_messages')
    .update({ is_read: true })
    .eq('receiver_id', userId)
    .eq('sender_id', senderId)
    .eq('is_read', false);
  
  if (error) throw error;
}

export async function getUnreadMessageCount(userId: string) {
  const { data, error } = await supabase
    .from('chat_messages')
    .select('sender_id', { count: 'exact', head: false })
    .eq('receiver_id', userId)
    .eq('is_read', false);
  
  if (error) throw error;
  
  // Group by sender to get count per conversation
  const unreadBySender: Record<string, number> = {};
  if (data) {
    data.forEach((msg: any) => {
      unreadBySender[msg.sender_id] = (unreadBySender[msg.sender_id] || 0) + 1;
    });
  }
  
  return {
    total: data?.length || 0,
    bySender: unreadBySender,
  };
}

export async function getUnreadMessageCountForSender(userId: string, senderId: string) {
  const { count, error } = await supabase
    .from('chat_messages')
    .select('*', { count: 'exact', head: true })
    .eq('receiver_id', userId)
    .eq('sender_id', senderId)
    .eq('is_read', false);
  
  if (error) throw error;
  return count || 0;
}

// ============ AI Chat Session APIs ============

export async function createAIChatSession(userId: string, title: string = 'नई बातचीत') {
  const { data, error } = await supabase
    .from('ai_chat_sessions')
    .insert({
      user_id: userId,
      title,
    })
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function getAIChatSessions(userId: string) {
  const { data, error } = await supabase
    .from('ai_chat_sessions')
    .select('*')
    .eq('user_id', userId)
    .order('updated_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getAIChatSessionMessages(sessionId: string) {
  const { data, error } = await supabase
    .from('ai_chat_history')
    .select('*')
    .eq('session_id', sessionId)
    .order('created_at', { ascending: true });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function updateAIChatSession(sessionId: string, updates: { title?: string; updated_at?: string }) {
  const { data, error } = await supabase
    .from('ai_chat_sessions')
    .update(updates)
    .eq('id', sessionId)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function deleteAIChatSession(sessionId: string) {
  const { error } = await supabase
    .from('ai_chat_sessions')
    .delete()
    .eq('id', sessionId);
  
  if (error) throw error;
}

// ============ 3D Structures APIs ============

export async function getThreeDStructures(filter: { class?: number; subject?: string; chapter?: string } = {}) {
  let query = supabase.from('threed_structures').select('*');
  
  if (filter.class) query = query.eq('class', filter.class);
  if (filter.subject) query = query.eq('subject', filter.subject);
  if (filter.chapter) query = query.eq('chapter', filter.chapter);
  
  const { data, error } = await query.order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function createThreeDStructure(structure: Omit<ThreeDStructure, 'id' | 'created_at' | 'updated_at'>) {
  const { data, error } = await supabase
    .from('threed_structures')
    .insert(structure)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as ThreeDStructure;
}

export async function updateThreeDStructure(id: string, updates: Partial<ThreeDStructure>) {
  const { data, error } = await supabase
    .from('threed_structures')
    .update(updates)
    .eq('id', id)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as ThreeDStructure;
}

export async function deleteThreeDStructure(id: string) {
  const { error } = await supabase
    .from('threed_structures')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
}

// ============ External Notes APIs ============

export async function getExternalNotes(filter: { class?: number; subject?: string; chapter?: string; source?: string } = {}) {
  let query = supabase.from('external_notes').select('*');
  
  if (filter.class) query = query.eq('class', filter.class);
  if (filter.subject) query = query.eq('subject', filter.subject);
  if (filter.chapter) query = query.eq('chapter', filter.chapter);
  if (filter.source) query = query.eq('source', filter.source);
  
  const { data, error } = await query.order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function createExternalNote(note: Omit<ExternalNote, 'id' | 'created_at' | 'updated_at'>) {
  const { data, error } = await supabase
    .from('external_notes')
    .insert(note)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as ExternalNote;
}

export async function updateExternalNote(id: string, updates: Partial<ExternalNote>) {
  const { data, error } = await supabase
    .from('external_notes')
    .update(updates)
    .eq('id', id)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as ExternalNote;
}

export async function deleteExternalNote(id: string) {
  const { error } = await supabase
    .from('external_notes')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
}

// ============ Password Recovery API ============

export async function recoverPasswordByIdentifier(identifier: string, pincode: string, dob: string) {
  // Detect identifier type: email, phone, or username
  // Check if identifier is email
  if (identifier.includes('@')) {
    // Try to find by auth email OR user_email
    const { data, error } = await supabase
      .from('profiles')
      .select('id, full_name, email, phone, user_email')
      .eq('pincode', pincode)
      .eq('date_of_birth', dob)
      .or(`email.ilike.${identifier},user_email.ilike.${identifier}`)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  }
  // Check if identifier is phone number (10 digits)
  else if (/^[0-9]{10}$/.test(identifier)) {
    const { data, error } = await supabase
      .from('profiles')
      .select('id, full_name, email, phone, user_email')
      .eq('phone', identifier)
      .eq('pincode', pincode)
      .eq('date_of_birth', dob)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  }
  // Otherwise, treat as username
  else {
    const email = `${identifier}@miaoda.com`;
    const { data, error } = await supabase
      .from('profiles')
      .select('id, full_name, email, phone, user_email')
      .ilike('email', email)
      .eq('pincode', pincode)
      .eq('date_of_birth', dob)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  }
}

// Legacy function for backward compatibility
export async function recoverPasswordByUsernamePincodeDOB(username: string, pincode: string, dob: string) {
  return recoverPasswordByIdentifier(username, pincode, dob);
}
